# E Learning Platform

> E-learning web application made using Spring Boot and MySql.

![homePage](https://gcdnb.pbrd.co/images/N0Zw4TpwCKn5.png?o=1)

---

### Start the Application
```shell
./mvnw spring-boot:run
```

