package com.elearning.platform.services.core.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.stripe.Stripe;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;

@Service
public class PaymentService {

    // Load Stripe secret key from application.properties or environment variable
    public PaymentService(@Value("${stripe.secret.key}") String stripeKey) {
        if (stripeKey == null || stripeKey.isEmpty()) {
            throw new IllegalArgumentException("Stripe API key is not configured.");
        }
        Stripe.apiKey = stripeKey;
    }

    /**
     * Creates a Stripe PaymentIntent
     * @param amount in currency units (e.g., 10.50 for $10.50)
     * @param currency ISO currency code, e.g., "usd"
     * @return PaymentIntent object
     * @throws Exception if creation fails
     */
    public PaymentIntent createPayment(Double amount, String currency) throws Exception {
        if (amount == null || amount <= 0) {
            throw new IllegalArgumentException("Amount must be greater than 0");
        }
        if (currency == null || currency.isEmpty()) {
            throw new IllegalArgumentException("Currency must be provided");
        }

        PaymentIntentCreateParams params = PaymentIntentCreateParams.builder()
                .setAmount(Math.round(amount * 100)) // convert to smallest currency unit
                .setCurrency(currency)
                .build();

        return PaymentIntent.create(params);
    }
}
