package com.elearning.platform.services.core.impl;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.MentorProfile;
import com.elearning.platform.model.WalletTransaction;
import com.elearning.platform.repositories.PayoutRepository;
import com.elearning.platform.repositories.UserRepository;
import com.elearning.platform.repositories.WalletTransactionRepository;
@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final PayoutRepository payoutRepository;
    private final WalletTransactionRepository walletTransactionRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository,
                           @Lazy PasswordEncoder passwordEncoder,
                           PayoutRepository payoutRepository,
                           WalletTransactionRepository walletTransactionRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.payoutRepository = payoutRepository;
        this.walletTransactionRepository = walletTransactionRepository;
    }

    @Override
    public void createUser(User user) {
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            throw new IllegalStateException("Username already exists: " + user.getUsername());
        }
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new IllegalStateException("Email already registered: " + user.getEmail());
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setWalletBalance(0.0);
        userRepository.save(user);
    }

    @Override
    public void update(User user) {
        User current = userRepository.findById(user.getId())
                .orElseThrow(() -> new IllegalStateException("User not found: " + user.getId()));

        current.setName(user.getName());
        current.setSurname(user.getSurname());
        current.setEmail(user.getEmail());
        current.setImgUrl(user.getImgUrl());
        current.setUsername(user.getUsername());

        userRepository.save(current);
    }

    @Override
    public void patch(User user) {
        User current = userRepository.findById(user.getId())
                .orElseThrow(() -> new IllegalStateException("User not found: " + user.getId()));

        current.setDetail(user.getDetail());
        userRepository.save(current);
    }

    @Override
    public Collection<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User findById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }

    @Override
    public MentorProfile findMentorById(Long mentorId) {
        return null; // implement later
    }

    @Override
    public PayoutRepository getPayoutRepository() {
        return payoutRepository;
    }

    @Override
    public WalletTransaction addWalletBalance(User user, Double amount) {
        user.setWalletBalance(user.getWalletBalance() + amount);
        userRepository.save(user);

        WalletTransaction txn = new WalletTransaction();
        txn.setUser(user);
        txn.setAmount(amount);
        txn.setType("CREDIT");
        txn.setCreatedAt(LocalDateTime.now());

        return walletTransactionRepository.save(txn);
    }

    public boolean deductWallet(User user, Double amount) {
        if (user.getWalletBalance() >= amount) {
            user.setWalletBalance(user.getWalletBalance() - amount);
            userRepository.save(user);

            WalletTransaction txn = new WalletTransaction();
            txn.setUser(user);
            txn.setAmount(amount);
            txn.setType("DEBIT");
            txn.setCreatedAt(LocalDateTime.now());

            walletTransactionRepository.save(txn);
            return true;
        }
        return false;
    }

    public List<WalletTransaction> getWalletTransactions(User user) {
        return walletTransactionRepository.findByUserId(user.getId());
    }
}
