package com.elearning.platform.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elearning.platform.model.Course;
import com.elearning.platform.model.Tutor;


@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {

    List<Course> findByTitleContainingIgnoreCase(String keyword);

    List<Course> findByPriceBetween(Double min, Double max);

    List<Course> findByDurationLessThanEqual(Integer duration);

    List<Course> findByMentorId(Long mentorId);

    List<Course> findByTitleContainingIgnoreCaseAndPriceBetweenAndDuration(
            String keyword, Double minPrice, Double maxPrice, Integer duration
    );
    
    List<Course> findByApprovedFalse();

	List<Course> findAllByTutor(Tutor tutor);

}
