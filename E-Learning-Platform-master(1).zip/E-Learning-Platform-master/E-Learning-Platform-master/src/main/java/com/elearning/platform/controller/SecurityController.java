package com.elearning.platform.controller;

import com.elearning.platform.auth.User;
import com.elearning.platform.auth.UserRepository;
import com.elearning.platform.model.Enrollment;
import com.elearning.platform.repositories.EnrollmentRepository;
import com.elearning.platform.services.core.impl.UserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@PreAuthorize("hasRole('USER')") // Spring Security expects role without "ROLE_" prefix here
@RequestMapping("/user")
public class SecurityController {

    private final UserRepository userRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final UserService userService;

    public SecurityController(UserRepository userRepository,
                              EnrollmentRepository enrollmentRepository,
                              UserService userService) {
        this.userRepository = userRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.userService = userService;
    }

    @GetMapping("/profile")
    public String getUserProfile(@AuthenticationPrincipal User currentUser, Model model) {
        if (currentUser == null) {
            model.addAttribute("error", "User not authenticated");
            return "error";
        }

        // Make sure findAllByUserName expects User or username string
        List<Enrollment> enrollments = enrollmentRepository.findAllByUserName(currentUser.getUsername());
        model.addAttribute("user", currentUser);
        model.addAttribute("enrollments", enrollments);
        model.addAttribute("numCourses", enrollments.size());

        return "user/profile";
    }

    @GetMapping("/edit/{userID}")
    public String getForEdit(@PathVariable Long userID, @AuthenticationPrincipal User currentUser, Model model) {
        return userRepository.findById(userID)
                .map(user -> {
                    if (!currentUser.getUsername().equals(user.getUsername())) {
                        model.addAttribute("error", "Unauthorized access");
                        return "error";
                    }
                    model.addAttribute("user", user);
                    return "user/user-edit";
                })
                .orElseGet(() -> {
                    model.addAttribute("error", "User not found");
                    return "error";
                });
    }

    @PostMapping("/edit/{userID}")
    public String updateUser(@PathVariable Long userID, @AuthenticationPrincipal User currentUser,
                             @ModelAttribute("user") User user, Model model) {
        return userRepository.findById(userID)
                .map(existingUser -> {
                    if (!currentUser.getUsername().equals(existingUser.getUsername())) {
                        model.addAttribute("error", "Unauthorized access");
                        return "error";
                    }
                    existingUser.setName(user.getName());
                    existingUser.setSurname(user.getSurname());
                    existingUser.setEmail(user.getEmail());
                    existingUser.setImgUrl(user.getImgUrl());
                    userService.update(existingUser);
                    return "redirect:/user/profile";
                })
                .orElseGet(() -> {
                    model.addAttribute("error", "User not found");
                    return "error";
                });
    }

    @PostMapping("/patch/{userID}")
    public String patchUser(@PathVariable Long userID, @AuthenticationPrincipal User currentUser,
                            @ModelAttribute("user") User user, Model model) {
        return userRepository.findById(userID)
                .map(existingUser -> {
                    if (!currentUser.getUsername().equals(existingUser.getUsername())) {
                        model.addAttribute("error", "Unauthorized access");
                        return "error";
                    }
                    existingUser.setDetail(user.getDetail()); // make sure User entity has get/setDetail
                    userService.patch(existingUser);
                    return "redirect:/user/profile";
                })
                .orElseGet(() -> {
                    model.addAttribute("error", "User not found");
                    return "error";
                });
    }
}
