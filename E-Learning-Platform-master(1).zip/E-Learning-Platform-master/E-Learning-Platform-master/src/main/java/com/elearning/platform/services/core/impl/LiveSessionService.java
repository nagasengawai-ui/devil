package com.elearning.platform.services.core.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elearning.platform.model.LiveSession;
import com.elearning.platform.auth.User;
import com.elearning.platform.repositories.LiveSessionRepository;

@Service
public class LiveSessionService {

    private final LiveSessionRepository liveSessionRepository;

    @Autowired
    public LiveSessionService(LiveSessionRepository liveSessionRepository) {
        this.liveSessionRepository = liveSessionRepository;
    }

    // Get upcoming sessions (startTime after now)
    public List<LiveSession> getUpcomingSessions() {
        List<LiveSession> upcoming = new ArrayList<>();
        for (LiveSession session : liveSessionRepository.findAll()) {
            if (session.getStartTime() != null && session.getStartTime().isAfter(LocalDateTime.now())) {
                upcoming.add(session);
            }
        }
        return upcoming;
    }

    // Add participant to a session
    public void addParticipant(Long sessionId, User user) {
        if (sessionId == null || user == null) return;

        Optional<LiveSession> sessionOpt = liveSessionRepository.findById(sessionId);
        if (sessionOpt.isPresent()) {
            LiveSession session = sessionOpt.get();
            if (session.getParticipants() == null) {
                session.setParticipants(new ArrayList<>());
            }
            if (!session.getParticipants().contains(user)) {
                session.getParticipants().add(user);
                liveSessionRepository.save(session);
            }
        }
    }

    // Save video recording link for a session
    public void saveRecordingLink(Long sessionId, String videoLink) {
        if (sessionId == null || videoLink == null) return;

        Optional<LiveSession> sessionOpt = liveSessionRepository.findById(sessionId);
        if (sessionOpt.isPresent()) {
            LiveSession session = sessionOpt.get();
            session.setRecordingUrl(videoLink);
            liveSessionRepository.save(session);
        }
    }

    // Get all sessions (for admin or mentor dashboard)
    public List<LiveSession> getAllSessions() {
        return liveSessionRepository.findAll();
    }
}
