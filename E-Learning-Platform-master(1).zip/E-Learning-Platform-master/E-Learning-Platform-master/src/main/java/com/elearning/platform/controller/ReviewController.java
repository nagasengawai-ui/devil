package com.elearning.platform.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.elearning.platform.services.core.impl.ReviewService;

@Controller
@RequestMapping("/reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @PostMapping("/add")
    public String addReview(@RequestParam Long userId,
                            @RequestParam Long mentorId,
                            @RequestParam Integer rating,
                            @RequestParam String comment,
                            Model model) {
        reviewService.addReview(userId, mentorId, rating, comment);
        model.addAttribute("success", "Review submitted successfully!");
        return "redirect:/mentor/profile?mentorId=" + mentorId;
    }
}
