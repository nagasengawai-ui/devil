package com.elearning.platform.services.core.impl;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.Notification;
import com.elearning.platform.repositories.NotificationRepository;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    @Autowired
    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    // Send a notification to a user
    public void sendNotification(User user, String message) {
        if (user == null || message == null || message.isEmpty()) return;

        Notification notification = new Notification();
        notification.setUser(user);
        notification.setMessage(message);
        notification.setIsRead(false);
        notification.setCreatedAt(LocalDateTime.now());

        notificationRepository.save(notification);

        // Optional: send email/SMS
        // emailService.send(user.getEmail(), message);
        // smsService.send(user.getPhone(), message);
    }

    // Get all unread notifications for a user
    public List<Notification> getUnreadNotifications(User user) {
        if (user == null) return Collections.emptyList();
        return notificationRepository.findByUserAndIsReadFalse(user);
    }
}
