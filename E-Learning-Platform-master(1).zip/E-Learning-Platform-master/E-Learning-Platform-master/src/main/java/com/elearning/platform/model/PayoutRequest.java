package com.elearning.platform.model;
import java.lang.*;
import java.util.*;
import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Represents a payout request made by a mentor for their earnings.
 */
@Entity
@Table(name = "payout_requests")
public class PayoutRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mentor_id", nullable = false)
    private MentorProfile mentor;

    @Column(nullable = false)
    private double amount;

    @Column(nullable = false, length = 20)
    private String status; // PENDING, APPROVED, REJECTED

    @Column(name = "requested_at", nullable = false)
    private LocalDateTime requestedAt = LocalDateTime.now();

    public PayoutRequest() {}

    public PayoutRequest(MentorProfile mentor, double amount, String status) {
        this.mentor = mentor;
        this.amount = amount;
        this.status = status;
        this.requestedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public MentorProfile getMentor() { return mentor; }
    public void setMentor(MentorProfile mentor) { this.mentor = mentor; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getRequestedAt() { return requestedAt; }
    public void setRequestedAt(LocalDateTime requestedAt) { this.requestedAt = requestedAt; }

    @Override
    public String toString() {
        return "PayoutRequest{" +
                "id=" + id +
                ", mentor=" + (mentor != null ? mentor.getId() : "null") +
                ", amount=" + amount +
                ", status='" + status + '\'' +
                ", requestedAt=" + requestedAt +
                '}';
    }

	public void setDescription(Object object) {
		// TODO Auto-generated method stub
		
	}
}
