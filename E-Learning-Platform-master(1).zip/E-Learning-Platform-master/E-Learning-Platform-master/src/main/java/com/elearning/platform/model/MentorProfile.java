package com.elearning.platform.model;

import javax.persistence.*;
import java.util.List;
import com.elearning.platform.auth.User;

/**
 * Represents a mentor's profile with bio, expertise, and availability.
 */
@Entity
@Table(name = "mentor_profiles")
public class MentorProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @Column(length = 2000)
    private String bio;

    @Column(length = 500)
    private String expertise;

    @Column(name = "profile_image", length = 500)
    private String profileImage;

    @Column(name = "intro_video", length = 500)
    private String introVideo;

    @Column(name = "is_verified", nullable = false)
    private Boolean isVerified = false;

    // Use Double (wrapper) to allow null checking
    @Column(name = "per_minute_rate")
    private Double perMinuteRate;

    @Column(name = "is_available", nullable = false)
    private Boolean isAvailable = true;

    @OneToMany(mappedBy = "mentor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Course> courses;

    @OneToMany(mappedBy = "mentor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LiveSession> liveSessions;

    @OneToMany(mappedBy = "mentor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Review> reviews;

    // ----- Constructors -----
    public MentorProfile() {
        // Default constructor required by JPA
    }

    public MentorProfile(User user, String bio, String expertise, String profileImage,
                         String introVideo, Boolean isVerified, Double perMinuteRate,
                         Boolean isAvailable) {
        this.user = user;
        this.bio = bio;
        this.expertise = expertise;
        this.profileImage = profileImage;
        this.introVideo = introVideo;
        this.isVerified = isVerified != null ? isVerified : false;
        // Set default if null
        this.perMinuteRate = perMinuteRate != null ? perMinuteRate : 0.0;
        this.isAvailable = isAvailable != null ? isAvailable : true;
    }

    // ----- Getters and Setters -----
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getExpertise() {
        return expertise;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getIntroVideo() {
        return introVideo;
    }

    public void setIntroVideo(String introVideo) {
        this.introVideo = introVideo;
    }

    public Boolean getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    public Double getPerMinuteRate() {
        return perMinuteRate;
    }

    public void setPerMinuteRate(Double perMinuteRate) {
        // Safely handle nulls if needed
        this.perMinuteRate = perMinuteRate != null ? perMinuteRate : 0.0;
    }

    public Boolean getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(Boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public List<LiveSession> getLiveSessions() {
        return liveSessions;
    }

    public void setLiveSessions(List<LiveSession> liveSessions) {
        this.liveSessions = liveSessions;
    }

    public List<Review> getReviews() {
        return reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

    // ----- Helper Method -----
    public String getName() {
        return user != null ? user.getName() + " " + user.getSurname() : "Unknown Mentor";
    }

    // ----- toString() -----
    @Override
    public String toString() {
        return "MentorProfile{" +
                "id=" + id +
                ", name='" + getName() + '\'' +
                ", expertise='" + expertise + '\'' +
                ", verified=" + isVerified +
                ", available=" + isAvailable +
                ", perMinuteRate=" + perMinuteRate +
                '}';
    }
}
