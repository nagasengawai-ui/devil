package com.elearning.platform.dto;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.Course;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

public class EnrollmentDto {

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date date;
    private User user;
    private Course course;

    // No-args constructor
    public EnrollmentDto() {}

    // All-args constructor
    public EnrollmentDto(Date date, User user, Course course) {
        this.date = date;
        this.user = user;
        this.course = course;
    }

    // Getters and setters
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
}
