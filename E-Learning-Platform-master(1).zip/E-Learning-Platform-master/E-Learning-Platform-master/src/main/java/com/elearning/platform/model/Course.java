package com.elearning.platform.model;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Entity
@Table(name = "course")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String title;
    
    @ManyToOne
    @JoinColumn(name = "tutor_id") // foreign key column
    private Tutor tutor;
    
    private Boolean approved = false; // <--- Add this field

    
    public Tutor getTutor() {
		return tutor;
	}

	public void setTutor(Tutor tutor) {
		this.tutor = tutor;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public void setId(Long id) {
		this.id = id;
	}
	private Integer duration; // <-- make sure this exists


    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(columnDefinition = "TEXT")
    private String detail;

    private String difficulty;

    private String url; // video or course link

    private String imgUrl;

    @Column(nullable = false)
    private double price;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "mentor_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MentorProfile mentor;

    // ---------------- Constructors ----------------
    public Course() {}

    public Course(String title, String description, String detail, String difficulty,
                  String url, String imgUrl, double price, MentorProfile mentor) {
        this.title = title;
        this.description = description;
        this.detail = detail;
        this.difficulty = difficulty;
        this.url = url;
        this.imgUrl = imgUrl;
        this.price = price;
        this.mentor = mentor;
    }

    // ---------------- Getters & Setters ----------------
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDetail() { return detail; }
    public void setDetail(String detail) { this.detail = detail; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getImgUrl() { return imgUrl; }
    public void setImgUrl(String imgUrl) { this.imgUrl = imgUrl; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public MentorProfile getMentor() { return mentor; }
    public void setMentor(MentorProfile mentor) { this.mentor = mentor; }
}
