package com.elearning.platform.services.core.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.CourseReview;
import com.elearning.platform.model.MentorProfile;
import com.elearning.platform.model.Review;
import com.elearning.platform.repositories.CourseReviewRepository;
import com.elearning.platform.repositories.MentorRepository;
import com.elearning.platform.repositories.ReviewRepository;
import com.elearning.platform.repositories.UserRepository;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private CourseReviewRepository courseReviewRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MentorRepository mentorRepository;

    public Review saveReview(Review review) {
        return reviewRepository.save(review);
    }

    public List<Review> getReviewsByMentor(Long mentorId) {
        return reviewRepository.findByMentorId(mentorId);
    }

    public CourseReview saveCourseReview(CourseReview courseReview) {
        return courseReviewRepository.save(courseReview);
    }

    public List<CourseReview> getCourseReviews(Long courseId) {
        return courseReviewRepository.findByCourseId(courseId);
    }

    public Review addReview(Long userId, Long mentorId, Integer rating, String comment) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        MentorProfile mentor = mentorRepository.findById(mentorId)
                .orElseThrow(() -> new RuntimeException("Mentor not found"));

        // Create review without Lombok
        Review review = new Review();
        review.setUser(user);
        review.setMentor(mentor);
        review.setRating(rating);
        review.setComment(comment);
        review.setCreatedAt(LocalDateTime.now());

        return reviewRepository.save(review);
    }

}
