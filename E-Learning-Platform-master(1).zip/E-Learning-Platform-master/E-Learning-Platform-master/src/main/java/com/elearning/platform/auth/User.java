package com.elearning.platform.auth;

import java.time.LocalDate;
import javax.persistence.*;

@Entity
@Table(name = "app_user") // avoid MySQL reserved word 'user'
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id") // must match FK
    private long id;

    @Column(name = "username", nullable = false, unique = true)
    private String username;

    @Column(name = "password")
    private String password;

    @Column(name = "name")
    private String name;

    @Column(name = "surname")
    private String surname;

    @Column(name = "email")
    private String email;

    @Column(name = "mobile")
    private String mobile;

    @Column(name = "role")
    private String role = "USER"; // default role

    private String detail;
    private String imgUrl;

    @Column(name = "wallet_balance")
    private double walletBalance = 0;

    @Column(name = "registration_date")
    private LocalDate date;

    // Gamification fields
    private Integer points = 0;
    private String level = "Beginner";
    private String badge = "Bronze";

    // ----- Constructors -----
    public User() {}

    public User(long id, String username, String password, String name, String surname, String email,
                String detail, String imgUrl, LocalDate date, String role, Integer points, String level, String badge) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.detail = detail;
        this.imgUrl = imgUrl;
        this.date = date;
        this.role = role != null ? role : "USER";
        this.points = points != null ? points : 0;
        this.level = level != null ? level : "Beginner";
        this.badge = badge != null ? badge : "Bronze";
    }

    public User(String username, String password, String name, String surname, String email,
                String imgUrl, LocalDate date) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.imgUrl = imgUrl;
        this.date = date != null ? date : LocalDate.now();
    }

    // ----- Getters and Setters -----
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSurname() { return surname; }
    public void setSurname(String surname) { this.surname = surname; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getDetail() { return detail; }
    public void setDetail(String detail) { this.detail = detail; }

    public String getImgUrl() { return imgUrl; }
    public void setImgUrl(String imgUrl) { this.imgUrl = imgUrl; }

    public double getWalletBalance() { return walletBalance; }
    public void setWalletBalance(double walletBalance) { this.walletBalance = walletBalance; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public Integer getPoints() { return points; }
    public void setPoints(Integer points) { this.points = points; }

    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }

    public String getBadge() { return badge; }
    public void setBadge(String badge) { this.badge = badge; }
}
