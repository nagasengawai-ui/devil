package com.elearning.platform.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.elearning.platform.auth.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Find by email
    Optional<User> findById(Long id);  // Must return Optional<User>


    // Find by username

    // Find by mobile number
    Optional<User> findByMobile(String mobile);
    
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);


    // Find by either email, username, or mobile
    @Query("SELECT u FROM User u WHERE u.email = :identifier OR u.username = :identifier OR u.mobile = :identifier")
    Optional<User> findByIdentifier(@Param("identifier") String identifier);
}
