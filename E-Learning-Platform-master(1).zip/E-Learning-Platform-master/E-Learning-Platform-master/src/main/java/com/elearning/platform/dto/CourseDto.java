package com.elearning.platform.dto;

import com.elearning.platform.model.MentorProfile;

public class CourseDto {

    private String title;
    private String description;
    private String detail;
    private String difficulty;
    private String url;
    private String imgUrl;
    private double price;
    private MentorProfile mentor;

    public CourseDto() {}

    public CourseDto(String title, String description, String detail, String difficulty,
                     String url, String imgUrl, double price, MentorProfile mentor) {
        this.title = title;
        this.description = description;
        this.detail = detail;
        this.difficulty = difficulty;
        this.url = url;
        this.imgUrl = imgUrl;
        this.price = price;
        this.mentor = mentor;
    }

    // ---------------- Getters & Setters ----------------
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDetail() { return detail; }
    public void setDetail(String detail) { this.detail = detail; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getImgUrl() { return imgUrl; }
    public void setImgUrl(String imgUrl) { this.imgUrl = imgUrl; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public MentorProfile getMentor() { return mentor; }
    public void setMentor(MentorProfile mentor) { this.mentor = mentor; }
}
