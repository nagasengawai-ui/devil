package com.elearning.platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = {
    "com.elearning.platform.services",
    "com.elearning.platform.controllers", // if you have controllers outside
    "com.elearning.platform.dto"         // optional
})
@EnableJpaRepositories(basePackages = "com.elearning.platform.repositories")
public class PlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(PlatformApplication.class, args);
    }
}
