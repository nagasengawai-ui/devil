package com.elearning.platform.services.core.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elearning.platform.model.MentorProfile;
import com.elearning.platform.repositories.MentorRepository;

@Service
public class MentorService {

    private final MentorRepository mentorRepository;

    @Autowired
    public MentorService(MentorRepository mentorRepository) {
        this.mentorRepository = mentorRepository;
    }

    // Save or update mentor
    public MentorProfile saveMentor(MentorProfile mentor) {
        if (mentor == null) return null;
        try {
            return mentorRepository.save(mentor);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Find mentor by ID
    public Optional<MentorProfile> findById(Long id) {
        if (id == null) return Optional.empty();
        return mentorRepository.findById(id);
    }

    // Get all verified mentors
    public List<MentorProfile> getAllVerifiedMentors() {
        return mentorRepository.findByIsVerifiedTrue();
    }

    // Check if mentor is available
    public boolean isMentorAvailable(MentorProfile mentor) {
        return mentor != null && mentor.getIsAvailable() != null && mentor.getIsAvailable();
    }

    // Get pending mentors (not verified yet)
    public List<MentorProfile> getPendingMentors() {
        return mentorRepository.findAll().stream()
                .filter(m -> m.getIsVerified() == null || !m.getIsVerified())
                .toList();
    }

    // Approve mentor
    public void approveMentor(Long id) {
        if (id == null) return;

        Optional<MentorProfile> optionalMentor = mentorRepository.findById(id);
        if (optionalMentor.isPresent()) {
            MentorProfile mentor = optionalMentor.get();
            mentor.setIsVerified(true);
            mentorRepository.save(mentor);
        }
    }
}
