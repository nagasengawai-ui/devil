package com.elearning.platform.auth;

import javax.persistence.*;

@Entity
@Table(name = "auth_group")
public class AuthGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String username;

    @Column(nullable = false)
    private String authgroup;  // example: ROLE_USER

    // No-args constructor
    public AuthGroup() {}

    // All-args constructor
    public AuthGroup(Long id, String username, String authgroup) {
        this.id = id;
        this.username = username;
        this.authgroup = authgroup;
    }

    // Constructor without ID (for creation)
    public AuthGroup(String username, String authgroup) {
        this.username = username;
        this.authgroup = authgroup;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAuthgroup() {
        return authgroup;
    }

    public void setAuthgroup(String authgroup) {
        this.authgroup = authgroup;
    }
}
