package com.elearning.platform.services.core.impl;

import org.springframework.stereotype.Service;

import com.elearning.platform.auth.User;

@Service
public class GamificationService {

    // Update user's level and badge based on points
    public void updateUserGamification(User user) {
        if (user.getPoints() >= 1000) {
            user.setRoll("Expert");
            user.setBadge("Gold");
        } else if (user.getPoints() >= 500) {
            user.setRoll("Intermediate");
            user.setBadge("Silver");
        } else {
            user.setRoll("Beginner");
            user.setBadge("Bronze");
        }
    }

    // Add points to user and update level/badge
    public void addPoints(User user, int pointsToAdd) {
        if (user.getPoints() == null) {
            user.setPoints(0);
        }
        user.setPoints(user.getPoints() + pointsToAdd);
        updateUserGamification(user);
    }
}
