package com.elearning.platform.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.elearning.platform.auth.User;

@Entity
@Table(name = "wallet_transactions")
public class WalletTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Double amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String type; // CREDIT / DEBIT

    @Column(length = 500)
    private String description;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    // ----------- Constructors -----------

    public WalletTransaction() {
    }

    public WalletTransaction(Double amount, User user, String type, String description) {
        this.amount = amount;
        this.user = user;
        this.type = type;
        this.description = description;
        this.createdAt = LocalDateTime.now();
    }

    public WalletTransaction(Long id, Double amount, User user, String type, String description, LocalDateTime createdAt) {
        this.id = id;
        this.amount = amount;
        this.user = user;
        this.type = type;
        this.description = description;
        this.createdAt = createdAt;
    }

    // ----------- Getters and Setters -----------

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    // ----------- toString() -----------

    @Override
    public String toString() {
        return "WalletTransaction{" +
                "id=" + id +
                ", amount=" + amount +
                ", user=" + (user != null ? user.getUsername() : "null") +
                ", type='" + type + '\'' +
                ", description='" + description + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
