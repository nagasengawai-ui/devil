package com.elearning.platform.services.core.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.Course;
import com.elearning.platform.model.MentorProfile;
import com.elearning.platform.model.PayoutRequest;
import com.elearning.platform.model.WalletTransaction;
import com.elearning.platform.repositories.PayoutRepository;
import com.elearning.platform.repositories.UserRepository;
import com.elearning.platform.repositories.WalletTransactionRepository;

@Service
public class WalletService {

    private static final double COMMISSION_RATE = 0.20; // 20% platform commission

    private final UserRepository userRepository;
    private final WalletTransactionRepository walletTransactionRepository;
    private final PayoutRepository payoutRepository;

    @Autowired
    public WalletService(UserRepository userRepository,
                         WalletTransactionRepository walletTransactionRepository,
                         PayoutRepository payoutRepository) {
        this.userRepository = userRepository;
        this.walletTransactionRepository = walletTransactionRepository;
        this.payoutRepository = payoutRepository;
    }

    // ---------------- Helper Method ----------------
    private WalletTransaction createTransaction(User user, Double amount, String type, String description) {
        WalletTransaction txn = new WalletTransaction();
        txn.setUser(user);
        txn.setAmount(amount);
        txn.setType(type);
        txn.setDescription(description);
        txn.setCreatedAt(LocalDateTime.now());
        return walletTransactionRepository.save(txn);
    }

    // ---------------- Learner Buys Course ----------------
    @Transactional
    public boolean payForCourse(User learner, Course course) {
        if (learner == null || course == null || course.getPrice() == null) return false;

        double price = course.getPrice();
        if (learner.getWalletBalance() == null || learner.getWalletBalance() < price) return false;

        // Deduct from learner
        deduct(learner, price, "Course purchased: " + course.getTitle());

        // Commission split
        double platformShare = price * COMMISSION_RATE;
        double mentorShare = price - platformShare;

        // Credit mentor
        MentorProfile mentorProfile = course.getMentor();
        if (mentorProfile == null || mentorProfile.getUser() == null) {
            throw new IllegalStateException("Mentor or mentor user not found for course");
        }
        User mentorUser = mentorProfile.getUser();
        if (mentorUser.getWalletBalance() == null) mentorUser.setWalletBalance(0.0);

        mentorUser.setWalletBalance(mentorUser.getWalletBalance() + mentorShare);
        userRepository.save(mentorUser);

        // Transaction record for mentor
        createTransaction(mentorUser, mentorShare, "CREDIT", "Earnings from course: " + course.getTitle());

        return true;
    }

    // ---------------- Deduct From Wallet ----------------
    @Transactional
    public boolean deduct(User user, Double amount, String description) {
        if (user == null || amount == null || amount <= 0) return false;

        if (user.getWalletBalance() == null || user.getWalletBalance() < amount) return false;

        user.setWalletBalance(user.getWalletBalance() - amount);
        userRepository.save(user);

        createTransaction(user, amount, "DEBIT", description != null ? description : "Wallet deduction");
        return true;
    }

    // ---------------- Top-Up Wallet ----------------
    @Transactional
    public void topUp(User user, Double amount) {
        if (user == null || amount == null || amount <= 0) return;

        if (user.getWalletBalance() == null) user.setWalletBalance(0.0);
        user.setWalletBalance(user.getWalletBalance() + amount);
        userRepository.save(user);

        createTransaction(user, amount, "CREDIT", "Wallet top-up");
    }

    // ---------------- Mentor Payout Request ----------------
    @Transactional
    public PayoutRequest requestPayout(MentorProfile mentor, Double amount) {
        if (mentor == null || mentor.getUser() == null || amount == null || amount <= 0) {
            throw new IllegalArgumentException("Invalid mentor or payout amount");
        }

        User mentorUser = mentor.getUser();
        if (mentorUser.getWalletBalance() == null || mentorUser.getWalletBalance() < amount) {
            throw new IllegalArgumentException("Insufficient balance for payout");
        }

        PayoutRequest payout = new PayoutRequest();
        payout.setMentor(mentor);
        payout.setAmount(amount);
        payout.setStatus("PENDING");
        payout.setRequestedAt(LocalDateTime.now());

        return payoutRepository.save(payout);
    }

    // ---------------- Approve Payout ----------------
    @Transactional
    public void approvePayout(Long payoutId) {
        PayoutRequest payout = payoutRepository.findById(payoutId)
                .orElseThrow(() -> new IllegalArgumentException("Payout not found"));

        User mentorUser = payout.getMentor().getUser();
        if (mentorUser.getWalletBalance() == null || mentorUser.getWalletBalance() < payout.getAmount()) {
            throw new IllegalStateException("Insufficient balance for payout");
        }

        mentorUser.setWalletBalance(mentorUser.getWalletBalance() - payout.getAmount());
        userRepository.save(mentorUser);

        payout.setStatus("APPROVED");
        payoutRepository.save(payout);

        createTransaction(mentorUser, payout.getAmount(), "DEBIT", "Payout processed");
    }

    // ---------------- Reject Payout ----------------
    @Transactional
    public void rejectPayout(Long payoutId, String reason) {
        PayoutRequest payout = payoutRepository.findById(payoutId)
                .orElseThrow(() -> new IllegalArgumentException("Payout not found"));

        payout.setStatus("REJECTED");
        payout.setDescription(reason == null ? reason : "Payout rejected by admin");
        payoutRepository.save(payout);
    }

    // ---------------- Get Pending Payouts ----------------
    public List<PayoutRequest> getPendingPayouts() {
        return payoutRepository.findByStatus("PENDING");
    }

    // ---------------- Get Wallet Transactions ----------------
    public List<WalletTransaction> getWalletTransactions(User user) {
        if (user == null) return List.of();
        return walletTransactionRepository.findByUserId(user.getId());
    }

}
