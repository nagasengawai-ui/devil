package com.elearning.platform.services.core.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.Course;
import com.elearning.platform.model.Enrollment;

@Service
public class AiSuggestionService {

    /**
     * Suggest courses to a user based on their enrolled courses.
     * @param user the user
     * @param allCourses list of all available courses
     * @return list of suggested courses
     */
    public List<Course> suggestCourses(User user, List<Course> allCourses) {
        if (user == null || allCourses == null || allCourses.isEmpty()) {
            return new ArrayList<>();
        }

        Set<String> keywords = new HashSet<>();
        if (user.getEnrollments() != null) {
            for (Enrollment e : user.getEnrollments()) {
                Course enrolledCourse = e.getCourse();
                if (enrolledCourse != null && enrolledCourse.getTitle() != null) {
                    keywords.add(enrolledCourse.getTitle().toLowerCase());
                }
            }
        }

        List<Course> suggested = new ArrayList<>();
        for (Course c : allCourses) {
            if (c.getTitle() == null) continue;

            for (String k : keywords) {
                if (c.getTitle().toLowerCase().contains(k)) {
                    suggested.add(c);
                    break;
                }
            }
        }

        // fallback: return first 5 courses if nothing matched
        if (suggested.isEmpty()) {
            return allCourses.subList(0, Math.min(5, allCourses.size()));
        }

        return suggested;
    }
}
