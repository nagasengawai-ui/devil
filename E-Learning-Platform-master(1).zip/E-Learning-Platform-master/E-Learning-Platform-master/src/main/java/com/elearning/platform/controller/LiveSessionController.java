package com.elearning.platform.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.LiveSession;
import com.elearning.platform.services.core.impl.LiveSessionService;
import com.elearning.platform.services.core.impl.UserService;

@Controller
@RequestMapping("/live")
public class LiveSessionController {

    @Autowired
    private LiveSessionService liveSessionService;

    @Autowired
    private UserService userService;

    @GetMapping("/upcoming")
    public String upcomingSessions(@RequestParam Long userId, Model model) {
        User user = userService.findById(userId);
        List<LiveSession> sessions = liveSessionService.getUpcomingSessions();
        model.addAttribute("sessions", sessions);
        model.addAttribute("user", user);
        return "live/upcoming";
    }

    @PostMapping("/join/{sessionId}")
    public String joinSession(@PathVariable Long sessionId, @RequestParam Long userId, Model model) {
        User user = userService.findById(userId);
        liveSessionService.addParticipant(sessionId, user);

        // Generate Twilio/Zoom/WebRTC session token (pseudo)
        String videoLink = "https://video.example.com/session/" + sessionId;
        liveSessionService.saveRecordingLink(sessionId, videoLink);

        return "redirect:/live/upcoming?userId=" + userId;
    }
}
