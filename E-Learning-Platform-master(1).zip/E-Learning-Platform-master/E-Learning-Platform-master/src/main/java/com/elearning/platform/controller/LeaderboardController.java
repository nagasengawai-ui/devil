package com.elearning.platform.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.elearning.platform.auth.User;
import com.elearning.platform.services.core.impl.UserService;

@Controller
public class LeaderboardController {

    @Autowired
    private UserService userService;

    @GetMapping("/leaderboard")
    public String leaderboard(Model model) {
        List<User> topUsers = userService.getAllUsers().stream()
                .sorted((u1, u2) -> u2.getPoints() - u1.getPoints())
                .limit(10)
                .toList();
        model.addAttribute("topUsers", topUsers);
        return "leaderboard";
    }
}
