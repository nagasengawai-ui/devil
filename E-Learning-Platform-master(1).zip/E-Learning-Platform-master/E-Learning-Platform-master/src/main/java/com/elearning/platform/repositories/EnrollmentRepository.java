package com.elearning.platform.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.Course;
import com.elearning.platform.model.Enrollment;

@Repository
public interface EnrollmentRepository extends JpaRepository<com.elearning.platform.model.Enrollment, Long> {
    List<com.elearning.platform.model.Enrollment> findByUserId(Long userId);
    List<Enrollment> findByCourseId(Long courseId);
	Object findByCourseAndUserName(Course course, User user);
	boolean existsByCourseAndUser(Course course, User user);
	List<Enrollment> findAllByUserName(String username);
}
