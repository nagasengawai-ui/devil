package com.elearning.platform.services.core.impl;

import java.awt.geom.Arc2D.Double;
import java.util.Collection;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.MentorProfile;
import com.elearning.platform.model.WalletTransaction;

public interface UserService {

    void createUser(User user);

    void update(User user);

    void patch(User user);

    Collection<User> getAllUsers();

    User findById(Long userId);

    MentorProfile findMentorById(Long mentorId);

    Object getPayoutRepository(); // or better: PayoutRepository getPayoutRepository();

	WalletTransaction addWalletBalance(User user, Double amount);

	boolean existsByEmail(String email);

	boolean existsByUsername(String username);
}
