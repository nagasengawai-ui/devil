package com.elearning.platform.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elearning.platform.model.Notification;
import com.elearning.platform.auth.User;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    // Fetch all unread notifications for a specific user
    List<Notification> findByUserAndIsReadFalse(User user);
}
