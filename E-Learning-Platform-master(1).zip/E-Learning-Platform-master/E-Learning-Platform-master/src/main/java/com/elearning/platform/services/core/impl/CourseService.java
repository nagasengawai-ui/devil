package com.elearning.platform.services.core.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elearning.platform.dto.CourseDto;
import com.elearning.platform.model.Course;
import com.elearning.platform.model.MentorProfile;
import com.elearning.platform.repositories.CourseRepository;

@Service
public class CourseService {

    private final CourseRepository courseRepository;

    @Autowired
    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    // Create a course from DTO
    public Course create(CourseDto dto) {
        Course course = new Course(
                dto.getTitle(),
                dto.getDescription(),
                dto.getDetail(),
                dto.getDifficulty(),
                dto.getUrl(),
                dto.getImgUrl(),
                dto.getPrice(),
                dto.getMentor()
        );
        return courseRepository.save(course);
    }

    // Update existing course by ID
    public Course update(CourseDto dto, Long courseId) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        course.setTitle(dto.getTitle());
        course.setDescription(dto.getDescription());
        course.setDetail(dto.getDetail());
        course.setDifficulty(dto.getDifficulty());
        course.setUrl(dto.getUrl());
        course.setImgUrl(dto.getImgUrl());
        course.setPrice(dto.getPrice());
        course.setMentor(dto.getMentor());

        return courseRepository.save(course);
    }

    // Delete course
    public void delete(Course course) {
        courseRepository.delete(course);
    }

    // List all courses
    public List<Course> getAll() {
        return courseRepository.findAll();
    }

    // Find by ID
    public Course findById(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
    }
}
