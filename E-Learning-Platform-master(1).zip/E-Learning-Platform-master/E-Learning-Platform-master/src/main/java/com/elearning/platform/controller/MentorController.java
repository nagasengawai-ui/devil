package com.elearning.platform.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.elearning.platform.model.MentorProfile;
import com.elearning.platform.model.PayoutRequest;
import com.elearning.platform.services.core.impl.UserService;
import com.elearning.platform.services.core.impl.WalletService;

@Controller
@RequestMapping("/mentor")
public class MentorController {

    @Autowired private UserService userService;
    @Autowired private WalletService walletService;

    @GetMapping("/profile")
    public String profile(@RequestParam Long mentorId, Model model) {
        MentorProfile mentor = userService.findMentorById(mentorId);
        model.addAttribute("mentor", mentor);
        return "mentor/profile";
    }

    @PostMapping("/payout-request")
    public String requestPayout(@RequestParam Long mentorId, @RequestParam Double amount, Model model) {
        MentorProfile mentor = userService.findMentorById(mentorId);
        walletService.requestPayout(mentor, amount);
        model.addAttribute("success", "Payout request submitted!");
        return "redirect:/mentor/profile?mentorId=" + mentorId;
    }

    @GetMapping("/payouts")
    public String viewPayouts(@RequestParam Long mentorId, Model model) {
        List<PayoutRequest> payouts = ((Object) userService.getPayoutRepository()).findByMentorId(mentorId);
        model.addAttribute("payouts", payouts);
        return "mentor/payouts";
    }

}
