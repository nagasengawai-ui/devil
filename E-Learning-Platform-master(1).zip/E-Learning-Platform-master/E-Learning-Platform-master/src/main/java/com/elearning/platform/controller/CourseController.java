package com.elearning.platform.controller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.elearning.platform.auth.User;
import com.elearning.platform.auth.UserRepository;
import com.elearning.platform.dto.CourseDto;
import com.elearning.platform.model.Course;
import com.elearning.platform.model.Enrollment;
import com.elearning.platform.model.MentorProfile;
import com.elearning.platform.repositories.CourseRepository;
import com.elearning.platform.repositories.EnrollmentRepository;
import com.elearning.platform.repositories.MentorRepository;
import com.elearning.platform.services.core.impl.CourseService;
import com.elearning.platform.services.core.impl.WalletService;

@Controller
@RequestMapping("/courses")
public class CourseController {

    private final CourseService courseService;
    private final CourseRepository courseRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final UserRepository userRepository;
    private final MentorRepository mentorRepository;
    private final WalletService walletService;

    @Autowired
    public CourseController(CourseService courseService,
                            CourseRepository courseRepository,
                            EnrollmentRepository enrollmentRepository,
                            UserRepository userRepository,
                            MentorRepository mentorRepository,
                            WalletService walletService) {
        this.courseService = courseService;
        this.courseRepository = courseRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.userRepository = userRepository;
        this.mentorRepository = mentorRepository;
        this.walletService = walletService;
    }

    // ---------------- Admin: Add Course ----------------
    @GetMapping("/add/{mentorId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String addCourse(@PathVariable Long mentorId, Model model) {
        MentorProfile mentor = mentorRepository.findById(mentorId)
                .orElseThrow(() -> new RuntimeException("Mentor not found"));
        model.addAttribute("course", new CourseDto());
        model.addAttribute("mentor", mentor);
        return "courses/course-add";
    }

    @PostMapping("/add/{mentorId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String saveCourse(@PathVariable Long mentorId, CourseDto courseDto, Model model) {
        MentorProfile mentor = mentorRepository.findById(mentorId)
                .orElseThrow(() -> new RuntimeException("Mentor not found"));

        courseDto.setMentor(mentor);
        courseService.create(courseDto);
        return "redirect:/courses";
    }

    // ---------------- Admin: Edit Course ----------------
    @GetMapping("/edit/{courseId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String getCourseForUpdate(@PathVariable Long courseId, Model model) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        model.addAttribute("course", course);
        return "courses/course-edit";
    }

    @PostMapping("/edit/{mentorId}/{courseId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String updateCourse(@PathVariable Long mentorId,
                               @PathVariable Long courseId,
                               CourseDto courseDto,
                               RedirectAttributes attributes) {

        MentorProfile mentor = mentorRepository.findById(mentorId)
                .orElseThrow(() -> new RuntimeException("Mentor not found"));

        courseDto.setMentor(mentor);
        courseService.update(courseDto, courseId);
        attributes.addAttribute("courseId", courseId);
        return "redirect:/courses/{courseId}";
    }

    // ---------------- Admin: Delete Course ----------------
    @GetMapping("/delete/{courseId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String deleteCourse(@PathVariable Long courseId) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        courseService.delete(course);
        return "redirect:/courses";
    }

    // ---------------- List Courses (All users) ----------------
    @GetMapping
    public String getCoursesList(Model model) {
        List<Course> courses = courseService.getAll();
        model.addAttribute("courses", courses);
        return "courses/courses";
    }

    // ---------------- Course Detail & Enrollment ----------------
    @GetMapping("/{courseId}")
    @PreAuthorize("hasRole('ROLE_USER')")
    public String getCourseDetail(@PathVariable Long courseId, Authentication authentication, Model model) {
    	// CORRECT
    	Optional<User> optionalUser = userRepository.findById(courseId);
    	User user = optionalUser.orElseThrow(() -> new RuntimeException("User not found"));

        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        boolean enrolled = enrollmentRepository.existsByCourseAndUser(course, user);
        model.addAttribute("course", course);
        model.addAttribute("enrolled", enrolled);
        model.addAttribute("walletBalance", user.getWalletBalance());

        return "courses/course-detail";
    }

    // ---------------- Enroll / Buy Course ----------------
    @PostMapping("/enroll/{courseId}")
    @PreAuthorize("hasRole('ROLE_USER')")
    public String enrollCourse(@PathVariable Long courseId, Authentication authentication, Model model) {
    	// CORRECT
    	Optional<User> optionalUser = userRepository.findById(courseId);
    	User user = optionalUser.orElseThrow(() -> new RuntimeException("User not found"));

        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        // Check if already enrolled
        if (enrollmentRepository.existsByCourseAndUser(course, user)) {
            model.addAttribute("message", "You are already enrolled in this course.");
            model.addAttribute("course", course);
            model.addAttribute("walletBalance", user.getWalletBalance());
            return "courses/course-detail";
        }

        // Pay via wallet
        boolean success = walletService.payForCourse(user, course);
        if (!success) {
            model.addAttribute("error", "Insufficient wallet balance. Please top up to enroll.");
            model.addAttribute("course", course);
            model.addAttribute("walletBalance", user.getWalletBalance());
            return "courses/course-detail";
        }

        // Record enrollment
        enrollmentRepository.save(new Enrollment(course, user));

        model.addAttribute("message", "Successfully enrolled!");
        return "redirect:/courses/" + courseId;
    }
}
