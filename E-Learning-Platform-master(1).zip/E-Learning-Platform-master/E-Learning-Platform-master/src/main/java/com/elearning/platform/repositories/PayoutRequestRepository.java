package com.elearning.platform.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elearning.platform.model.PayoutRequest;

@Repository
public interface PayoutRequestRepository extends JpaRepository<PayoutRequest, Long> {

    // Fetch all payout requests for a specific mentor
    List<PayoutRequest> findByMentorId(Long mentorId);

    // Fetch all payout requests by status (e.g., PENDING, APPROVED, REJECTED)
    List<PayoutRequest> findByStatus(String status);

    // Optional: Fetch payout requests for a specific mentor by status
    List<PayoutRequest> findByMentorIdAndStatus(Long mentorId, String status);
}
