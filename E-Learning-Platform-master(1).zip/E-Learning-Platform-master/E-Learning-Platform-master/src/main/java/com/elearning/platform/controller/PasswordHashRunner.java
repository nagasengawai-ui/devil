package com.elearning.platform.controller;

import com.elearning.platform.auth.User;
import com.elearning.platform.auth.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class PasswordHashRunner implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public PasswordHashRunner(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Checking user passwords...");

        for (User user : userRepository.findAll()) {
            String dbPassword = user.getPassword();

            // If password is not hashed yet (simple check)
            if (!dbPassword.startsWith("$2a$")) {
                String hashed = passwordEncoder.encode(dbPassword);
                user.setPassword(hashed);
                userRepository.save(user);
                System.out.println("Hashed password for user: " + user.getUsername());
            }
        }

        System.out.println("All passwords are now hashed.");
    }
}
