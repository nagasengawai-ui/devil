package com.elearning.platform.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elearning.platform.model.MentorProfile;

@Repository
public interface MentorRepository extends JpaRepository<MentorProfile, Long> {

    // Fetch all verified mentors
    List<MentorProfile> findByIsVerifiedTrue();
}
