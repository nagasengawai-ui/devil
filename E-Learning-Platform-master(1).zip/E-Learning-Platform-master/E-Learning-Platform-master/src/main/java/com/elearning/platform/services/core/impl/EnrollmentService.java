package com.elearning.platform.services.core.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elearning.platform.auth.User;
import com.elearning.platform.model.Course;
import com.elearning.platform.model.Enrollment;
import com.elearning.platform.repositories.EnrollmentRepository;

@Service
public class EnrollmentService {

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    public Enrollment enroll(User user, Course course) {
        Enrollment enrollment = new Enrollment(user, course, LocalDateTime.now());
        return enrollmentRepository.save(enrollment);
    }

    public List<Enrollment> getEnrollmentsByUser(User user) {
        return enrollmentRepository.findByUserId(user.getId());
    }

    public List<Enrollment> getEnrollmentsByCourse(Course course) {
        return enrollmentRepository.findByCourseId(course.getId());
    }

	public void createEnrollment(Long courseId, String username) {
		// TODO Auto-generated method stub
		
	}
}
