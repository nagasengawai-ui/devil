package com.elearning.platform.repositories;

import com.elearning.platform.model.WalletTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WalletTransactionRepository extends JpaRepository<WalletTransaction, Long> {

    // Get all wallet transactions for a specific user
    List<WalletTransaction> findByUserId(Long userId);
}
