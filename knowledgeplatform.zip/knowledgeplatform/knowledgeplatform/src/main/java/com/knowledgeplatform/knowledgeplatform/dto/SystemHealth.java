package com.knowledgeplatform.knowledgeplatform.dto;

import java.time.LocalDateTime;

public class SystemHealth {
    private String serverStatus;
    private String databaseStatus;
    private String apiStatus;
    private String cacheStatus;
    private String storageStatus;
    private Double uptime;
    private Double responseTime;
    private Integer activeUsers;
    private Integer totalMemory;
    private Integer usedMemory;
    private Integer totalDisk;
    private Integer usedDisk;
    private Double cpuUsage;
    private LocalDateTime lastChecked;
    private String overallStatus;
    private HealthMetrics metrics;

    // Default constructor
    public SystemHealth() {
        this.lastChecked = LocalDateTime.now();
    }

    // Getters and setters
    public String getServerStatus() { return serverStatus; }
    public void setServerStatus(String serverStatus) { this.serverStatus = serverStatus; }

    public String getDatabaseStatus() { return databaseStatus; }
    public void setDatabaseStatus(String databaseStatus) { this.databaseStatus = databaseStatus; }

    public String getApiStatus() { return apiStatus; }
    public void setApiStatus(String apiStatus) { this.apiStatus = apiStatus; }

    public String getCacheStatus() { return cacheStatus; }
    public void setCacheStatus(String cacheStatus) { this.cacheStatus = cacheStatus; }

    public String getStorageStatus() { return storageStatus; }
    public void setStorageStatus(String storageStatus) { this.storageStatus = storageStatus; }

    public Double getUptime() { return uptime; }
    public void setUptime(Double uptime) { this.uptime = uptime; }

    public Double getResponseTime() { return responseTime; }
    public void setResponseTime(Double responseTime) { this.responseTime = responseTime; }

    public Integer getActiveUsers() { return activeUsers; }
    public void setActiveUsers(Integer activeUsers) { this.activeUsers = activeUsers; }

    public Integer getTotalMemory() { return totalMemory; }
    public void setTotalMemory(Integer totalMemory) { this.totalMemory = totalMemory; }

    public Integer getUsedMemory() { return usedMemory; }
    public void setUsedMemory(Integer usedMemory) { this.usedMemory = usedMemory; }

    public Integer getTotalDisk() { return totalDisk; }
    public void setTotalDisk(Integer totalDisk) { this.totalDisk = totalDisk; }

    public Integer getUsedDisk() { return usedDisk; }
    public void setUsedDisk(Integer usedDisk) { this.usedDisk = usedDisk; }

    public Double getCpuUsage() { return cpuUsage; }
    public void setCpuUsage(Double cpuUsage) { this.cpuUsage = cpuUsage; }

    public LocalDateTime getLastChecked() { return lastChecked; }
    public void setLastChecked(LocalDateTime lastChecked) { this.lastChecked = lastChecked; }

    public String getOverallStatus() { return overallStatus; }
    public void setOverallStatus(String overallStatus) { this.overallStatus = overallStatus; }

    public HealthMetrics getMetrics() { return metrics; }
    public void setMetrics(com.knowledgeplatform.knowledgeplatform.model.HealthMetrics metrics2) { this.metrics = metrics; }

    // Utility methods
    public Double getMemoryUsagePercentage() {
        if (totalMemory == null || totalMemory == 0) return 0.0;
        return (usedMemory.doubleValue() / totalMemory.doubleValue()) * 100.0;
    }

    public Double getDiskUsagePercentage() {
        if (totalDisk == null || totalDisk == 0) return 0.0;
        return (usedDisk.doubleValue() / totalDisk.doubleValue()) * 100.0;
    }

    public boolean isHealthy() {
        return "HEALTHY".equals(overallStatus);
    }

    public boolean hasWarnings() {
        return "WARNING".equals(overallStatus);
    }

    public boolean isCritical() {
        return "CRITICAL".equals(overallStatus);
    }

    public String getFormattedUptime() {
        if (uptime == null) return "N/A";
        
        long days = (long) (uptime / 24);
        long hours = (long) (uptime % 24);
        return String.format("%d days, %d hours", days, hours);
    }

    // Builder pattern
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private SystemHealth systemHealth = new SystemHealth();

        public Builder serverStatus(String serverStatus) {
            systemHealth.serverStatus = serverStatus;
            return this;
        }

        public Builder databaseStatus(String databaseStatus) {
            systemHealth.databaseStatus = databaseStatus;
            return this;
        }

        public Builder apiStatus(String apiStatus) {
            systemHealth.apiStatus = apiStatus;
            return this;
        }

        public Builder cacheStatus(String cacheStatus) {
            systemHealth.cacheStatus = cacheStatus;
            return this;
        }

        public Builder storageStatus(String storageStatus) {
            systemHealth.storageStatus = storageStatus;
            return this;
        }

        public Builder uptime(Double uptime) {
            systemHealth.uptime = uptime;
            return this;
        }

        public Builder responseTime(Double responseTime) {
            systemHealth.responseTime = responseTime;
            return this;
        }

        public Builder activeUsers(Integer activeUsers) {
            systemHealth.activeUsers = activeUsers;
            return this;
        }

        public Builder memory(Integer total, Integer used) {
            systemHealth.totalMemory = total;
            systemHealth.usedMemory = used;
            return this;
        }

        public Builder disk(Integer total, Integer used) {
            systemHealth.totalDisk = total;
            systemHealth.usedDisk = used;
            return this;
        }

        public Builder cpuUsage(Double cpuUsage) {
            systemHealth.cpuUsage = cpuUsage;
            return this;
        }

        public Builder overallStatus(String overallStatus) {
            systemHealth.overallStatus = overallStatus;
            return this;
        }

        public SystemHealth build() {
            // Calculate overall status if not set
            if (systemHealth.overallStatus == null) {
                systemHealth.overallStatus = calculateOverallStatus();
            }
            systemHealth.lastChecked = LocalDateTime.now();
            return systemHealth;
        }

        private String calculateOverallStatus() {
            int healthyCount = 0;
            int totalCount = 0;

            if (systemHealth.serverStatus != null) {
                totalCount++;
                if ("HEALTHY".equals(systemHealth.serverStatus)) healthyCount++;
            }
            if (systemHealth.databaseStatus != null) {
                totalCount++;
                if ("HEALTHY".equals(systemHealth.databaseStatus)) healthyCount++;
            }
            if (systemHealth.apiStatus != null) {
                totalCount++;
                if ("HEALTHY".equals(systemHealth.apiStatus)) healthyCount++;
            }

            if (totalCount == 0) return "UNKNOWN";
            if (healthyCount == totalCount) return "HEALTHY";
            if (healthyCount >= totalCount * 0.7) return "WARNING";
            return "CRITICAL";
        }
    }

    // Status constants
    public static class Status {
        public static final String HEALTHY = "HEALTHY";
        public static final String WARNING = "WARNING";
        public static final String CRITICAL = "CRITICAL";
        public static final String UNKNOWN = "UNKNOWN";
        public static final String OFFLINE = "OFFLINE";
        public static final String DEGRADED = "DEGRADED";
    }

    @Override
    public String toString() {
        return "SystemHealth{" +
                "overallStatus='" + overallStatus + '\'' +
                ", serverStatus='" + serverStatus + '\'' +
                ", databaseStatus='" + databaseStatus + '\'' +
                ", apiStatus='" + apiStatus + '\'' +
                ", uptime=" + uptime +
                ", responseTime=" + responseTime +
                ", activeUsers=" + activeUsers +
                ", lastChecked=" + lastChecked +
                '}';
    }

private String Metrics;

// HealthMetrics inner class
public void setMetrics(String metrics) {
	Metrics = metrics;
}

class HealthMetrics {
    private Integer totalRequests;
    private Integer successfulRequests;
    private Integer failedRequests;
    private Double errorRate;
    private Integer databaseConnections;
    private Integer activeThreads;
    private Double averageLoad;
    private LocalDateTime metricsTimestamp;

    public HealthMetrics() {
        this.metricsTimestamp = LocalDateTime.now();
    }

    // Getters and setters
    public Integer getTotalRequests() { return totalRequests; }
    public void setTotalRequests(Integer totalRequests) { this.totalRequests = totalRequests; }

    public Integer getSuccessfulRequests() { return successfulRequests; }
    public void setSuccessfulRequests(Integer successfulRequests) { this.successfulRequests = successfulRequests; }

    public Integer getFailedRequests() { return failedRequests; }
    public void setFailedRequests(Integer failedRequests) { this.failedRequests = failedRequests; }

    public Double getErrorRate() { return errorRate; }
    public void setErrorRate(Double errorRate) { this.errorRate = errorRate; }

    public Integer getDatabaseConnections() { return databaseConnections; }
    public void setDatabaseConnections(Integer databaseConnections) { this.databaseConnections = databaseConnections; }

    public Integer getActiveThreads() { return activeThreads; }
    public void setActiveThreads(Integer activeThreads) { this.activeThreads = activeThreads; }

    public Double getAverageLoad() { return averageLoad; }
    public void setAverageLoad(Double averageLoad) { this.averageLoad = averageLoad; }

    public LocalDateTime getMetricsTimestamp() { return metricsTimestamp; }
    public void setMetricsTimestamp(LocalDateTime metricsTimestamp) { this.metricsTimestamp = metricsTimestamp; }

    // Utility methods
    public Double calculateErrorRate() {
        if (totalRequests == null || totalRequests == 0) return 0.0;
        return (failedRequests != null ? failedRequests.doubleValue() : 0.0) / totalRequests.doubleValue() * 100.0;
    }

    public Double getSuccessRate() {
        if (totalRequests == null || totalRequests == 0) return 0.0;
        return (successfulRequests != null ? successfulRequests.doubleValue() : 0.0) / totalRequests.doubleValue() * 100.0;
    
}}}