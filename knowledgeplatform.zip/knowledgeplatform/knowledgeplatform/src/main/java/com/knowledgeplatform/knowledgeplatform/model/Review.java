package com.knowledgeplatform.knowledgeplatform.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "reviews")
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // What is being reviewed
    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    @ManyToOne
    @JoinColumn(name = "mentor_id")
    private MentorProfile mentor;

    @ManyToOne
    @JoinColumn(name = "session_id")
    private LiveSession session;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    private String reviewType; // COURSE_REVIEW, MENTOR_REVIEW, SESSION_REVIEW

    // Rating (1-5 stars)
    @Column(nullable = false)
    private Integer overallRating;

    // Detailed ratings
    private Integer contentRating;
    private Integer instructorRating;
    private Integer valueRating;
    private Integer supportRating;

    // Review content
    private String title;
    
    @Column(columnDefinition = "TEXT")
    private String comment;

    @Column(columnDefinition = "TEXT")
    private String pros;

    @Column(columnDefinition = "TEXT")
    private String cons;

    // Verification
    private Boolean isVerified = false;
    private Boolean wouldRecommend;

    // Engagement
    private Integer helpfulCount = 0;
    private Integer notHelpfulCount = 0;
    private Integer reportCount = 0;

    // Moderation
    private String status = "APPROVED"; // APPROVED, PENDING, FLAGGED, REMOVED
    private String moderatorNotes;

    // Response from mentor
    @Column(columnDefinition = "TEXT")
    private String mentorResponse;

    private LocalDateTime mentorRespondedAt;

    // Timestamps
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Constructors
    public Review() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public Review(User user, Course course, Integer rating, String comment) {
        this();
        this.user = user;
        this.course = course;
        this.overallRating = rating;
        this.comment = comment;
        this.reviewType = "COURSE_REVIEW";
        this.isVerified = true; // User is enrolled
    }

    public Review(User user, MentorProfile mentor, Integer rating, String comment) {
        this();
        this.user = user;
        this.mentor = mentor;
        this.overallRating = rating;
        this.comment = comment;
        this.reviewType = "MENTOR_REVIEW";
    }

    // Business Methods
    public boolean isPositive() {
        return overallRating >= 4;
    }

    public boolean needsModeration() {
        return overallRating <= 2 || reportCount > 5;
    }

    public void markHelpful() {
        this.helpfulCount++;
        this.updatedAt = LocalDateTime.now();
    }

    public void markNotHelpful() {
        this.notHelpfulCount++;
        this.updatedAt = LocalDateTime.now();
    }

    public void report() {
        this.reportCount++;
        if (reportCount >= 3) {
            this.status = "FLAGGED";
        }
        this.updatedAt = LocalDateTime.now();
    }

    public void addMentorResponse(String response) {
        this.mentorResponse = response;
        this.mentorRespondedAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public Double getHelpfulnessScore() {
        int totalVotes = helpfulCount + notHelpfulCount;
        if (totalVotes == 0) return 0.0;
        return (helpfulCount * 100.0) / totalVotes;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    public MentorProfile getMentor() { return mentor; }
    public void setMentor(MentorProfile mentor) { this.mentor = mentor; }
    public LiveSession getSession() { return session; }
    public void setSession(LiveSession session) { this.session = session; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public String getReviewType() { return reviewType; }
    public void setReviewType(String reviewType) { this.reviewType = reviewType; }
    public Integer getOverallRating() { return overallRating; }
    public void setOverallRating(Integer overallRating) { this.overallRating = overallRating; }
    public Integer getContentRating() { return contentRating; }
    public void setContentRating(Integer contentRating) { this.contentRating = contentRating; }
    public Integer getInstructorRating() { return instructorRating; }
    public void setInstructorRating(Integer instructorRating) { this.instructorRating = instructorRating; }
    public Integer getValueRating() { return valueRating; }
    public void setValueRating(Integer valueRating) { this.valueRating = valueRating; }
    public Integer getSupportRating() { return supportRating; }
    public void setSupportRating(Integer supportRating) { this.supportRating = supportRating; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    public String getPros() { return pros; }
    public void setPros(String pros) { this.pros = pros; }
    public String getCons() { return cons; }
    public void setCons(String cons) { this.cons = cons; }
    public Boolean getIsVerified() { return isVerified; }
    public void setIsVerified(Boolean isVerified) { this.isVerified = isVerified; }
    public Boolean getWouldRecommend() { return wouldRecommend; }
    public void setWouldRecommend(Boolean wouldRecommend) { this.wouldRecommend = wouldRecommend; }
    public Integer getHelpfulCount() { return helpfulCount; }
    public void setHelpfulCount(Integer helpfulCount) { this.helpfulCount = helpfulCount; }
    public Integer getNotHelpfulCount() { return notHelpfulCount; }
    public void setNotHelpfulCount(Integer notHelpfulCount) { this.notHelpfulCount = notHelpfulCount; }
    public Integer getReportCount() { return reportCount; }
    public void setReportCount(Integer reportCount) { this.reportCount = reportCount; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getModeratorNotes() { return moderatorNotes; }
    public void setModeratorNotes(String moderatorNotes) { this.moderatorNotes = moderatorNotes; }
    public String getMentorResponse() { return mentorResponse; }
    public void setMentorResponse(String mentorResponse) { this.mentorResponse = mentorResponse; }
    public LocalDateTime getMentorRespondedAt() { return mentorRespondedAt; }
    public void setMentorRespondedAt(LocalDateTime mentorRespondedAt) { this.mentorRespondedAt = mentorRespondedAt; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

	public void setRating(Integer rating) {
		// TODO Auto-generated method stub
		this.contentRating=rating;
		
	}
private double rating;

public double getRating() {
	return rating;
}

public void setRating(double rating) {
	this.rating = rating;
}

public void setId(Long id) {
	this.id = id;
}
}