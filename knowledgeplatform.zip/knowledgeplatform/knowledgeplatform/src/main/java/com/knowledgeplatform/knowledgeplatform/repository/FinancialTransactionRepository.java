package com.knowledgeplatform.knowledgeplatform.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.FinancialTransaction;

@Repository
public interface FinancialTransactionRepository extends JpaRepository<FinancialTransaction, Long> {
    List<FinancialTransaction> findByUserId(Long userId);
    List<FinancialTransaction> findByMentorId(Long mentorId);
    List<FinancialTransaction> findByTransactionType(String transactionType);
    List<FinancialTransaction> findByStatus(String status);
    List<FinancialTransaction> findByTransactionTypeAndStatus(String transactionType, String status);
    List<FinancialTransaction> findTop10ByOrderByCreatedAtDesc();
    
    @Query("SELECT SUM(t.amount) FROM FinancialTransaction t WHERE t.status = 'COMPLETED'")
    Double getTotalRevenue();
    
    @Query("SELECT SUM(t.platformCommission) FROM FinancialTransaction t WHERE t.status = 'COMPLETED'")
    Double getTotalCommission();
    
    @Query("SELECT SUM(t.amount) FROM FinancialTransaction t WHERE t.status = 'COMPLETED' AND t.createdAt >= :since")
    Double getRevenueSince(@Param("since") LocalDateTime since);
    
    @Query("SELECT SUM(t.amount) FROM FinancialTransaction t WHERE t.mentorId = :mentorId AND t.status = 'COMPLETED' AND t.createdAt >= :since")
    Double calculateRecentEarnings(@Param("mentorId") Long mentorId, @Param("since") LocalDateTime since);
	Double getPendingPayoutsAmount();
}