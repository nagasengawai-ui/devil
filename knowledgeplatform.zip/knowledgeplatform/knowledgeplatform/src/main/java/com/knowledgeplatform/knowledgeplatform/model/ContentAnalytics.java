package com.knowledgeplatform.knowledgeplatform.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "content_analytics")
public class ContentAnalytics {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "period_date")
    private LocalDateTime periodDate;

    @Column(name = "total_courses")
    private Integer totalCourses;

    @Column(name = "published_courses")
    private Integer publishedCourses;

    @Column(name = "draft_courses")
    private Integer draftCourses;

    @Column(name = "total_mentors")
    private Integer totalMentors;

    @Column(name = "active_mentors")
    private Integer activeMentors;

    @Column(name = "new_courses")
    private Integer newCourses;

    @Column(name = "course_completion_rate")
    private Double courseCompletionRate;

    @Column(name = "average_course_rating")
    private Double averageCourseRating;

    @Column(name = "total_enrollments")
    private Integer totalEnrollments;

    @Column(name = "new_enrollments")
    private Integer newEnrollments;

    @Column(name = "popular_categories")
    private String popularCategories;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    // Constructors
    public ContentAnalytics() {
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getPeriodDate() { return periodDate; }
    public void setPeriodDate(LocalDateTime periodDate) { this.periodDate = periodDate; }

    public Integer getTotalCourses() { return totalCourses; }
    public void setTotalCourses(Integer totalCourses) { this.totalCourses = totalCourses; }

    public Integer getPublishedCourses() { return publishedCourses; }
    public void setPublishedCourses(Integer publishedCourses) { this.publishedCourses = publishedCourses; }

    public Integer getDraftCourses() { return draftCourses; }
    public void setDraftCourses(Integer draftCourses) { this.draftCourses = draftCourses; }

    public Integer getTotalMentors() { return totalMentors; }
    public void setTotalMentors(Integer totalMentors) { this.totalMentors = totalMentors; }

    public Integer getActiveMentors() { return activeMentors; }
    public void setActiveMentors(Integer activeMentors) { this.activeMentors = activeMentors; }

    public Integer getNewCourses() { return newCourses; }
    public void setNewCourses(Integer newCourses) { this.newCourses = newCourses; }

    public Double getCourseCompletionRate() { return courseCompletionRate; }
    public void setCourseCompletionRate(Double courseCompletionRate) { this.courseCompletionRate = courseCompletionRate; }

    public Double getAverageCourseRating() { return averageCourseRating; }
    public void setAverageCourseRating(Double averageCourseRating) { this.averageCourseRating = averageCourseRating; }

    public Integer getTotalEnrollments() { return totalEnrollments; }
    public void setTotalEnrollments(Integer totalEnrollments) { this.totalEnrollments = totalEnrollments; }

    public Integer getNewEnrollments() { return newEnrollments; }
    public void setNewEnrollments(Integer newEnrollments) { this.newEnrollments = newEnrollments; }

    public String getPopularCategories() { return popularCategories; }
    public void setPopularCategories(String popularCategories) { this.popularCategories = popularCategories; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}