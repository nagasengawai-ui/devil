package com.knowledgeplatform.knowledgeplatform.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

public class UserStats {
    @NotNull @Min(0) private Long totalUsers;
    @NotNull @Min(0) private Long activeUsers;
    @NotNull @Min(0) private Long suspendedUsers;
    @NotNull @Min(0) private Long newUsersToday;
    @NotNull @Min(0) private Long newUsersThisWeek;
    @NotNull @Min(0) private Long newUsersThisMonth;
    @NotNull @Min(0) private Long verifiedUsers;
    @NotNull @Min(0) private Long unverifiedUsers;
    @NotNull @Min(0) private Long mentorUsers;
    @NotNull @Min(0) private Long studentUsers;
    @NotNull private Double growthRate;
    @NotNull private LocalDateTime lastUpdated;

    public UserStats() {
        this.lastUpdated = LocalDateTime.now();
    }

    // Getters and setters
    public Long getTotalUsers() { return totalUsers; }
    public void setTotalUsers(Long totalUsers) { this.totalUsers = totalUsers; }
    public Long getActiveUsers() { return activeUsers; }
    public void setActiveUsers(Long activeUsers) { this.activeUsers = activeUsers; }
    public Long getSuspendedUsers() { return suspendedUsers; }
    public void setSuspendedUsers(Long suspendedUsers) { this.suspendedUsers = suspendedUsers; }
    public Long getNewUsersToday() { return newUsersToday; }
    public void setNewUsersToday(Long newUsersToday) { this.newUsersToday = newUsersToday; }
    public Long getNewUsersThisWeek() { return newUsersThisWeek; }
    public void setNewUsersThisWeek(Long newUsersThisWeek) { this.newUsersThisWeek = newUsersThisWeek; }
    public Long getNewUsersThisMonth() { return newUsersThisMonth; }
    public void setNewUsersThisMonth(Long newUsersThisMonth) { this.newUsersThisMonth = newUsersThisMonth; }
    public Long getVerifiedUsers() { return verifiedUsers; }
    public void setVerifiedUsers(Long verifiedUsers) { this.verifiedUsers = verifiedUsers; }
    public Long getUnverifiedUsers() { return unverifiedUsers; }
    public void setUnverifiedUsers(Long unverifiedUsers) { this.unverifiedUsers = unverifiedUsers; }
    public Long getMentorUsers() { return mentorUsers; }
    public void setMentorUsers(Long mentorUsers) { this.mentorUsers = mentorUsers; }
    public Long getStudentUsers() { return studentUsers; }
    public void setStudentUsers(Long studentUsers) { this.studentUsers = studentUsers; }
    public Double getGrowthRate() { return growthRate; }
    public void setGrowthRate(Double growthRate) { this.growthRate = growthRate; }
    public LocalDateTime getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(LocalDateTime lastUpdated) { this.lastUpdated = lastUpdated; }
}