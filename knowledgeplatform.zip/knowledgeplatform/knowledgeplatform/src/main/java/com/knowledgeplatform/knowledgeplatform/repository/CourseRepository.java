package com.knowledgeplatform.knowledgeplatform.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.Course;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {

    // Find courses by mentor ID
    List<Course> findByMentorId(Long mentorId);
    
    // Find course by ID and mentor ID (for mentor-specific course access)
    Optional<Course> findByIdAndMentorId(Long courseId, Long mentorId);
    
    // Find courses by status
    List<Course> findByStatus(String status);
    
    @Query("SELECT c FROM Course c WHERE c.status = 'PUBLISHED' ORDER BY c.totalEnrollments DESC")
    List<Course> findTopPublishedByEnrollments(int limit);
    
    // Find published courses by mentor
    List<Course> findByMentorIdAndStatus(Long mentorId, String status);
    
    // Find courses by category
    List<Course> findByCategory(String category);
    
    // Find published courses ordered by creation date
    List<Course> findByStatusOrderByCreatedAtDesc(String status);
    
    // Find courses by status ordered by creation date
    List<Course> findByStatusOrderByCreatedAtAsc(String status);
    
    // Search courses by title or description
    List<Course> findByTitleContainingOrDescriptionContaining(String title, String description);
    
    // Find courses by price range
    List<Course> findByPriceBetween(Double minPrice, Double maxPrice);
    
    // Find courses by level
    List<Course> findByLevel(String level);
    
    // Find free courses
    List<Course> findByIsFreeTrue();
    
    // Find paid courses
    List<Course> findByIsFreeFalse();
    
    // Find courses with price less than or equal to
    List<Course> findByPriceLessThanEqual(Double maxPrice);
    
    // Find courses with price greater than or equal to
    List<Course> findByPriceGreaterThanEqual(Double minPrice);
    
    // Find top courses by enrollment count
    List<Course> findTop10ByStatusOrderByTotalEnrollmentsDesc(String status);
    
    // Find top rated courses
    List<Course> findTop10ByStatusOrderByAverageRatingDesc(String status);
    
    // Find newly published courses
    List<Course> findTop10ByStatusOrderByPublishedAtDesc(String status);
    
    // Find courses by mentor and category
    List<Course> findByMentorIdAndCategory(Long mentorId, String category);
    
    // Find courses created after a specific date
    List<Course> findByCreatedAtAfter(LocalDateTime date);
    
    // Find courses published after a specific date
    List<Course> findByPublishedAtAfter(LocalDateTime date);
    
    // Count courses by mentor
    Long countByMentorId(Long mentorId);
    
    // Count courses by status
    Long countByStatus(String status);
    
    // Count courses by category
    Long countByCategory(String category);
    
    // Check if course exists by title and mentor
    Boolean existsByTitleAndMentorId(String title, Long mentorId);
    
    // Find courses by multiple categories
    List<Course> findByCategoryIn(List<String> categories);
    
    // Find courses by multiple levels
    List<Course> findByLevelIn(List<String> levels);
    
    // Custom query to count lectures in a course
    @Query("SELECT COUNT(cl) FROM Course c JOIN c.lectures cl WHERE c.id = :courseId")
    Long countCourseLectures(@Param("courseId") Long courseId);
    
    // Custom query to calculate recent earnings for a mentor
    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t " +
           "WHERE t.mentor.id = :mentorId " +
           "AND t.transactionType = 'COURSE_PURCHASE' " +
           "AND t.createdAt >= :since " +
           "AND t.status = 'COMPLETED'")
    Double calculateRecentEarnings(@Param("mentorId") Long mentorId, @Param("since") LocalDateTime since);
    
    // Advanced search with multiple criteria
    @Query("SELECT c FROM Course c WHERE " +
           "(:query IS NULL OR LOWER(c.title) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(c.description) LIKE LOWER(CONCAT('%', :query, '%'))) AND " +
           "(:category IS NULL OR c.category = :category) AND " +
           "(:level IS NULL OR c.level = :level) AND " +
           "(:minPrice IS NULL OR c.price >= :minPrice) AND " +
           "(:maxPrice IS NULL OR c.price <= :maxPrice) AND " +
           "c.status = 'PUBLISHED'")
    List<Course> searchCourses(@Param("query") String query, 
                              @Param("category") String category, 
                              @Param("level") String level,
                              @Param("minPrice") Double minPrice, 
                              @Param("maxPrice") Double maxPrice);
    
    // Advanced search with sorting
    @Query("SELECT c FROM Course c WHERE " +
           "(:query IS NULL OR LOWER(c.title) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(c.description) LIKE LOWER(CONCAT('%', :query, '%'))) AND " +
           "(:category IS NULL OR c.category = :category) AND " +
           "(:level IS NULL OR c.level = :level) AND " +
           "(:minPrice IS NULL OR c.price >= :minPrice) AND " +
           "(:maxPrice IS NULL OR c.price <= :maxPrice) AND " +
           "c.status = 'PUBLISHED' " +
           "ORDER BY " +
           "CASE WHEN :sortBy = 'price_asc' THEN c.price END ASC, " +
           "CASE WHEN :sortBy = 'price_desc' THEN c.price END DESC, " +
           "CASE WHEN :sortBy = 'rating' THEN c.averageRating END DESC, " +
           "CASE WHEN :sortBy = 'enrollments' THEN c.totalEnrollments END DESC, " +
           "c.createdAt DESC")
    List<Course> searchCoursesWithSorting(@Param("query") String query, 
                                         @Param("category") String category, 
                                         @Param("level") String level,
                                         @Param("minPrice") Double minPrice, 
                                         @Param("maxPrice") Double maxPrice,
                                         @Param("sortBy") String sortBy);
    
    // Find courses with average rating above threshold
    @Query("SELECT c FROM Course c WHERE c.averageRating >= :minRating AND c.status = 'PUBLISHED'")
    List<Course> findByAverageRatingGreaterThanEqual(@Param("minRating") Double minRating);
    
    // Calculate total earnings for a mentor
    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t " +
           "WHERE t.mentor.id = :mentorId " +
           "AND t.transactionType = 'COURSE_PURCHASE' " +
           "AND t.status = 'COMPLETED'")
    Double getTotalEarningsByMentorId(@Param("mentorId") Long mentorId);
    
    // Find courses that need review (for admin)
    @Query("SELECT c FROM Course c WHERE c.status = 'PENDING' ORDER BY c.createdAt ASC")
    List<Course> findCoursesPendingReview();
    
    // Find popular courses in a category
    @Query("SELECT c FROM Course c WHERE c.category = :category AND c.status = 'PUBLISHED' ORDER BY c.totalEnrollments DESC")
    List<Course> findPopularCoursesByCategory(@Param("category") String category);
    
    // Find related courses (same category, different mentor)
    @Query("SELECT c FROM Course c WHERE c.category = :category AND c.mentor.id != :mentorId AND c.status = 'PUBLISHED' ORDER BY c.averageRating DESC")
    List<Course> findRelatedCourses(@Param("category") String category, @Param("mentorId") Long mentorId);

	List<Course> findTop5ByStatusOrderByCreatedAtDesc(String string);
}