package com.knowledgeplatform.knowledgeplatform.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "transactions")
public class Transaction {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "transaction_id", unique = true, nullable = false)
    private String transactionId; // External transaction ID (e.g., from Stripe)
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mentor_id")
    private MentorProfile mentor;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id")
    private Course course;
    
    @Column(name = "amount", nullable = false, precision = 10, scale = 2)
    private Double amount;
    
    @Column(name = "currency", nullable = false)
    private String currency = "USD";
    
    @Column(name = "platform_commission", precision = 10, scale = 2)
    private Double platformCommission;
    
    @Column(name = "mentor_earnings", precision = 10, scale = 2)
    private Double mentorEarnings;
    
    @Column(name = "transaction_type", nullable = false)
    private String transactionType; // COURSE_PURCHASE, MENTORING_SESSION, WALLET_TOPUP, PAYOUT, REFUND
    
    @Column(name = "payment_method")
    private String paymentMethod; // CREDIT_CARD, DEBIT_CARD, WALLET, BANK_TRANSFER, STRIPE
    
    @Column(name = "payment_gateway")
    private String paymentGateway; // STRIPE, PAYPAL, RAZORPAY, etc.
    
    @Column(name = "gateway_transaction_id")
    private String gatewayTransactionId;
    
    @Column(name = "status", nullable = false)
    private String status; // PENDING, COMPLETED, FAILED, REFUNDED, CANCELLED
    
    @Column(name = "description")
    private String description;
    
    @Column(name = "metadata", columnDefinition = "TEXT")
    private String metadata; // JSON string for additional data
    
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    @Column(name = "completed_at")
    private LocalDateTime completedAt;
    
    @Column(name = "refunded_at")
    private LocalDateTime refundedAt;
    
    @Column(name = "failure_reason")
    private String failureReason;
    
    @Column(name = "invoice_url")
    private String invoiceUrl;
    
    @Column(name = "receipt_url")
    private String receiptUrl;

    // Default constructor
    public Transaction() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        generateTransactionId();
    }

    // Constructor with required fields
    public Transaction(User user, Double amount, String transactionType, String status) {
        this();
        this.user = user;
        this.amount = amount;
        this.transactionType = transactionType;
        this.status = status;
        generateTransactionId();
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public MentorProfile getMentor() { return mentor; }
    public void setMentor(MentorProfile mentor) { 
        this.mentor = mentor;
        calculateEarnings();
    }

    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { 
        this.amount = amount;
        calculateEarnings();
    }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public Double getPlatformCommission() { return platformCommission; }
    public void setPlatformCommission(Double platformCommission) { 
        this.platformCommission = platformCommission;
        calculateEarnings();
    }

    public Double getMentorEarnings() { return mentorEarnings; }
    public void setMentorEarnings(Double mentorEarnings) { this.mentorEarnings = mentorEarnings; }

    public String getTransactionType() { return transactionType; }
    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getPaymentGateway() { return paymentGateway; }
    public void setPaymentGateway(String paymentGateway) { this.paymentGateway = paymentGateway; }

    public String getGatewayTransactionId() { return gatewayTransactionId; }
    public void setGatewayTransactionId(String gatewayTransactionId) { this.gatewayTransactionId = gatewayTransactionId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { 
        this.status = status;
        this.updatedAt = LocalDateTime.now();
        
        if ("COMPLETED".equals(status) && this.completedAt == null) {
            this.completedAt = LocalDateTime.now();
        } else if ("REFUNDED".equals(status) && this.refundedAt == null) {
            this.refundedAt = LocalDateTime.now();
        }
    }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getMetadata() { return metadata; }
    public void setMetadata(String metadata) { this.metadata = metadata; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }

    public LocalDateTime getRefundedAt() { return refundedAt; }
    public void setRefundedAt(LocalDateTime refundedAt) { this.refundedAt = refundedAt; }

    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }

    public String getInvoiceUrl() { return invoiceUrl; }
    public void setInvoiceUrl(String invoiceUrl) { this.invoiceUrl = invoiceUrl; }

    public String getReceiptUrl() { return receiptUrl; }
    public void setReceiptUrl(String receiptUrl) { this.receiptUrl = receiptUrl; }

    // Business logic methods
    private void generateTransactionId() {
        if (this.transactionId == null) {
            String timestamp = String.valueOf(System.currentTimeMillis());
            String random = String.valueOf((int) (Math.random() * 1000));
            this.transactionId = "TXN_" + timestamp + "_" + random;
        }
    }

    private void calculateEarnings() {
        if (this.amount != null && this.platformCommission != null) {
            this.mentorEarnings = this.amount - this.platformCommission;
        } else if (this.amount != null && this.platformCommission == null) {
            // Default commission rate of 20%
            this.platformCommission = this.amount * 0.20;
            this.mentorEarnings = this.amount - this.platformCommission;
        }
    }

    // Utility methods
    public boolean isCompleted() {
        return "COMPLETED".equals(this.status);
    }

    public boolean isFailed() {
        return "FAILED".equals(this.status);
    }

    public boolean isPending() {
        return "PENDING".equals(this.status);
    }

    public boolean isRefunded() {
        return "REFUNDED".equals(this.status);
    }

    public boolean isCoursePurchase() {
        return "COURSE_PURCHASE".equals(this.transactionType);
    }

    public boolean isMentoringSession() {
        return "MENTORING_SESSION".equals(this.transactionType);
    }

    public boolean isWalletTopup() {
        return "WALLET_TOPUP".equals(this.transactionType);
    }

    public boolean isPayout() {
        return "PAYOUT".equals(this.transactionType);
    }

    public boolean isRefund() {
        return "REFUND".equals(this.transactionType);
    }

    public void markAsCompleted() {
        setStatus("COMPLETED");
    }

    public void markAsFailed(String reason) {
        setStatus("FAILED");
        this.failureReason = reason;
    }

    public void markAsRefunded() {
        setStatus("REFUNDED");
    }

    public String getFormattedAmount() {
        return String.format("%s %.2f", this.currency, this.amount);
    }

    // Transaction type constants
    public static class Type {
        public static final String COURSE_PURCHASE = "COURSE_PURCHASE";
        public static final String MENTORING_SESSION = "MENTORING_SESSION";
        public static final String WALLET_TOPUP = "WALLET_TOPUP";
        public static final String PAYOUT = "PAYOUT";
        public static final String REFUND = "REFUND";
        public static final String WITHDRAWAL = "WITHDRAWAL";
        public static final String SUBSCRIPTION = "SUBSCRIPTION";
    }

    // Status constants
    public static class Status {
        public static final String PENDING = "PENDING";
        public static final String COMPLETED = "COMPLETED";
        public static final String FAILED = "FAILED";
        public static final String REFUNDED = "REFUNDED";
        public static final String CANCELLED = "CANCELLED";
        public static final String PROCESSING = "PROCESSING";
    }

    // Payment method constants
    public static class PaymentMethod {
        public static final String CREDIT_CARD = "CREDIT_CARD";
        public static final String DEBIT_CARD = "DEBIT_CARD";
        public static final String WALLET = "WALLET";
        public static final String BANK_TRANSFER = "BANK_TRANSFER";
        public static final String STRIPE = "STRIPE";
        public static final String PAYPAL = "PAYPAL";
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", transactionId='" + transactionId + '\'' +
                ", amount=" + amount +
                ", currency='" + currency + '\'' +
                ", transactionType='" + transactionType + '\'' +
                ", status='" + status + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}