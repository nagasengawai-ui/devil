package com.knowledgeplatform.knowledgeplatform.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.knowledgeplatform.knowledgeplatform.dto.MentorEarnings;
import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.Enrollment;
import com.knowledgeplatform.knowledgeplatform.model.LiveSession;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.service.CourseService;
import com.knowledgeplatform.knowledgeplatform.service.MentorService;
import com.knowledgeplatform.knowledgeplatform.service.PaymentService;
import com.knowledgeplatform.knowledgeplatform.service.UserService;

@Controller
@RequestMapping("/mentor")
public class MentorController {

    @Autowired
    private MentorService mentorService;

    @Autowired
    private CourseService courseService;

    @Autowired
    private PaymentService paymentService;

    // Mentor Dashboard
    @GetMapping("/dashboard")
    public String dashboard(Model model, Principal principal) {
        MentorProfile mentor = getMentorFromPrincipal(principal);
        MentorEarnings earnings = mentorService.getMentorEarnings(mentor.getId());
        MentorAnalytics analytics = getMentorAnalytics(mentor.getId());

        model.addAttribute("mentor", mentor);
        model.addAttribute("earnings", earnings);
        model.addAttribute("analytics", analytics);
        model.addAttribute("recentEnrollments", getRecentEnrollments(mentor.getId()));

        return "mentor/dashboard";
    }

    // Course Management
    @GetMapping("/courses")
    public String courseManagement(Model model, Principal principal) {
        MentorProfile mentor = getMentorFromPrincipal(principal);
        List<Course> courses = mentorService.getCoursesByMentor(mentor.getId());

        model.addAttribute("courses", courses);
        model.addAttribute("mentor", mentor);

        return "mentor/courses";
    }

    @GetMapping("/courses/create")
    public String createCourseForm(Model model, Principal principal) {
        model.addAttribute("course", new Course());
        return "mentor/create-course";
    }

    @PostMapping("/courses/create")
    public String createCourse(@ModelAttribute Course course,
                             Principal principal,
                             RedirectAttributes redirectAttributes) {
        MentorProfile mentor = getMentorFromPrincipal(principal);
        
        try {
            Course createdCourse = mentorService.createCourse(mentor.getId(), course);
            redirectAttributes.addFlashAttribute("success", "Course created successfully!");
            return "redirect:/mentor/courses/edit/" + createdCourse.getId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to create course: " + e.getMessage());
            return "redirect:/mentor/courses";
        }
    }

    @GetMapping("/courses/edit/{courseId}")
    public String editCourse(@PathVariable Long courseId, Model model, Principal principal) {
        Course course = courseService.getCourseById(courseId);
        MentorProfile mentor = getMentorFromPrincipal(principal);

        // Security check - ensure mentor owns this course
        if (!course.getMentor().getId().equals(mentor.getId())) {
            return "redirect:/mentor/courses";
        }

        model.addAttribute("course", course);
        return "mentor/edit-course";
    }

    @PostMapping("/courses/submit/{courseId}")
    public String submitCourseForReview(@PathVariable Long courseId,
                                      Principal principal,
                                      RedirectAttributes redirectAttributes) {
        try {
            Course course = courseService.submitForReview(courseId);
            redirectAttributes.addFlashAttribute("success", "Course submitted for review!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Submission failed: " + e.getMessage());
        }

        return "redirect:/mentor/courses";
    }

    // Live Sessions Management
    @GetMapping("/sessions")
    public String sessionManagement(Model model, Principal principal) {
        MentorProfile mentor = getMentorFromPrincipal(principal);
        List<LiveSession> sessions = mentor.getLiveSessions();

        model.addAttribute("sessions", sessions);
        model.addAttribute("mentor", mentor);

        return "mentor/sessions";
    }

    @GetMapping("/sessions/create")
    public String createSessionForm(Model model, Principal principal) {
        model.addAttribute("session", new LiveSession());
        return "mentor/create-session";
    }

    @PostMapping("/sessions/create")
    public String createSession(@ModelAttribute LiveSession session,
                              Principal principal,
                              RedirectAttributes redirectAttributes) {
        MentorProfile mentor = getMentorFromPrincipal(principal);
        
        try {
            LiveSession createdSession = mentorService.createLiveSession(mentor.getId(), session);
            redirectAttributes.addFlashAttribute("success", "Session created successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to create session: " + e.getMessage());
        }

        return "redirect:/mentor/sessions";
    }

    // Earnings & Payouts
    @GetMapping("/earnings")
    public String earnings(Model model, Principal principal) {
        MentorProfile mentor = getMentorFromPrincipal(principal);
        MentorEarnings earnings = mentorService.getMentorEarnings(mentor.getId());
        List<Payout> payoutHistory = getPayoutHistory(mentor.getId());

        model.addAttribute("mentor", mentor);
        model.addAttribute("earnings", earnings);
        model.addAttribute("payoutHistory", payoutHistory);

        return "mentor/earnings";
    }

    @PostMapping("/payout/request")
    public String requestPayout(@RequestParam Double amount,
                              Principal principal,
                              RedirectAttributes redirectAttributes) {
        MentorProfile mentor = getMentorFromPrincipal(principal);
        
        try {
            paymentService.processMentorPayout(mentor.getId(), amount);
            redirectAttributes.addFlashAttribute("success", 
                String.format("Payout request for $%.2f submitted!", amount));
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Payout failed: " + e.getMessage());
        }

        return "redirect:/mentor/earnings";
    }

    // Profile Management
    @GetMapping("/profile")
    public String mentorProfile(Model model, Principal principal) {
        MentorProfile mentor = getMentorFromPrincipal(principal);
        model.addAttribute("mentor", mentor);
        return "mentor/profile";
    }

    @PostMapping("/profile/update")
    public String updateMentorProfile(@ModelAttribute MentorProfile updatedProfile,
                                    Principal principal,
                                    RedirectAttributes redirectAttributes) {
        MentorProfile mentor = getMentorFromPrincipal(principal);
        
        try {
            MentorProfile updated = mentorService.updateMentorProfile(mentor.getId(), updatedProfile);
            redirectAttributes.addFlashAttribute("success", "Profile updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update profile: " + e.getMessage());
        }

        return "redirect:/mentor/profile";
    }

    private MentorProfile getMentorFromPrincipal(Principal principal) {
        User user = userService.getUserByEmail(principal.getName());
        return user.getMentorProfile();
    }

    private MentorAnalytics getMentorAnalytics(Long mentorId) {
        MentorAnalytics analytics = new MentorAnalytics();
        // Implementation to get mentor analytics
        return analytics;
    }

    private List<Enrollment> getRecentEnrollments(Long mentorId) {
        // Implementation to get recent enrollments
        return List.of(); // Placeholder
    }

    private List<Payout> getPayoutHistory(Long mentorId) {
        // Implementation to get payout history
        return List.of(); // Placeholder
    }

    @Autowired
    private UserService userService;
}

// DTO for mentor analytics
class MentorAnalytics {
    private Integer totalStudents;
    private Integer totalCourses;
    private Integer totalSessions;
    private Double averageRating;
    private Double completionRate;
    private Double studentSatisfaction;
    private Integer newStudentsThisMonth;

    // Getters and setters
    public Integer getTotalStudents() { return totalStudents; }
    public void setTotalStudents(Integer totalStudents) { this.totalStudents = totalStudents; }
    public Integer getTotalCourses() { return totalCourses; }
    public void setTotalCourses(Integer totalCourses) { this.totalCourses = totalCourses; }
    public Integer getTotalSessions() { return totalSessions; }
    public void setTotalSessions(Integer totalSessions) { this.totalSessions = totalSessions; }
    public Double getAverageRating() { return averageRating; }
    public void setAverageRating(Double averageRating) { this.averageRating = averageRating; }
    public Double getCompletionRate() { return completionRate; }
    public void setCompletionRate(Double completionRate) { this.completionRate = completionRate; }
    public Double getStudentSatisfaction() { return studentSatisfaction; }
    public void setStudentSatisfaction(Double studentSatisfaction) { this.studentSatisfaction = studentSatisfaction; }
    public Integer getNewStudentsThisMonth() { return newStudentsThisMonth; }
    public void setNewStudentsThisMonth(Integer newStudentsThisMonth) { this.newStudentsThisMonth = newStudentsThisMonth; }
}

// Payout entity (simplified)
class Payout {
    private String id;
    private Double amount;
    private String status;
    private String method;
    // ... other fields
}