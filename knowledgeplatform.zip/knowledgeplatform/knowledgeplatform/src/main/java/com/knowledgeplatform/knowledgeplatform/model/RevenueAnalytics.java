package com.knowledgeplatform.knowledgeplatform.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "revenue_analytics")
public class RevenueAnalytics {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "period_date")
    private LocalDateTime periodDate;

    @Column(name = "total_revenue")
    private BigDecimal totalRevenue;

    @Column(name = "course_revenue")
    private BigDecimal courseRevenue;

    @Column(name = "mentoring_revenue")
    private BigDecimal mentoringRevenue;

    @Column(name = "platform_commission")
    private BigDecimal platformCommission;

    @Column(name = "mentor_payouts")
    private BigDecimal mentorPayouts;

    @Column(name = "net_revenue")
    private BigDecimal netRevenue;

    @Column(name = "new_customers")
    private Integer newCustomers;

    @Column(name = "repeat_customers")
    private Integer repeatCustomers;

    @Column(name = "average_order_value")
    private BigDecimal averageOrderValue;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    // Constructors
    public RevenueAnalytics() {
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getPeriodDate() { return periodDate; }
    public void setPeriodDate(LocalDateTime periodDate) { this.periodDate = periodDate; }

    public BigDecimal getTotalRevenue() { return totalRevenue; }
    public void setTotalRevenue(BigDecimal totalRevenue) { this.totalRevenue = totalRevenue; }

    public BigDecimal getCourseRevenue() { return courseRevenue; }
    public void setCourseRevenue(BigDecimal courseRevenue) { this.courseRevenue = courseRevenue; }

    public BigDecimal getMentoringRevenue() { return mentoringRevenue; }
    public void setMentoringRevenue(BigDecimal mentoringRevenue) { this.mentoringRevenue = mentoringRevenue; }

    public BigDecimal getPlatformCommission() { return platformCommission; }
    public void setPlatformCommission(BigDecimal platformCommission) { this.platformCommission = platformCommission; }

    public BigDecimal getMentorPayouts() { return mentorPayouts; }
    public void setMentorPayouts(BigDecimal mentorPayouts) { this.mentorPayouts = mentorPayouts; }

    public BigDecimal getNetRevenue() { return netRevenue; }
    public void setNetRevenue(BigDecimal netRevenue) { this.netRevenue = netRevenue; }

    public Integer getNewCustomers() { return newCustomers; }
    public void setNewCustomers(Integer newCustomers) { this.newCustomers = newCustomers; }

    public Integer getRepeatCustomers() { return repeatCustomers; }
    public void setRepeatCustomers(Integer repeatCustomers) { this.repeatCustomers = repeatCustomers; }

    public BigDecimal getAverageOrderValue() { return averageOrderValue; }
    public void setAverageOrderValue(BigDecimal averageOrderValue) { this.averageOrderValue = averageOrderValue; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}