package com.knowledgeplatform.knowledgeplatform.model;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "enrollments")
public class Enrollment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    @NotNull
    private LocalDateTime enrolledAt;

    private LocalDateTime completedAt;

    @NotNull
    private String status = "ACTIVE";

    @Min(0) @Max(100)
    private Double progress = 0.0;

    private Integer completedLectures = 0;

    private LocalDateTime lastActivityAt;

    @Min(0)
    private Double amountPaid = 0.0;

    @Min(0)
    private Double platformCommission = 0.0;

    private String paymentMethod;
    private String paymentStatus = "PENDING";

    private Integer accessExpiryDays = 365;

    @PrePersist
    protected void onCreate() {
        enrolledAt = LocalDateTime.now();
        lastActivityAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        lastActivityAt = LocalDateTime.now();
    }

    // Business Methods
    public void completeLecture() {
        this.completedLectures++;
        updateProgress();
    }

    private void updateProgress() {
        if (course != null && course.getTotalLectures() != null && course.getTotalLectures() > 0) {
            this.progress = (completedLectures.doubleValue() / course.getTotalLectures()) * 100.0;
        }
    }

    public boolean isCompleted() {
        return progress >= 100.0;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    public LocalDateTime getEnrolledAt() { return enrolledAt; }
    public void setEnrolledAt(LocalDateTime enrolledAt) { this.enrolledAt = enrolledAt; }
    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Double getProgress() { return progress; }
    public void setProgress(Double progress) { this.progress = progress; }
    public Integer getCompletedLectures() { return completedLectures; }
    public void setCompletedLectures(Integer completedLectures) { this.completedLectures = completedLectures; }
    public LocalDateTime getLastActivityAt() { return lastActivityAt; }
    public void setLastActivityAt(LocalDateTime lastActivityAt) { this.lastActivityAt = lastActivityAt; }
    public Double getAmountPaid() { return amountPaid; }
    public void setAmountPaid(Double amountPaid) { this.amountPaid = amountPaid; }
    public Double getPlatformCommission() { return platformCommission; }
    public void setPlatformCommission(Double platformCommission) { this.platformCommission = platformCommission; }
    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }
    public Integer getAccessExpiryDays() { return accessExpiryDays; }
    public void setAccessExpiryDays(Integer accessExpiryDays) { this.accessExpiryDays = accessExpiryDays; }
}