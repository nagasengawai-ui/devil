package com.knowledgeplatform.knowledgeplatform.model;

import java.time.LocalDateTime;

public class PlatformActivity {
    private String type;
    private String description;
    private LocalDateTime timestamp;
    private Long userId;
    private String userFullName;
    private Long entityId;
    private String entityType;
    private String ipAddress;
    private String userAgent;
    private String severity; // INFO, WARNING, ERROR, SUCCESS
    private String category; // USER, COURSE, MENTOR, PAYMENT, SYSTEM

    // Default constructor
    public PlatformActivity() {
        this.timestamp = LocalDateTime.now();
        this.severity = "INFO";
    }

    // Constructor with required fields
    public PlatformActivity(String type, String description, LocalDateTime timestamp) {
        this();
        this.type = type;
        this.description = description;
        this.timestamp = timestamp;
    }

    // Constructor with all fields
    public PlatformActivity(String type, String description, LocalDateTime timestamp, 
                          Long userId, String userFullName, Long entityId, String entityType,
                          String ipAddress, String userAgent, String severity, String category) {
        this.type = type;
        this.description = description;
        this.timestamp = timestamp;
        this.userId = userId;
        this.userFullName = userFullName;
        this.entityId = entityId;
        this.entityType = entityType;
        this.ipAddress = ipAddress;
        this.userAgent = userAgent;
        this.severity = severity;
        this.category = category;
    }

    // Getters and setters
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getUserFullName() { return userFullName; }
    public void setUserFullName(String userFullName) { this.userFullName = userFullName; }

    public Long getEntityId() { return entityId; }
    public void setEntityId(Long entityId) { this.entityId = entityId; }

    public String getEntityType() { return entityType; }
    public void setEntityType(String entityType) { this.entityType = entityType; }

    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }

    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }

    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    // Utility methods
    public boolean isUserActivity() {
        return userId != null;
    }

    public boolean isSystemActivity() {
        return "SYSTEM".equals(category);
    }

    public boolean isError() {
        return "ERROR".equals(severity);
    }

    public boolean isWarning() {
        return "WARNING".equals(severity);
    }

    public boolean isSuccess() {
        return "SUCCESS".equals(severity);
    }

    public String getFormattedTimestamp() {
        return timestamp != null ? timestamp.toString() : "N/A";
    }

    public String getActivitySummary() {
        return String.format("[%s] %s - %s", 
            severity != null ? severity : "INFO", 
            type != null ? type : "UNKNOWN", 
            description != null ? description : "No description");
    }

    // Builder pattern for easy creation
    public static Builder builder() {
        return new Builder();
    }

    // Builder class
    public static class Builder {
        private String type;
        private String description;
        private LocalDateTime timestamp;
        private Long userId;
        private String userFullName;
        private Long entityId;
        private String entityType;
        private String ipAddress;
        private String userAgent;
        private String severity;
        private String category;

        public Builder type(String type) {
            this.type = type;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder timestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public Builder userId(Long userId) {
            this.userId = userId;
            return this;
        }

        public Builder userFullName(String userFullName) {
            this.userFullName = userFullName;
            return this;
        }

        public Builder entityId(Long entityId) {
            this.entityId = entityId;
            return this;
        }

        public Builder entityType(String entityType) {
            this.entityType = entityType;
            return this;
        }

        public Builder ipAddress(String ipAddress) {
            this.ipAddress = ipAddress;
            return this;
        }

        public Builder userAgent(String userAgent) {
            this.userAgent = userAgent;
            return this;
        }

        public Builder severity(String severity) {
            this.severity = severity;
            return this;
        }

        public Builder category(String category) {
            this.category = category;
            return this;
        }

        public PlatformActivity build() {
            PlatformActivity activity = new PlatformActivity();
            activity.type = this.type;
            activity.description = this.description;
            activity.timestamp = this.timestamp != null ? this.timestamp : LocalDateTime.now();
            activity.userId = this.userId;
            activity.userFullName = this.userFullName;
            activity.entityId = this.entityId;
            activity.entityType = this.entityType;
            activity.ipAddress = this.ipAddress;
            activity.userAgent = this.userAgent;
            activity.severity = this.severity != null ? this.severity : "INFO";
            activity.category = this.category;
            return activity;
        }
    }

    // Predefined activity types
    public static class Types {
        // User activities
        public static final String USER_REGISTRATION = "USER_REGISTRATION";
        public static final String USER_LOGIN = "USER_LOGIN";
        public static final String USER_LOGOUT = "USER_LOGOUT";
        public static final String USER_PROFILE_UPDATE = "USER_PROFILE_UPDATE";
        public static final String USER_PASSWORD_CHANGE = "USER_PASSWORD_CHANGE";
        
        // Course activities
        public static final String COURSE_CREATED = "COURSE_CREATED";
        public static final String COURSE_PUBLISHED = "COURSE_PUBLISHED";
        public static final String COURSE_UPDATED = "COURSE_UPDATED";
        public static final String COURSE_VIEWED = "COURSE_VIEWED";
        public static final String COURSE_ENROLLMENT = "COURSE_ENROLLMENT";
        public static final String COURSE_COMPLETION = "COURSE_COMPLETION";
        
        // Mentor activities
        public static final String MENTOR_REGISTRATION = "MENTOR_REGISTRATION";
        public static final String MENTOR_VERIFICATION = "MENTOR_VERIFICATION";
        public static final String MENTOR_PROFILE_UPDATE = "MENTOR_PROFILE_UPDATE";
        
        // Payment activities
        public static final String PAYMENT_PROCESSED = "PAYMENT_PROCESSED";
        public static final String PAYMENT_FAILED = "PAYMENT_FAILED";
        public static final String PAYOUT_REQUESTED = "PAYOUT_REQUESTED";
        public static final String PAYOUT_PROCESSED = "PAYOUT_PROCESSED";
        
        // Review activities
        public static final String REVIEW_CREATED = "REVIEW_CREATED";
        public static final String REVIEW_UPDATED = "REVIEW_UPDATED";
        
        // System activities
        public static final String SYSTEM_STARTUP = "SYSTEM_STARTUP";
        public static final String SYSTEM_SHUTDOWN = "SYSTEM_SHUTDOWN";
        public static final String SYSTEM_ERROR = "SYSTEM_ERROR";
        public static final String SYSTEM_BACKUP = "SYSTEM_BACKUP";
    }

    // Predefined categories
    public static class Categories {
        public static final String USER = "USER";
        public static final String COURSE = "COURSE";
        public static final String MENTOR = "MENTOR";
        public static final String PAYMENT = "PAYMENT";
        public static final String REVIEW = "REVIEW";
        public static final String SYSTEM = "SYSTEM";
    }

    // Predefined severity levels
    public static class Severity {
        public static final String INFO = "INFO";
        public static final String SUCCESS = "SUCCESS";
        public static final String WARNING = "WARNING";
        public static final String ERROR = "ERROR";
    }

    @Override
    public String toString() {
        return "PlatformActivity{" +
                "type='" + type + '\'' +
                ", description='" + description + '\'' +
                ", timestamp=" + timestamp +
                ", userId=" + userId +
                ", userFullName='" + userFullName + '\'' +
                ", entityId=" + entityId +
                ", entityType='" + entityType + '\'' +
                ", severity='" + severity + '\'' +
                ", category='" + category + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PlatformActivity that = (PlatformActivity) o;

        if (type != null ? !type.equals(that.type) : that.type != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (timestamp != null ? !timestamp.equals(that.timestamp) : that.timestamp != null) return false;
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;
        return entityId != null ? entityId.equals(that.entityId) : that.entityId == null;
    }

    @Override
    public int hashCode() {
        int result = type != null ? type.hashCode() : 0;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (timestamp != null ? timestamp.hashCode() : 0);
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        result = 31 * result + (entityId != null ? entityId.hashCode() : 0);
        return result;
    }
}