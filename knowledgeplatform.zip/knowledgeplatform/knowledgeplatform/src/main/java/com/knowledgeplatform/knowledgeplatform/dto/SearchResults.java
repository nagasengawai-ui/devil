package com.knowledgeplatform.knowledgeplatform.dto;

import java.util.List;

import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.LiveSession;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;

public class SearchResults {
    private List<Course> courses;
    private List<MentorProfile> mentors;
    private List<LiveSession> sessions;
    private String aiExplanation;

    // Getters and setters
    public List<Course> getCourses() { return courses; }
    public void setCourses(List<Course> courses) { this.courses = courses; }
    public List<MentorProfile> getMentors() { return mentors; }
    public void setMentors(List<MentorProfile> mentors) { this.mentors = mentors; }
    public List<LiveSession> getSessions() { return sessions; }
    public void setSessions(List<LiveSession> sessions) { this.sessions = sessions; }
    public String getAiExplanation() { return aiExplanation; }
    public void setAiExplanation(String aiExplanation) { this.aiExplanation = aiExplanation; }
}