package com.knowledgeplatform.knowledgeplatform.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.knowledgeplatform.knowledgeplatform.model.LiveSession;
import com.knowledgeplatform.knowledgeplatform.model.Review;
import com.knowledgeplatform.knowledgeplatform.model.SessionBooking;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.service.LiveSessionService;
import com.knowledgeplatform.knowledgeplatform.service.PaymentService;
import com.knowledgeplatform.knowledgeplatform.service.UserService;

@Controller
@RequestMapping("/sessions")
public class LiveSessionController {

    @Autowired
    private LiveSessionService liveSessionService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private UserService userService;

    // Session Detail Page
    @GetMapping("/{sessionId}")
    public String sessionDetail(@PathVariable Long sessionId, Model model, Principal principal) {
        LiveSession session = liveSessionService.getSessionById(sessionId);
        
        // Increment view count
        liveSessionService.incrementViewCount(sessionId);

        model.addAttribute("session", session);
        model.addAttribute("mentor", session.getMentor());

        // Check if user can book free trial
        if (principal != null) {
            User user = getUserFromPrincipal(principal);
            boolean canBookFreeTrial = session.canStartFreeTrial(user);
            model.addAttribute("canBookFreeTrial", canBookFreeTrial);
            model.addAttribute("currentUser", user);
        }

        return "sessions/detail";
    }

    // Book Free Trial
    @PostMapping("/{sessionId}/book-trial")
    public String bookFreeTrial(@PathVariable Long sessionId,
                              Principal principal,
                              RedirectAttributes redirectAttributes) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = getUserFromPrincipal(principal);
        LiveSession session = liveSessionService.getSessionById(sessionId);
        
        try {
            SessionBooking booking = liveSessionService.bookSession(sessionId, user.getId());
            redirectAttributes.addFlashAttribute("success", 
                "Free trial booked! You have " + session.getFreeTrialMinutes() + " minutes.");
            return "redirect:/sessions/call/" + booking.getId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Booking failed: " + e.getMessage());
            return "redirect:/sessions/" + sessionId;
        }
    }

   

	// Book Paid Session
    @PostMapping("/{sessionId}/book")
    public String bookSession(@PathVariable Long sessionId,
                            @RequestParam Integer duration,
                            Principal principal,
                            RedirectAttributes redirectAttributes) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = getUserFromPrincipal(principal);
        
        try {
            SessionBooking booking = liveSessionService.bookSession(sessionId, user.getId(), duration);
            redirectAttributes.addFlashAttribute("success", 
                String.format("Session booked for %d minutes!", duration));
            return "redirect:/sessions/call/" + booking.getId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Booking failed: " + e.getMessage());
            return "redirect:/sessions/" + sessionId;
        }
    }

    // Call Interface (WebRTC)
    @GetMapping("/call/{bookingId}")
    public String callInterface(@PathVariable Long bookingId, Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        SessionBooking booking = liveSessionService.getBookingById(bookingId);
        User user = getUserFromPrincipal(principal);

        // Security check
        if (!booking.getUser().getId().equals(user.getId()) && 
            !booking.getSession().getMentor().getUser().getId().equals(user.getId())) {
            return "redirect:/";
        }

        // Generate WebRTC tokens
        WebRTCConfig webrtcConfig = generateWebRTCConfig(booking);

        model.addAttribute("booking", booking);
        model.addAttribute("session", booking.getSession());
        model.addAttribute("webrtcConfig", webrtcConfig);
        model.addAttribute("isMentor", booking.getSession().getMentor().getUser().getId().equals(user.getId()));

        return "sessions/call";
    }

    // Start Session (Mentor only)
    @PostMapping("/call/{bookingId}/start")
    @ResponseBody
    public ApiResponse startSession(@PathVariable Long bookingId, Principal principal) {
        User user = getUserFromPrincipal(principal);
        SessionBooking booking = liveSessionService.getBookingById(bookingId);

        // Check if user is the mentor
        if (!booking.getSession().getMentor().getUser().getId().equals(user.getId())) {
            return new ApiResponse("error", "Only mentor can start session");
        }

        try {
            liveSessionService.startSession(bookingId);
            return new ApiResponse("success", "Session started");
        } catch (Exception e) {
            return new ApiResponse("error", e.getMessage());
        }
    }

    // End Session
    @PostMapping("/call/{bookingId}/end")
    @ResponseBody
    public ApiResponse endSession(@PathVariable Long bookingId,
                                @RequestParam Integer duration,
                                Principal principal) {
        User user = getUserFromPrincipal(principal);
        SessionBooking booking = liveSessionService.getBookingById(bookingId);

        // Check permissions
        if (!booking.getUser().getId().equals(user.getId()) && 
            !booking.getSession().getMentor().getUser().getId().equals(user.getId())) {
            return new ApiResponse("error", "Not authorized");
        }

        try {
            liveSessionService.endSession(bookingId, duration);
            return new ApiResponse("success", "Session ended");
        } catch (Exception e) {
            return new ApiResponse("error", e.getMessage());
        }
    }

    // Session Feedback
    @GetMapping("/call/{bookingId}/feedback")
    public String feedbackForm(@PathVariable Long bookingId, Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        SessionBooking booking = liveSessionService.getBookingById(bookingId);
        User user = getUserFromPrincipal(principal);

        // Security check
        if (!booking.getUser().getId().equals(user.getId())) {
            return "redirect:/";
        }

        model.addAttribute("booking", booking);
        model.addAttribute("session", booking.getSession());

        return "sessions/feedback";
    }

    @PostMapping("/call/{bookingId}/feedback")
    public String submitFeedback(@PathVariable Long bookingId,
                               @RequestParam Integer rating,
                               @RequestParam String comment,
                               Principal principal,
                               RedirectAttributes redirectAttributes) {
        User user = getUserFromPrincipal(principal);
        
        try {
            Review review = liveSessionService.submitSessionFeedback(bookingId, user.getId(), rating, comment);
            redirectAttributes.addFlashAttribute("success", "Thank you for your feedback!");
            return "redirect:/user/learning";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to submit feedback: " + e.getMessage());
            return "redirect:/sessions/call/" + bookingId + "/feedback";
        }
    }

    // Webinar Registration
    @PostMapping("/webinar/{sessionId}/register")
    public String registerWebinar(@PathVariable Long sessionId,
                                Principal principal,
                                RedirectAttributes redirectAttributes) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = getUserFromPrincipal(principal);
        
        try {
            SessionBooking registration = liveSessionService.registerForWebinar(sessionId, user.getId());
            redirectAttributes.addFlashAttribute("success", "Successfully registered for webinar!");
            return "redirect:/user/learning";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Registration failed: " + e.getMessage());
            return "redirect:/sessions/" + sessionId;
        }
    }

    private User getUserFromPrincipal(Principal principal) {
        return userService.getUserByEmail(principal.getName());
    }

    private WebRTCConfig generateWebRTCConfig(SessionBooking booking) {
        WebRTCConfig config = new WebRTCConfig();
        // Implementation to generate WebRTC configuration
        // This would integrate with services like Twilio, Agora, etc.
        config.setSessionId(booking.getSession().getWebRtcSessionId());
        config.setToken(generateToken(booking));
        config.setApiKey("your_webrtc_api_key");
        
        return config;
    }

    private String generateToken(SessionBooking booking) {
        // Implementation to generate WebRTC token
        return "token_" + booking.getId() + "_" + System.currentTimeMillis();
    }
}

// WebRTC Configuration DTO
class WebRTCConfig {
    private String sessionId;
    private String token;
    private String apiKey;

    // Getters and setters
    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public String getApiKey() { return apiKey; }
    public void setApiKey(String apiKey) { this.apiKey = apiKey; }
}