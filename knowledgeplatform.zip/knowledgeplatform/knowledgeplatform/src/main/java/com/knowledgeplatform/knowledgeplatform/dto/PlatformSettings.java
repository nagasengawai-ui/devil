package com.knowledgeplatform.knowledgeplatform.dto;

import java.math.BigDecimal;

public class PlatformSettings {
    private double commissionRate;
    private double minimumPayout;
    private int freeTrialMinutes;
    private boolean registrationEnabled;
    private boolean emailVerificationRequired;
    private String platformName;
    private String supportEmail;
	private boolean mentorVerificationRequired;
    
    // Constructors
    public PlatformSettings() {}
    
    public PlatformSettings(double commissionRate, double minimumPayout, 
                           int freeTrialMinutes, boolean registrationEnabled, 
                           boolean emailVerificationRequired, String platformName, 
                           String supportEmail) {
        this.commissionRate = commissionRate;
        this.minimumPayout = minimumPayout;
        this.freeTrialMinutes = freeTrialMinutes;
        this.registrationEnabled = registrationEnabled;
        this.emailVerificationRequired = emailVerificationRequired;
        this.platformName = platformName;
        this.supportEmail = supportEmail;
    }
    
    // Getters and setters
    public double getCommissionRate() { return commissionRate; }
    public void setCommissionRate(double d) { this.commissionRate = d; }
    
    public double getMinimumPayout() { return minimumPayout; }
    public void setMinimumPayout(double d) { this.minimumPayout = d; }
    
    public int getFreeTrialMinutes() { return freeTrialMinutes; }
    public void setFreeTrialMinutes(int freeTrialMinutes) { this.freeTrialMinutes = freeTrialMinutes; }
    
    public boolean isRegistrationEnabled() { return registrationEnabled; }
    public void setRegistrationEnabled(boolean registrationEnabled) { this.registrationEnabled = registrationEnabled; }
    
    public boolean isEmailVerificationRequired() { return emailVerificationRequired; }
    public void setEmailVerificationRequired(boolean emailVerificationRequired) { this.emailVerificationRequired = emailVerificationRequired; }
    
    public String getPlatformName() { return platformName; }
    public void setPlatformName(String platformName) { this.platformName = platformName; }
    
    public String getSupportEmail() { return supportEmail; }
    public void setSupportEmail(String supportEmail) { this.supportEmail = supportEmail; }

    public void setMentorVerificationRequired(boolean mentorVerificationRequired) {
        this.mentorVerificationRequired = mentorVerificationRequired;
    }

	public void setMaxCourseDuration(int i) {
		// TODO Auto-generated method stub
		
	}
}