package com.knowledgeplatform.knowledgeplatform.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.knowledgeplatform.knowledgeplatform.model.LiveSession;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.Review;
import com.knowledgeplatform.knowledgeplatform.model.SessionBooking;
import com.knowledgeplatform.knowledgeplatform.repository.LiveSessionRepository;
import com.knowledgeplatform.knowledgeplatform.repository.MentorRepository;

@Service
public class LiveSessionService {

    @Autowired
    private LiveSessionRepository liveSessionRepository;

    @Autowired
    private MentorRepository mentorProfileRepository;

    @Autowired
    private com.knowledgeplatform.repository.sessionBookingRepository sessionBookingRepository;

    public LiveSession getSessionById(Long sessionId) {
        Optional<LiveSession> session = liveSessionRepository.findById(sessionId);
        return session.orElseThrow(() -> new RuntimeException("Live session not found with id: " + sessionId));
    }

    public List<LiveSession> getUpcomingSessions() {
        return liveSessionRepository.findByScheduledAtAfterAndStatus(LocalDateTime.now(), "AVAILABLE");
    }

    public List<LiveSession> getSessionsByMentor(Long mentorId) {
        return liveSessionRepository.findByMentorIdAndStatus(mentorId, LocalDateTime.now());
    }

    public List<LiveSession> searchSessions(String query) {
        return liveSessionRepository.searchSessions(query);
    }

    public LiveSession createSession(LiveSession session, Long mentorId) {
        Optional<MentorProfile> mentor = mentorProfileRepository.findById(mentorId);
        if (mentor.isPresent()) {
            session.setMentor(mentor.get());
            session.setCreatedAt(LocalDateTime.now());
            session.setUpdatedAt(LocalDateTime.now());
            return liveSessionRepository.save(session);
        }
        throw new RuntimeException("Mentor not found with id: " + mentorId);
    }

    public LiveSession updateSession(Long sessionId, LiveSession sessionDetails) {
        Optional<LiveSession> existingSession = liveSessionRepository.findById(sessionId);
        if (existingSession.isPresent()) {
            LiveSession session = existingSession.get();
            session.setTitle(sessionDetails.getTitle());
            session.setDescription(sessionDetails.getDescription());
            session.setSessionType(sessionDetails.getSessionType());
            session.setScheduledAt(sessionDetails.getScheduledAt());
            session.setDuration(sessionDetails.getDuration());
            session.setPricePerMinute(sessionDetails.getPricePerMinute());
            session.setFixedPrice(sessionDetails.getFixedPrice());
            session.setIsFree(sessionDetails.getIsFree());
            session.setMaxParticipants(sessionDetails.getMaxParticipants());
            session.setStatus(sessionDetails.getStatus());
            session.setUpdatedAt(LocalDateTime.now());
            return liveSessionRepository.save(session);
        }
        throw new RuntimeException("Live session not found with id: " + sessionId);
    }

    public void deleteSession(Long sessionId) {
        Optional<LiveSession> session = liveSessionRepository.findById(sessionId);
        if (session.isPresent()) {
            liveSessionRepository.delete(session.get());
        } else {
            throw new RuntimeException("Live session not found with id: " + sessionId);
        }
    }

    public SessionBooking bookSession(Long sessionId, Long userId) {
        LiveSession session = getSessionById(sessionId);
        
        // Check if session is available
        if (!"AVAILABLE".equals(session.getStatus())) {
            throw new RuntimeException("Session is not available for booking");
        }

        // Check if session has reached maximum participants
        if (session.getCurrentParticipants() >= session.getMaxParticipants()) {
            throw new RuntimeException("Session is fully booked");
        }

        // Create booking
        SessionBooking booking = new SessionBooking();
        booking.setSession(session);
        // Note: You'll need to set the user once you have User entity properly set up
        // booking.setUser(user);
        booking.setBookedAt(LocalDateTime.now());
        booking.setStatus("CONFIRMED");

        // Update session participant count
        session.setCurrentParticipants(session.getCurrentParticipants() + 1);
        liveSessionRepository.save(session);

        return sessionBookingRepository.save(booking);
    }

    public void cancelBooking(Long bookingId) {
        Optional<SessionBooking> booking = sessionBookingRepository.findById(bookingId);
        if (booking.isPresent()) {
            SessionBooking sessionBooking = booking.get();
            LiveSession session = sessionBooking.getSession();
            
            // Update session participant count
            session.setCurrentParticipants(session.getCurrentParticipants() - 1);
            liveSessionRepository.save(session);

            // Update booking status
            sessionBooking.setStatus("CANCELLED");
            sessionBookingRepository.save(sessionBooking);
        } else {
            throw new RuntimeException("Booking not found with id: " + bookingId);
        }
    }

    public List<LiveSession> getAvailableSessions() {
        return liveSessionRepository.findByStatusAndScheduledAtAfter("AVAILABLE", LocalDateTime.now());
    }

    public List<LiveSession> getSessionsByCategory(String category) {
        return liveSessionRepository.findByCategoryAndStatusAndScheduledAtAfter(
            category, "AVAILABLE", LocalDateTime.now());
    }

    public List<LiveSession> getPopularSessions(int limit) {
        return liveSessionRepository.findTopByOrderByTotalBookingsDesc(limit);
    }

    public void incrementViewCount(Long sessionId) {
        Optional<LiveSession> session = liveSessionRepository.findById(sessionId);
        if (session.isPresent()) {
            LiveSession liveSession = session.get();
            liveSession.setTotalViews(liveSession.getTotalViews() + 1);
            liveSessionRepository.save(liveSession);
        }
    }

    public void completeSession(Long sessionId) {
        Optional<LiveSession> session = liveSessionRepository.findById(sessionId);
        if (session.isPresent()) {
            LiveSession liveSession = session.get();
            liveSession.setStatus("COMPLETED");
            liveSession.setUpdatedAt(LocalDateTime.now());
            liveSessionRepository.save(liveSession);
        }
    }

    public List<SessionBooking> getSessionBookings(Long sessionId) {
        return sessionBookingRepository.findBySessionId(sessionId);
    }

    public boolean isUserBookedSession(Long sessionId, Long userId) {
        // This method will need to be implemented once User entity is properly set up
        // return sessionBookingRepository.existsBySessionIdAndUserId(sessionId, userId);
        return false; // Placeholder
    }

	public Long getSessionById1(Long sessionId) {
		// TODO Auto-generated method stub
		return sessionId;
	}

	public com.knowledgeplatform.controller.SessionBooking bookFreeTrial(Long sessionId, Long id) {
		// TODO Auto-generated method stub
		return sessionId;
	}

	public  SessionBooking  public com.knowledgeplatform.model.SessionBooking getBookingById(Long bookingId) {
		// TODO Auto-generated method stub
		return bookingId;
	}

	public com.knowledgeplatform.model.SessionBooking registerForWebinar(Long sessionId, Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Review submitSessionFeedback(Long bookingId, Long id, Integer rating, String comment) {
		// TODO Auto-generated method stub
		return null;
	}

	public void endSession(Long bookingId, Integer duration) {
		// TODO Auto-generated method stub
		
	}

	public void startSession(Long bookingId) {
		// TODO Auto-generated method stub
		
	}

	public SessionBooking bookSession(Long sessionId, Long id, Integer duration) {
		// TODO Auto-generated method stub
		return null;
	}
}