package com.knowledgeplatform.knowledgeplatform.dto;

public class ContentOverview {
    @Override
	public String toString() {
		return "ContentOverview [totalCourses=" + totalCourses + ", publishedCourses=" + publishedCourses
				+ ", draftCourses=" + draftCourses + ", totalMentors=" + totalMentors + ", verifiedMentors="
				+ verifiedMentors + "]";
	}
	public ContentOverview() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ContentOverview(int totalCourses, int publishedCourses, int draftCourses, int totalMentors,
			int verifiedMentors) {
		super();
		this.totalCourses = totalCourses;
		this.publishedCourses = publishedCourses;
		this.draftCourses = draftCourses;
		this.totalMentors = totalMentors;
		this.verifiedMentors = verifiedMentors;
	}
	private long totalCourses;
    public long getTotalCourses() {
		return totalCourses;
	}
	public void setTotalCourses(long totalCourses) {
		this.totalCourses = totalCourses;
	}
	public int getPublishedCourses() {
		return publishedCourses;
	}
	public void setPublishedCourses(int publishedCourses) {
		this.publishedCourses = publishedCourses;
	}
	public int getDraftCourses() {
		return draftCourses;
	}
	public void setDraftCourses(int draftCourses) {
		this.draftCourses = draftCourses;
	}
	public int getTotalMentors() {
		return totalMentors;
	}
	public void setTotalMentors(int totalMentors) {
		this.totalMentors = totalMentors;
	}
	public int getVerifiedMentors() {
		return verifiedMentors;
	}
	public void setVerifiedMentors(int verifiedMentors) {
		this.verifiedMentors = verifiedMentors;
	}
	private int publishedCourses;
    private int draftCourses;
    private int totalMentors;
    private int verifiedMentors;
	private long totalReviews;
	
    public void setTotalReviews(long count) {
        this.totalReviews = count;
    }
    
    // Constructors, getters, setters
}