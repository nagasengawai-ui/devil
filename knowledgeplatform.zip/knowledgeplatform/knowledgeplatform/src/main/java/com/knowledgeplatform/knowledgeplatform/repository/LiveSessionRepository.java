package com.knowledgeplatform.knowledgeplatform.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.LiveSession;

@Repository
public interface LiveSessionRepository extends JpaRepository<LiveSession, Long> {

    // Find live sessions by mentor ID
    List<LiveSession> findByMentorId(Long mentorId);
    
    // Find live sessions by status
    List<LiveSession> findByStatus(String status);
    
    // Find upcoming live sessions
    List<LiveSession> findByStartTimeAfterAndStatus(LocalDateTime startTime, String status);
    
    // Find live sessions by mentor and status
    List<LiveSession> findByMentorIdAndStatus(Long mentorId, LocalDateTime localDateTime);
    
    // Find available (scheduled) live sessions for booking
    @Query("SELECT ls FROM LiveSession ls WHERE ls.status = 'SCHEDULED' AND ls.startTime > :now ORDER BY ls.startTime ASC")
    List<LiveSession> findAvailableSessions(@Param("now") LocalDateTime now);
    
    // Find live sessions starting within a time range
    List<LiveSession> findByStartTimeBetween(LocalDateTime start, LocalDateTime end);
    
    // Count live sessions by mentor and status
    Long countByMentorIdAndStatus(Long mentorId, String status);

	List<LiveSession> findByScheduledAtAfterAndStatus(LocalDateTime now, String string);

	List<LiveSession> searchSessions(String query);
}