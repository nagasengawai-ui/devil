package com.knowledgeplatform.knowledgeplatform.dto;

import java.math.BigDecimal;

public class CourseStats {
    private Long courseId;
    private String courseTitle;
    private String mentorName;
    private int totalEnrollments;
    private BigDecimal totalRevenue;
    private double averageRating;
    private int totalReviews;
    private String status;
    private String category;
	private long totalCourses;
    
    // Constructors
    public CourseStats() {}
    
    public CourseStats(Long courseId, String courseTitle, String mentorName, 
                      int totalEnrollments, BigDecimal totalRevenue, double averageRating, 
                      int totalReviews, String status, String category) {
        this.courseId = courseId;
        this.courseTitle = courseTitle;
        this.mentorName = mentorName;
        this.totalEnrollments = totalEnrollments;
        this.totalRevenue = totalRevenue;
        this.averageRating = averageRating;
        this.totalReviews = totalReviews;
        this.status = status;
        this.category = category;
    }
    
    // Getters and setters
    public Long getCourseId() { return courseId; }
    public void setCourseId(Long courseId) { this.courseId = courseId; }
    
    public String getCourseTitle() { return courseTitle; }
    public void setCourseTitle(String courseTitle) { this.courseTitle = courseTitle; }
    
    public String getMentorName() { return mentorName; }
    public void setMentorName(String mentorName) { this.mentorName = mentorName; }
    
    public int getTotalEnrollments() { return totalEnrollments; }
    public void setTotalEnrollments(int totalEnrollments) { this.totalEnrollments = totalEnrollments; }
    
    public BigDecimal getTotalRevenue() { return totalRevenue; }
    public void setTotalRevenue(BigDecimal totalRevenue) { this.totalRevenue = totalRevenue; }
    
    public double getAverageRating() { return averageRating; }
    public void setAverageRating(double averageRating) { this.averageRating = averageRating; }
    
    public int getTotalReviews() { return totalReviews; }
    public void setTotalReviews(int totalReviews) { this.totalReviews = totalReviews; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

	public void setTotalCourses(long count) {
		// TODO Auto-generated method stub
		this.totalCourses=count;
	}

	public void setPendingApproval(Long countByStatus) {
		// TODO Auto-generated method stub
		this.setPendingApproval(countByStatus);
	}

	public void setPublishedCourses(Long countByStatus) {
		// TODO Auto-generated method stub
		this.setPublishedCourses(countByStatus);
		
	}

	public void setDraftCourses(Long countByStatus) {
		// TODO Auto-generated method stub
		
	}

	public void setRejectedCourses(Long countByStatus) {
		// TODO Auto-generated method stub
		
	}
}