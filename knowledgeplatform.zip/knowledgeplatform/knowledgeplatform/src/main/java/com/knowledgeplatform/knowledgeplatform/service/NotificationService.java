package com.knowledgeplatform.knowledgeplatform.service;

import com.knowledgeplatform.model.Course;
import com.knowledgeplatform.model.LiveSession;
import com.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.model.PlatformNotification;
import com.knowledgeplatform.model.Review;
import com.knowledgeplatform.model.User;
import com.knowledgeplatform.repository.NotificationRepository;
import com.knowledgeplatform.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private UserRepository userRepository;

    @Transactional
    public void notifyFollowersAboutNewCourse(MentorProfile mentor, Course course) {
        try {
            List<User> followers = getMentorFollowers(mentor);
            
            for (User follower : followers) {
                PlatformNotification notification = createNotification(
                    follower,
                    "New Course Available",
                    String.format("%s %s has published a new course: %s", 
                        mentor.getUser().getFirstName(), 
                        mentor.getUser().getLastName(), 
                        course.getTitle()),
                    "NEW_COURSE",
                    course.getId(),
                    "COURSE"
                );
                notificationRepository.save(notification);
            }
        } catch (Exception e) {
            System.err.println("Error notifying followers about new course: " + e.getMessage());
        }
    }

    @Transactional
    public void notifyFollowersAboutNewSession(MentorProfile mentor, LiveSession session) {
        try {
            List<User> followers = getMentorFollowers(mentor);
            
            for (User follower : followers) {
                PlatformNotification notification = createNotification(
                    follower,
                    "New Live Session Scheduled",
                    String.format("%s %s has scheduled a new live session: %s", 
                        mentor.getUser().getFirstName(), 
                        mentor.getUser().getLastName(), 
                        session.getTitle()),
                    "NEW_SESSION",
                    session.getId(),
                    "LIVE_SESSION"
                );
                notificationRepository.save(notification);
            }
        } catch (Exception e) {
            System.err.println("Error notifying followers about new session: " + e.getMessage());
        }
    }

    @Transactional
    public void notifyMentorAboutVerification(MentorProfile mentor, Boolean approved, String notes) {
        try {
            PlatformNotification notification = createNotification(
                mentor.getUser(),
                "Mentor Verification Update",
                approved ? 
                    "Congratulations! Your mentor profile has been verified successfully." :
                    "Your mentor verification request has been rejected. Reason: " + notes,
                "VERIFICATION_STATUS",
                mentor.getId(),
                "MENTOR_PROFILE"
            );
            notificationRepository.save(notification);
        } catch (Exception e) {
            System.err.println("Error notifying mentor about verification: " + e.getMessage());
        }
    }

    @Transactional
    public void notifyEnrollmentConfirmation(User user, Course course) {
        try {
            PlatformNotification notification = createNotification(
                user,
                "Enrollment Confirmed",
                String.format("You have been successfully enrolled in: %s", course.getTitle()),
                "ENROLLMENT_CONFIRMATION",
                course.getId(),
                "COURSE"
            );
            notificationRepository.save(notification);
        } catch (Exception e) {
            System.err.println("Error notifying enrollment confirmation: " + e.getMessage());
        }
    }

    @Transactional
    public void notifyMentorAboutEnrollment(MentorProfile mentor, Course course, User student) {
        try {
            PlatformNotification notification = createNotification(
                mentor.getUser(),
                "New Student Enrollment",
                String.format("%s %s has enrolled in your course: %s", 
                    student.getFirstName(), student.getLastName(), course.getTitle()),
                "NEW_ENROLLMENT",
                course.getId(),
                "COURSE"
            );
            notificationRepository.save(notification);
        } catch (Exception e) {
            System.err.println("Error notifying mentor about enrollment: " + e.getMessage());
        }
    }

    @Transactional
    public void notifyCourseCompletion(User user, Course course) {
        try {
            PlatformNotification notification = createNotification(
                user,
                "Course Completed!",
                String.format("Congratulations! You have completed the course: %s", course.getTitle()),
                "COURSE_COMPLETION",
                course.getId(),
                "COURSE"
            );
            notificationRepository.save(notification);
        } catch (Exception e) {
            System.err.println("Error notifying course completion: " + e.getMessage());
        }
    }

    @Transactional
    public void notifyNewReview(MentorProfile mentor, Review review) {
        try {
            PlatformNotification notification = createNotification(
                mentor.getUser(),
                "New Review Received",
                String.format("You have received a new %d-star review", review.getRating()),
                "NEW_REVIEW",
                review.getId(),
                "REVIEW"
            );
            notificationRepository.save(notification);
        } catch (Exception e) {
            System.err.println("Error notifying about new review: " + e.getMessage());
        }
    }

    @Transactional
    public void notifyAdminForCourseReview(Course course) {
        try {
            List<User> adminUsers = userRepository.findByRoleContaining("ROLE_ADMIN");
            
            for (User admin : adminUsers) {
                PlatformNotification notification = createNotification(
                    admin,
                    "Course Pending Review",
                    String.format("Course '%s' by %s %s is pending review", 
                        course.getTitle(),
                        course.getMentor().getUser().getFirstName(),
                        course.getMentor().getUser().getLastName()),
                    "COURSE_REVIEW",
                    course.getId(),
                    "COURSE"
                );
                notificationRepository.save(notification);
            }
        } catch (Exception e) {
            System.err.println("Error notifying admin for course review: " + e.getMessage());
        }
    }

    @Transactional
    public void notifyMentorAboutCourseApproval(MentorProfile mentor, Course course) {
        try {
            PlatformNotification notification = createNotification(
                mentor.getUser(),
                "Course Published",
                String.format("Your course '%s' has been approved and published successfully", course.getTitle()),
                "COURSE_APPROVED",
                course.getId(),
                "COURSE"
            );
            notificationRepository.save(notification);
        } catch (Exception e) {
            System.err.println("Error notifying mentor about course approval: " + e.getMessage());
        }
    }

    @Transactional
    public void notifyMentorAboutCourseRejection(MentorProfile mentor, Course course, String reason) {
        try {
            PlatformNotification notification = createNotification(
                mentor.getUser(),
                "Course Rejected",
                String.format("Your course '%s' was rejected. Reason: %s", course.getTitle(), reason),
                "COURSE_REJECTED",
                course.getId(),
                "COURSE"
            );
            notificationRepository.save(notification);
        } catch (Exception e) {
            System.err.println("Error notifying mentor about course rejection: " + e.getMessage());
        }
    }

    // Additional notification methods
    @Transactional
    public void notifyUserRegistration(User user) {
        PlatformNotification notification = createNotification(
            user,
            "Welcome to Knowledge Platform!",
            "Thank you for registering with us. Start your learning journey today!",
            "WELCOME",
            user.getId(),
            "USER"
        );
        notificationRepository.save(notification);
    }

    @Transactional
    public void notifyUserStatusChange(User user, String previousStatus, String newStatus, String reason) {
        PlatformNotification notification = createNotification(
            user,
            "Account Status Updated",
            String.format("Your account status has been changed from %s to %s. Reason: %s", previousStatus, newStatus, reason),
            "ACCOUNT_STATUS",
            user.getId(),
            "USER"
        );
        notificationRepository.save(notification);
    }

    @Transactional
    public void notifyEmailVerification(User user) {
        PlatformNotification notification = createNotification(
            user,
            "Email Verified",
            "Your email has been successfully verified.",
            "EMAIL_VERIFIED",
            user.getId(),
            "USER"
        );
        notificationRepository.save(notification);
    }

    @Transactional
    public void notifyWalletTransaction(User user, Double amount, String type, String description) {
        PlatformNotification notification = createNotification(
            user,
            "Wallet Transaction",
            String.format("%s: $%.2f - %s", type, amount, description),
            "WALLET_TRANSACTION",
            user.getId(),
            "USER"
        );
        notificationRepository.save(notification);
    }

    public List<PlatformNotification> getUserNotifications(Long userId) {
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public Long getUnreadNotificationsCount(Long userId) {
        return notificationRepository.countByUserIdAndIsReadFalse(userId);
    }

    public List<PlatformNotification> getRecentNotifications(Long userId) {
        LocalDateTime weekAgo = LocalDateTime.now().minusDays(7);
        return notificationRepository.findByUserIdAndCreatedAtAfterOrderByCreatedAtDesc(userId, weekAgo);
    }

    @Transactional
    public void markAsRead(Long notificationId) {
        try {
            notificationRepository.findById(notificationId).ifPresent(notification -> {
                notification.setIsRead(true);
                notificationRepository.save(notification);
            });
        } catch (Exception e) {
            System.err.println("Error marking notification as read: " + e.getMessage());
        }
    }

    @Transactional
    public void markAllAsRead(Long userId) {
        try {
            List<PlatformNotification> unreadNotifications = notificationRepository.findByUserIdAndIsReadFalse(userId);
            for (PlatformNotification notification : unreadNotifications) {
                notification.setIsRead(true);
                notificationRepository.save(notification);
            }
        } catch (Exception e) {
            System.err.println("Error marking all notifications as read: " + e.getMessage());
        }
    }

    @Transactional
    public void deleteNotification(Long notificationId) {
        try {
            notificationRepository.deleteById(notificationId);
        } catch (Exception e) {
            System.err.println("Error deleting notification: " + e.getMessage());
        }
    }

    @Transactional
    public void clearAllNotifications(Long userId) {
        try {
            notificationRepository.deleteByUserId(userId);
        } catch (Exception e) {
            System.err.println("Error clearing all notifications: " + e.getMessage());
        }
    }

    @Transactional
    public PlatformNotification createCustomNotification(User user, String title, String message, String type, 
                                               Long relatedEntityId, String relatedEntityType) {
        try {
            return createNotification(user, title, message, type, relatedEntityId, relatedEntityType);
        } catch (Exception e) {
            System.err.println("Error creating custom notification: " + e.getMessage());
            return null;
        }
    }

    private PlatformNotification createNotification(User user, String title, String message, String type, 
                                                   Long relatedEntityId, String relatedEntityType) {
        PlatformNotification notification = new PlatformNotification();
        notification.setUser(user);
        notification.setTitle(title);
        notification.setMessage(message);
        notification.setType(type);
        notification.setRelatedEntityId(relatedEntityId);
        notification.setRelatedEntityType(relatedEntityType);
        notification.setIsRead(false);
        notification.setCreatedAt(LocalDateTime.now());
        return notification;
    }

    private List<User> getMentorFollowers(MentorProfile mentor) {
        return List.of(); // Placeholder - implement follower logic
    }
}