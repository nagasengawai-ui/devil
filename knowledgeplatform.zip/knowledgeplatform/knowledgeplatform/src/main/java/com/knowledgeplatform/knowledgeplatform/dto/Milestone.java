package com.knowledgeplatform.knowledgeplatform.dto;

public class Milestone {
    @Override
	public String toString() {
		return "Milestone [title=" + title + ", description=" + description + ", completed=" + completed + "]";
	}
	public Milestone(String title, String description, boolean completed) {
		super();
		this.title = title;
		this.description = description;
		this.completed = completed;
	}

	private String title;
    public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public boolean isCompleted() {
		return completed;
	}
	public void setCompleted(boolean completed) {
		this.completed = completed;
	}
	private String description;
    private boolean completed;
	public void setOrder(int order) {
		// TODO Auto-generated method stub
		this.setOrder(order);
		
	}
    
    // Constructors, getters, setters
}