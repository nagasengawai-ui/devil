package com.knowledgeplatform.knowledgeplatform.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.AvailabilitySchedule;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;

@Repository
public interface MentorRepository extends JpaRepository<MentorProfile, Long> {
    
    // Basic count methods
    Long countByIsVerified(boolean isVerified);
    Long countByVerificationStatus(String verificationStatus);
    
    // Find by user ID
    Optional<MentorProfile> findByUserId(Long userId);
    
    // Find by various statuses
    List<MentorProfile> findByIsVerified(boolean isVerified);
    List<MentorProfile> findByVerificationStatus(String verificationStatus);
    List<MentorProfile> findByStatus(String status);
    
    // Find by availability
    List<MentorProfile> findByIsAvailable(boolean isAvailable);
    

    @OneToMany(mappedBy = "mentor", cascade = CascadeType.ALL, fetch = FetchType.LAZY) List<AvailabilitySchedule> availabilitySchedules = new ArrayList<>();

    
    // Complex queries with @Query
    @Query("SELECT COUNT(m) FROM MentorProfile m WHERE m.isVerified = true AND m.isAvailable = true")
    Long countAvailableVerifiedMentors();
    
    @Query("SELECT m FROM MentorProfile m WHERE m.averageRating >= :minRating ORDER BY m.averageRating DESC")
    List<MentorProfile> findTopRatedMentors(@Param("minRating") double minRating);
    
    @Query("SELECT m FROM MentorProfile m WHERE m.yearsOfExperience >= :minExperience")
    List<MentorProfile> findByMinExperience(@Param("minExperience") int minExperience);
    
    // Search by expertise area (if you have expertise relationship)
    @Query("SELECT DISTINCT m FROM MentorProfile m JOIN m.expertiseAreas e WHERE e LIKE %:expertise%")
    List<MentorProfile> findByExpertiseContaining(@Param("expertise") String expertise);
    
    // Count mentors with courses
    @Query("SELECT COUNT(DISTINCT m) FROM MentorProfile m JOIN m.courses c WHERE c.status = 'PUBLISHED'")
    Long countMentorsWithPublishedCourses();
    
    // Find mentors with the highest earnings
    @Query("SELECT m FROM MentorProfile m ORDER BY m.totalEarnings DESC")
    List<MentorProfile> findTopEarningMentors();
	List<MentorProfile> findByUser_FirstNameContainingOrUser_LastNameContainingOrProfessionalTitleContaining(
			String search, String search2, String search3);
	List<MentorProfile> findByExpertiseAreasContaining(String category);
	List<MentorProfile> findTop10ByOrderByAverageRatingDesc();
}