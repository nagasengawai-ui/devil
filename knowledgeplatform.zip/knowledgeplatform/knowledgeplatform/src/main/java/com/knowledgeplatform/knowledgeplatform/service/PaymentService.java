package com.knowledgeplatform.knowledgeplatform.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.knowledgeplatform.knowledgeplatform.dto.PlatformRevenue;
import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.FinancialTransaction;
import com.knowledgeplatform.knowledgeplatform.model.LiveSession;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.repository.FinancialTransactionRepository;

@Service
@Transactional
public class PaymentService {

    @Autowired
    private UserService userService;

    @Autowired
    private MentorService mentorService;

    @Autowired
    private FinancialTransactionRepository transactionRepository;

    private static final Double PLATFORM_COMMISSION = 0.20;

    @Transactional
    public Double processCoursePayment(User user, Course course) {
        Double amount = course.getCurrentPrice();

        if (user.getWalletBalance() < amount) {
            throw new RuntimeException("Insufficient wallet balance");
        }

        user.setWalletBalance(user.getWalletBalance() - amount);
        userService.updateUser(user.getId(), user);

        Double mentorEarnings = amount * (1 - PLATFORM_COMMISSION);
        
        MentorProfile mentor = course.getMentor();
        mentor.addEarning(mentorEarnings);
        mentorService.updateMentorProfile(mentor.getId(), mentor);

        recordTransaction(user, amount, "COURSE_PURCHASE", 
                         "Purchase: " + course.getTitle(), course.getMentor().getId());

        return amount;
    }

    @Transactional
    public Double processSessionPayment(User user, LiveSession session, Integer durationMinutes) {
        Double amount = session.calculateCost(durationMinutes);

        if (user.getWalletBalance() < amount) {
            throw new RuntimeException("Insufficient wallet balance");
        }

        user.setWalletBalance(user.getWalletBalance() - amount);
        userService.updateUser(user.getId(), user);

        Double mentorEarnings = amount * (1 - PLATFORM_COMMISSION);
        
        MentorProfile mentor = session.getMentor();
        mentor.addEarning(mentorEarnings);
        mentorService.updateMentorProfile(mentor.getId(), mentor);

        recordTransaction(user, amount, "SESSION_PAYMENT", 
                         String.format("Session: %s (%d mins)", session.getTitle(), durationMinutes), 
                         session.getMentor().getId());

        return amount;
    }

    @Transactional
    public void processMentorPayout(Long mentorId, Double amount) {
        MentorProfile mentor = mentorService.getMentorById(mentorId);

        if (mentor.getAvailableBalance() < amount) {
            throw new RuntimeException("Insufficient balance for payout");
        }

        if (amount < 50.0) {
            throw new RuntimeException("Minimum payout amount is $50");
        }

        mentor.setAvailableBalance(mentor.getAvailableBalance() - amount);
        mentorService.updateMentorProfile(mentorId, mentor);

        processExternalPayout(mentor, amount);
        recordPayoutTransaction(mentor, amount);
    }

    @Transactional
    public User topUpWallet(Long userId, Double amount, String paymentMethod) {
        if (amount <= 0) {
            throw new RuntimeException("Amount must be greater than 0");
        }

        String transactionId = processExternalPayment(amount, paymentMethod);
        User user = userService.addToWallet(userId, amount);
        recordTransaction(user, amount, "WALLET_TOPUP", "Wallet top-up via " + paymentMethod, null);

        return user;
    }

    public PlatformRevenue getPlatformRevenue() {
        PlatformRevenue revenue = new PlatformRevenue();
        
        revenue.setTotalRevenue(transactionRepository.getTotalRevenue());
        revenue.setTodayRevenue(transactionRepository.getRevenueSince(LocalDateTime.now().withHour(0).withMinute(0).withSecond(0)));
        revenue.setMonthlyRevenue(transactionRepository.getRevenueSince(LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0)));
        revenue.setPlatformCommission(transactionRepository.getTotalCommission());
        revenue.setActiveSubscriptions(0);
        revenue.setPendingPayouts(0.0);

        return revenue;
    }

    private void recordTransaction(User user, Double amount, String type, String description, Long mentorId) {
        FinancialTransaction transaction = new FinancialTransaction();
        transaction.setUser(user);
        transaction.setAmount(amount);
        transaction.setTransactionType(type);
        transaction.setDescription(description);
        transaction.setStatus("COMPLETED");
        transaction.setPlatformCommission(amount * PLATFORM_COMMISSION);
        transaction.setMentorEarnings(amount * (1 - PLATFORM_COMMISSION));
        transaction.setMentorId(mentorId);
        transaction.setCreatedAt(LocalDateTime.now());
        transaction.setUpdatedAt(LocalDateTime.now());
        
        transactionRepository.save(transaction);
    }

    private void recordPayoutTransaction(MentorProfile mentor, Double amount) {
        FinancialTransaction transaction = new FinancialTransaction();
        transaction.setUser(mentor.getUser());
        transaction.setAmount(amount);
        transaction.setTransactionType("PAYOUT");
        transaction.setDescription("Payout to mentor");
        transaction.setStatus("COMPLETED");
        transaction.setMentorId(mentor.getId());
        transaction.setCreatedAt(LocalDateTime.now());
        transaction.setUpdatedAt(LocalDateTime.now());
        
        transactionRepository.save(transaction);
    }

    private String processExternalPayment(Double amount, String paymentMethod) {
        return "txn_" + System.currentTimeMillis();
    }

    private void processExternalPayout(MentorProfile mentor, Double amount) {
        // Integration with payout gateway
    }
}