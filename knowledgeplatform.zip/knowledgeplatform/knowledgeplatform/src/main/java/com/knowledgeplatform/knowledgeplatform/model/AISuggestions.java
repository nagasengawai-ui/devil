package com.knowledgeplatform.knowledgeplatform.model;

import java.util.List;

//DTO classes for AI service
public class AISuggestions {
 private List<Course> recommendedCourses;
 private List<MentorProfile> recommendedMentors;
 private List<LiveSession> recommendedSessions;
 private List<com.knowledgeplatform.knowledgeplatform.dto.LearningPath> learningPaths;

 // Getters and setters
 public List<Course> getRecommendedCourses() { return recommendedCourses; }
 public List<MentorProfile> getRecommendedMentors() { return recommendedMentors; }
 public void setRecommendedMentors(List<MentorProfile> recommendedMentors) { this.recommendedMentors = recommendedMentors; }
 public List<LiveSession> getRecommendedSessions() { return recommendedSessions; }
 public void setRecommendedSessions(List<LiveSession> recommendedSessions) { this.recommendedSessions = recommendedSessions; }
 public List<com.knowledgeplatform.knowledgeplatform.dto.LearningPath> getLearningPaths() { return learningPaths; }
 public void setLearningPaths(List<com.knowledgeplatform.knowledgeplatform.dto.LearningPath> learningPaths) { this.learningPaths = learningPaths; }
public void setRecommendedCourses(List<Course> recommendedCourses2) {
	// TODO Auto-generated method stub
	
}
}