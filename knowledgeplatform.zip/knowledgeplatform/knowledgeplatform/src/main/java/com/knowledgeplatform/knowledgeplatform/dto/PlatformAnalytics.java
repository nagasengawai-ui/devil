package com.knowledgeplatform.knowledgeplatform.dto;

import java.awt.FontMetrics;
import java.math.BigDecimal;

import com.knowledgeplatform.knowledgeplatform.model.ContentAnalytics;
import com.knowledgeplatform.knowledgeplatform.model.RevenueAnalytics;
import com.knowledgeplatform.knowledgeplatform.model.UserGrowth;

public class PlatformAnalytics {
    public PlatformAnalytics(int totalUsers, int totalMentors, int totalCourses, int totalEnrollments,
			BigDecimal totalRevenue, int activeSessions) {
		super();
		this.totalUsers = totalUsers;
		this.totalMentors = totalMentors;
		this.totalCourses = totalCourses;
		this.totalEnrollments = totalEnrollments;
		this.totalRevenue = totalRevenue;
		this.activeSessions = activeSessions;
	}

	private int totalUsers;
    private int totalMentors;
    private int totalCourses;
    public int getTotalUsers() {
		return totalUsers;
	}

	public void setTotalUsers(int totalUsers) {
		this.totalUsers = totalUsers;
	}

	public int getTotalMentors() {
		return totalMentors;
	}

	public void setTotalMentors(int totalMentors) {
		this.totalMentors = totalMentors;
	}

	public int getTotalCourses() {
		return totalCourses;
	}

	public void setTotalCourses(int totalCourses) {
		this.totalCourses = totalCourses;
	}

	public int getTotalEnrollments() {
		return totalEnrollments;
	}

	public void setTotalEnrollments(int totalEnrollments) {
		this.totalEnrollments = totalEnrollments;
	}

	public BigDecimal getTotalRevenue() {
		return totalRevenue;
	}

	public void setTotalRevenue(BigDecimal totalRevenue) {
		this.totalRevenue = totalRevenue;
	}

	public int getActiveSessions() {
		return activeSessions;
	}

	public void setActiveSessions(int activeSessions) {
		this.activeSessions = activeSessions;
	}

	private int totalEnrollments;
    private BigDecimal totalRevenue;
    private int activeSessions;
	private FontMetrics FontMetrics;
    
    // Constructors, getters, setters
    public PlatformAnalytics() {}

	public void setUserGrowth(UserGrowth userGrowth) {
		// TODO Auto-generated method stub
		this.setUserGrowth(userGrowth);
		
	}

	public void setEngagementMetrics(FontMetrics fontMetrics) {
		// TODO Auto-generated method stub
		this.FontMetrics=fontMetrics;
	}

	public void setRevenueAnalytics(RevenueAnalytics revenueAnalytics) {
		// TODO Auto-generated method stub
		this.setRevenueAnalytics(revenueAnalytics);
		
	}

	public void setContentAnalytics(ContentAnalytics contentAnalytics) {
		// TODO Auto-generated method stub
		this.setContentAnalytics(contentAnalytics);
	}
    
    // Add constructor and getters/setters
}