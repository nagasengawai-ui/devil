package com.knowledgeplatform.knowledgeplatform.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

public class CourseProgress {
    public CourseProgress(@NotNull @Min(0) @Max(100) Double progressPercentage,
			@NotNull @Min(0) Integer completedLectures, @NotNull @Min(0) Integer totalLectures,
			LocalDateTime lastActivity, @NotNull @Min(0) Long timeSpent) {
		super();
		this.progressPercentage = progressPercentage;
		this.completedLectures = completedLectures;
		this.totalLectures = totalLectures;
		this.lastActivity = lastActivity;
		this.timeSpent = timeSpent;
	}
	@NotNull @Min(0) @Max(100)
    private Double progressPercentage;
    
    @NotNull @Min(0)
    private Integer completedLectures;
    
    @NotNull @Min(0)
    private Integer totalLectures;
    
    private LocalDateTime lastActivity;
    
    @NotNull @Min(0)
    private Long timeSpent;

    // Getters and setters
    public Double getProgressPercentage() { return progressPercentage; }
    public void setProgressPercentage(Double progressPercentage) { this.progressPercentage = progressPercentage; }
    public Integer getCompletedLectures() { return completedLectures; }
    public void setCompletedLectures(Integer completedLectures) { this.completedLectures = completedLectures; }
    public Integer getTotalLectures() { return totalLectures; }
    public void setTotalLectures(Integer totalLectures) { this.totalLectures = totalLectures; }
    public LocalDateTime getLastActivity() { return lastActivity; }
    public void setLastActivity(LocalDateTime lastActivity) { this.lastActivity = lastActivity; }
    public Long getTimeSpent() { return timeSpent; }
    public void setTimeSpent(Long timeSpent) { this.timeSpent = timeSpent; }
}