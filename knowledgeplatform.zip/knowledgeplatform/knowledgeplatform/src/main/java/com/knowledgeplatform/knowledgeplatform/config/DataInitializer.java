package com.knowledgeplatform.knowledgeplatform.config;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.knowledgeplatform.knowledgeplatform.model.Course;






import com.knowledgeplatform.knowledgeplatform.config.*;
import com.knowledgeplatform.knowledgeplatform.controller.*;
import com.knowledgeplatform.knowledgeplatform.dto.*;
import com.knowledgeplatform.knowledgeplatform.model.*;
import com.knowledgeplatform.knowledgeplatform.repository.*;
import com.knowledgeplatform.knowledgeplatform.service.*;






@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserService userService;

    @Autowired
    private MentorService mentorService;

    @Autowired
    private CourseService courseService;

    @Override
    public void run(String... args) throws Exception {
        createSampleData();
    }

    private void createSampleData() {
        // Create sample admin user
        User admin = new User("admin@platform.com", "admin123", "Platform", "Admin");
        admin.setRole("ADMIN");
        userService.registerUser(admin);

        // Create sample mentor
        User mentorUser = new User("mentor@example.com", "mentor123", "John", "Doe");
        userService.registerUser(mentorUser);

        MentorProfile mentorProfile = new MentorProfile(mentorUser);
        mentorProfile.setProfessionalTitle("Business Consultant");
        mentorProfile.setBio("10+ years of experience in business strategy and consulting");
        mentorProfile.setExpertiseAreas(List.of("Business", "Strategy", "Consulting"));
        mentorProfile.setSkills(List.of("Business Planning", "Market Analysis", "Strategic Planning"));
        mentorProfile.setIsVerified(true);
        mentorService.becomeMentor(mentorUser.getId(), mentorProfile);

        // Create sample course
        Course course = new Course(
            "Business Strategy Fundamentals",
            "Learn the core principles of business strategy and how to apply them in real-world scenarios",
            mentorProfile
        );
        course.setCategory("Business");
        course.setLevel("Beginner");
        course.setPrice(99.99);
        course.setStatus("PUBLISHED");
        courseService.createCourse(mentorProfile.getId(), course);
    }
}