package com.knowledgeplatform.knowledgeplatform.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.knowledgeplatform.knowledgeplatform.dto.MentorEarnings;
import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.LiveSession;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.repository.CourseRepository;
import com.knowledgeplatform.knowledgeplatform.repository.LiveSessionRepository;
import com.knowledgeplatform.knowledgeplatform.repository.MentorRepository;
import com.knowledgeplatform.knowledgeplatform.repository.UserRepository;

@Service
@Transactional
public class MentorService {

    @Autowired
    private MentorRepository mentorRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private LiveSessionRepository liveSessionRepository;

    @Autowired
    private NotificationService notificationService;

    public MentorProfile getMentorById(Long mentorId) {
        return mentorRepository.findById(mentorId)
                .orElseThrow(() -> new RuntimeException("Mentor not found with id: " + mentorId));
    }

    public MentorProfile getMentorByUserId(Long userId) {
        return mentorRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Mentor not found for user id: " + userId));
    }

    @Transactional
    public MentorProfile becomeMentor(Long userId, MentorProfile mentorProfile) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        if (mentorRepository.findByUserId(userId).isPresent()) {
            throw new RuntimeException("User is already a mentor");
        }

        mentorProfile.setUser(user);
        mentorProfile.setIsVerified(false);
        mentorProfile.setVerificationStatus("PENDING");
        mentorProfile.setAverageRating(0.0);
        mentorProfile.setTotalEarnings(0.0);
        mentorProfile.setAvailableBalance(0.0);
        mentorProfile.setLifetimeEarnings(0.0);
        mentorProfile.setCreatedAt(LocalDateTime.now());
        mentorProfile.setUpdatedAt(LocalDateTime.now());

        MentorProfile savedMentor = mentorRepository.save(mentorProfile);

        user.setRole("ROLE_MENTOR");
        userRepository.save(user);

        return savedMentor;
    }

    @Transactional
    public MentorProfile updateMentorProfile(Long mentorId, MentorProfile updatedProfile) {
        MentorProfile existingProfile = getMentorById(mentorId);

        if (updatedProfile.getExpertiseAreas() != null) {
            existingProfile.setExpertiseAreas(updatedProfile.getExpertiseAreas());
        }
        if (updatedProfile.getSkills() != null) {
            existingProfile.setSkills(updatedProfile.getSkills());
        }
        if (updatedProfile.getProfessionalTitle() != null) {
            existingProfile.setProfessionalTitle(updatedProfile.getProfessionalTitle());
        }
        if (updatedProfile.getBio() != null) {
            existingProfile.setBio(updatedProfile.getBio());
        }
        if (updatedProfile.getVideoIntroductionUrl() != null) {
            existingProfile.setVideoIntroductionUrl(updatedProfile.getVideoIntroductionUrl());
        }
        if (updatedProfile.getOffersCourses() != null) {
            existingProfile.setOffersCourses(updatedProfile.getOffersCourses());
        }
        if (updatedProfile.getOffersMentoring() != null) {
            existingProfile.setOffersMentoring(updatedProfile.getOffersMentoring());
        }
        if (updatedProfile.getOffersWebinars() != null) {
            existingProfile.setOffersWebinars(updatedProfile.getOffersWebinars());
        }
        if (updatedProfile.getCourseBasePrice() != null) {
            existingProfile.setCourseBasePrice(updatedProfile.getCourseBasePrice());
        }
        if (updatedProfile.getMentoringRatePerMinute() != null) {
            existingProfile.setMentoringRatePerMinute(updatedProfile.getMentoringRatePerMinute());
        }
        if (updatedProfile.getWebinarBasePrice() != null) {
            existingProfile.setWebinarBasePrice(updatedProfile.getWebinarBasePrice());
        }
        if (updatedProfile.getTimezone() != null) {
            existingProfile.setTimezone(updatedProfile.getTimezone());
        }
        if (updatedProfile.getAvailabilitySchedule() != null) {
            existingProfile.setAvailabilitySchedule(updatedProfile.getAvailabilitySchedule());
        }
        if (updatedProfile.getCompany() != null) {
            existingProfile.setCompany(updatedProfile.getCompany());
        }
        if (updatedProfile.getWebsite() != null) {
            existingProfile.setWebsite(updatedProfile.getWebsite());
        }
        if (updatedProfile.getSocialLinks() != null) {
            existingProfile.setSocialLinks(updatedProfile.getSocialLinks());
        }
        if (updatedProfile.getTotalStudents() != null) {
            existingProfile.setTotalStudents(updatedProfile.getTotalStudents());
        }

        existingProfile.setUpdatedAt(LocalDateTime.now());
        return mentorRepository.save(existingProfile);
    }

    @Transactional
    public Course createCourse(Long mentorId, Course course) {
        MentorProfile mentor = getMentorById(mentorId);
        
        course.setMentor(mentor);
        course.setStatus("DRAFT");
        course.setCreatedAt(LocalDateTime.now());
        course.setUpdatedAt(LocalDateTime.now());

        Course savedCourse = courseRepository.save(course);
        notificationService.notifyFollowersAboutNewCourse(mentor, savedCourse);
        return savedCourse;
    }

    @Transactional
    public Course updateCourse(Long mentorId, Long courseId, Course updatedCourse) {
        MentorProfile mentor = getMentorById(mentorId);
        Course existingCourse = courseRepository.findByIdAndMentorId(courseId, mentorId)
                .orElseThrow(() -> new RuntimeException("Course not found or access denied"));

        if (updatedCourse.getTitle() != null) {
            existingCourse.setTitle(updatedCourse.getTitle());
        }
        if (updatedCourse.getDescription() != null) {
            existingCourse.setDescription(updatedCourse.getDescription());
        }
        if (updatedCourse.getCategory() != null) {
            existingCourse.setCategory(updatedCourse.getCategory());
        }
        if (updatedCourse.getPrice() != null) {
            existingCourse.setPrice(updatedCourse.getPrice());
        }
        if (updatedCourse.getLevel() != null) {
            existingCourse.setLevel(updatedCourse.getLevel());
        }
        if (updatedCourse.getThumbnailUrl() != null) {
            existingCourse.setThumbnailUrl(updatedCourse.getThumbnailUrl());
        }

        existingCourse.setUpdatedAt(LocalDateTime.now());
        return courseRepository.save(existingCourse);
    }

    @Transactional
    public LiveSession createLiveSession(Long mentorId, LiveSession session) {
        MentorProfile mentor = getMentorById(mentorId);
        
        session.setMentor(mentor);
        session.setStatus("SCHEDULED");
        session.setCreatedAt(LocalDateTime.now());
        session.setUpdatedAt(LocalDateTime.now());

        LiveSession savedSession = liveSessionRepository.save(session);
        notificationService.notifyFollowersAboutNewSession(mentor, savedSession);
        return savedSession;
    }

    public List<Course> getMentorCourses(Long mentorId) {
        return courseRepository.findByMentorId(mentorId);
    }

    public List<LiveSession> getMentorLiveSessions(Long mentorId) {
        return liveSessionRepository.findByMentorId(mentorId);
    }

    public MentorEarnings getMentorEarnings(Long mentorId) {
        MentorProfile mentor = getMentorById(mentorId);
        
        MentorEarnings earnings = new MentorEarnings();
        earnings.setTotalEarnings(mentor.getTotalEarnings() != null ? mentor.getTotalEarnings() : 0.0);
        earnings.setAvailableBalance(mentor.getAvailableBalance() != null ? mentor.getAvailableBalance() : 0.0);
        earnings.setLifetimeEarnings(mentor.getLifetimeEarnings() != null ? mentor.getLifetimeEarnings() : 0.0);
        
        Double recentEarnings = calculateRecentEarnings(mentorId);
        earnings.setRecentEarnings(recentEarnings);
        
        earnings.setNextPayoutDate(calculateNextPayoutDate());
        earnings.setIsEligibleForPayout(mentor.getAvailableBalance() != null && mentor.getAvailableBalance() >= 50.0);

        return earnings;
    }

    public List<MentorProfile> searchMentors(String query, String category, String expertise) {
        if (query != null && !query.trim().isEmpty()) {
            return mentorRepository.findByUser_FirstNameContainingOrUser_LastNameContainingOrProfessionalTitleContaining(query, query, query);
        } else if (category != null && !category.trim().isEmpty()) {
            return mentorRepository.findByExpertiseAreasContaining(category);
        } else {
            return mentorRepository.findTop10ByOrderByAverageRatingDesc();
        }
    }

    @Transactional
    public MentorProfile verifyMentor(Long mentorId, Boolean approved, String notes) {
        MentorProfile mentor = getMentorById(mentorId);
        
        mentor.setIsVerified(approved);
        mentor.setVerificationStatus(approved ? "APPROVED" : "REJECTED");
        mentor.setVerificationNotes(notes);
        mentor.setVerifiedAt(LocalDateTime.now());
        mentor.setUpdatedAt(LocalDateTime.now());

        MentorProfile updatedMentor = mentorRepository.save(mentor);
        notificationService.notifyMentorAboutVerification(updatedMentor, approved, notes);
        return updatedMentor;
    }

    public List<MentorProfile> getPendingVerificationMentors() {
        return mentorRepository.findByVerificationStatus("PENDING");
    }

    private Double calculateRecentEarnings(Long mentorId) {
        LocalDateTime thirtyDaysAgo = LocalDateTime.now().minusDays(30);
        return 0.0; // Placeholder - implement based on transaction repository
    }

    private LocalDateTime calculateNextPayoutDate() {
        return LocalDateTime.now().plusMonths(1).withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
    }

	public List<Course> getCoursesByMentor(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}