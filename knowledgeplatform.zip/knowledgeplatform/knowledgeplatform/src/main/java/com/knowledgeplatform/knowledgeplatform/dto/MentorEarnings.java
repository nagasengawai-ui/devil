package com.knowledgeplatform.knowledgeplatform.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class MentorEarnings {
    private double totalEarnings;
    private double availableBalance;
    public double getTotalEarnings() {
		return totalEarnings;
	}
	public void setTotalEarnings(double d) {
		this.totalEarnings = d;
	}
	public double getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(double d) {
		this.availableBalance = d;
	}
	public BigDecimal getPendingBalance() {
		return pendingBalance;
	}
	public void setPendingBalance(BigDecimal pendingBalance) {
		this.pendingBalance = pendingBalance;
	}
	public LocalDateTime getLastPayoutDate() {
		return lastPayoutDate;
	}
	public void setLastPayoutDate(LocalDateTime lastPayoutDate) {
		this.lastPayoutDate = lastPayoutDate;
	}
	private BigDecimal pendingBalance;
    private LocalDateTime lastPayoutDate;
	public void setLifetimeEarnings(double d) {
		// TODO Auto-generated method stub
		this.setLifetimeEarnings(d);
		
	}
	public void setRecentEarnings(Double recentEarnings) {
		// TODO Auto-generated method stub
		this.setRecentEarnings(recentEarnings);
		
	}
	public void setNextPayoutDate(LocalDateTime calculateNextPayoutDate) {
		// TODO Auto-generated method stub
		this.setNextPayoutDate(calculateNextPayoutDate);
		
		
	}
	public void setIsEligibleForPayout(boolean b) {
		// TODO Auto-generated method stub
		this.setIsEligibleForPayout(b);
		
	}
    
    // Constructors, getters, setters
}