package com.knowledgeplatform.knowledgeplatform.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.knowledgeplatform.knowledgeplatform.dto.UserStats;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.repository.UserRepository;

@Service
@Transactional
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private NotificationService notificationService;

    public User getUserById(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));
    }

    public User createUser(User user) {
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new RuntimeException("Email already registered: " + user.getEmail());
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        User savedUser = userRepository.save(user);
        notificationService.notifyUserRegistration(savedUser);
        return savedUser;
    }

    public User updateUser(Long userId, User updatedUser) {
        User existingUser = getUserById(userId);

        if (updatedUser.getFirstName() != null) {
            existingUser.setFirstName(updatedUser.getFirstName());
        }
        if (updatedUser.getLastName() != null) {
            existingUser.setLastName(updatedUser.getLastName());
        }
        if (updatedUser.getPhone() != null) {
            existingUser.setPhone(updatedUser.getPhone());
        }
        if (updatedUser.getCountry() != null) {
            existingUser.setCountry(updatedUser.getCountry());
        }
        if (updatedUser.getCity() != null) {
            existingUser.setCity(updatedUser.getCity());
        }
        if (updatedUser.getBio() != null) {
            existingUser.setBio(updatedUser.getBio());
        }
        if (updatedUser.getProfilePicture() != null) {
            existingUser.setProfilePicture(updatedUser.getProfilePicture());
        }

        existingUser.setUpdatedAt(LocalDateTime.now());
        return userRepository.save(existingUser);
    }

    public User updateUserRole(Long userId, String role) {
        User user = getUserById(userId);
        user.setRole(role);
        user.setUpdatedAt(LocalDateTime.now());
        return userRepository.save(user);
    }

    public User updateUserStatus(Long userId, String status, String reason) {
        User user = getUserById(userId);
        String previousStatus = user.getStatus();
        user.setStatus(status);
        user.setUpdatedAt(LocalDateTime.now());

        User updatedUser = userRepository.save(user);
        notificationService.notifyUserStatusChange(updatedUser, previousStatus, status, reason);
        return updatedUser;
    }

    public void deleteUser(Long userId) {
        User user = getUserById(userId);
        user.setStatus("DELETED");
        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);
    }

    public User verifyEmail(Long userId) {
        User user = getUserById(userId);
        user.setEmailVerified(true);
        user.setUpdatedAt(LocalDateTime.now());
        
        User verifiedUser = userRepository.save(user);
        notificationService.notifyEmailVerification(verifiedUser);
        return verifiedUser;
    }

    public User updatePassword(Long userId, String newPassword) {
        User user = getUserById(userId);
        user.setPassword(passwordEncoder.encode(newPassword));
        user.setUpdatedAt(LocalDateTime.now());
        return userRepository.save(user);
    }

    public User updateWalletBalance(Long userId, Double amount) {
        User user = getUserById(userId);
        Double currentBalance = user.getWalletBalance() != null ? user.getWalletBalance() : 0.0;
        user.setWalletBalance(currentBalance + amount);
        user.setUpdatedAt(LocalDateTime.now());
        
        User updatedUser = userRepository.save(user);
        notificationService.notifyWalletTransaction(updatedUser, amount, 
            amount > 0 ? "CREDIT" : "DEBIT", "Wallet balance updated");
        return updatedUser;
    }

    public User addToWallet(Long userId, Double amount) {
        return updateWalletBalance(userId, amount);
    }

    public Double getUserWalletBalance(Long userId) {
        User user = getUserById(userId);
        return user.getWalletBalance() != null ? user.getWalletBalance() : 0.0;
    }

    public boolean userExists(Long userId) {
        return userRepository.existsById(userId);
    }

    public boolean emailExists(String email) {
        return userRepository.existsByEmail(email);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public List<User> getUsersByRole(String role) {
        return userRepository.findByRoleContaining(role);
    }

    public List<User> getUsersByStatus(String status) {
        return userRepository.findByStatus(status);
    }

    public List<User> searchUsers(String query) {
        return userRepository.findByFirstNameContainingOrLastNameContainingOrEmailContaining(query, query, query);
    }

    public User registerUser(User user) {
        return createUser(user);
    }

	public UserStats getUserStats(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public User updateUserProfile(Long id, User updatedUser) {
		// TODO Auto-generated method stub
		return null;
	}

	public void becomeMentor(Long id, MentorProfile mentorProfile) {
		// TODO Auto-generated method stub
		
	}
}