package com.knowledgeplatform.knowledgeplatform.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.knowledgeplatform.knowledgeplatform.dto.LearningPath;
import com.knowledgeplatform.knowledgeplatform.dto.SearchResults;
import com.knowledgeplatform.knowledgeplatform.model.AISuggestions;
import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.service.AIService;
import com.knowledgeplatform.knowledgeplatform.service.CourseService;
import com.knowledgeplatform.knowledgeplatform.service.MentorService;
import com.knowledgeplatform.knowledgeplatform.service.UserService;

@Controller
public class HomeController {

    @Autowired
    private CourseService courseService;

    @Autowired
    private MentorService mentorService;

    @Autowired
    private AIService aiService;

    @Autowired
    private UserService userService;

    // Home Page
    @GetMapping("/")
    public String home(Model model, Principal principal) {
        // Platform statistics
        PlatformStats stats = getPlatformStats();
        model.addAttribute("stats", stats);

        // Featured content
        List<Course> featuredCourses = courseService.getPopularCourses(6);
        List<MentorProfile> featuredMentors = mentorService.searchMentors(null, null, null).subList(0, 6);

        model.addAttribute("featuredCourses", featuredCourses);
        model.addAttribute("featuredMentors", featuredMentors);

        // Personalized recommendations if user is logged in
        if (principal != null) {
            User user = getUserFromPrincipal(principal);
            AISuggestions suggestions = aiService.getSuggestionsForUser(user.getId());
            model.addAttribute("suggestions", suggestions);
            model.addAttribute("currentUser", user);
        }

        return "home";
    }

    // Universal Search
    @GetMapping("/search")
    public String search(@RequestParam String q, 
                        @RequestParam(required = false) String category,
                        @RequestParam(required = false) String type,
                        Model model, Principal principal) {
        
        SearchResults results = new SearchResults();

        if (principal != null) {
            // AI-powered search for logged-in users
            User user = getUserFromPrincipal(principal);
            results = aiService.intelligentSearch(q, user.getId());
        } else {
            // Basic search for anonymous users
            results.setCourses(courseService.searchCourses(q));
            results.setMentors(mentorService.searchMentors(q, category, null));
        }

        model.addAttribute("query", q);
        model.addAttribute("results", results);
        model.addAttribute("resultCount", getTotalResultsCount(results));

        return "search/results";
    }

    // Browse Categories
    @GetMapping("/browse/{category}")
    public String browseCategory(@PathVariable String category, Model model) {
        List<Course> categoryCourses = courseService.searchCourses(null);
        List<MentorProfile> categoryMentors = mentorService.searchMentors(null, category, null);

        model.addAttribute("category", category);
        model.addAttribute("courses", categoryCourses);
        model.addAttribute("mentors", categoryMentors);

        return "browse/category";
    }

    // AI Learning Path
    @GetMapping("/learning-path")
    public String learningPath(@RequestParam String goal, Principal principal, Model model) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = getUserFromPrincipal(principal);
        LearningPath path = aiService.generateLearningPath(user.getId(), goal);

        model.addAttribute("learningPath", path);
        model.addAttribute("goal", goal);

        return "learning/path";
    }

    // Platform Statistics API
    @GetMapping("/api/stats")
    @ResponseBody
    public PlatformStats getPlatformStatistics() {
        return getPlatformStats();
    }

    private PlatformStats getPlatformStats() {
        PlatformStats stats = new PlatformStats();
        // These would be actual database queries
        stats.setTotalUsers(15000L);
        stats.setTotalMentors(500L);
        stats.setTotalCourses(2000L);
        stats.setTotalSessions(5000L);
        stats.setSuccessRate(94.5);
        
        return stats;
    }

    private User getUserFromPrincipal(Principal principal) {
        return userService.getUserByEmail(principal.getName());
    }

    private Integer getTotalResultsCount(SearchResults results) {
        return (results.getCourses() != null ? results.getCourses().size() : 0) +
               (results.getMentors() != null ? results.getMentors().size() : 0) +
               (results.getSessions() != null ? results.getSessions().size() : 0);
    }
}

// DTO for platform statistics
class PlatformStats {
    private Long totalUsers;
    private Long totalMentors;
    private Long totalCourses;
    private Long totalSessions;
    private Double successRate;

    // Getters and setters
    public Long getTotalUsers() { return totalUsers; }
    public void setTotalUsers(Long totalUsers) { this.totalUsers = totalUsers; }
    public Long getTotalMentors() { return totalMentors; }
    public void setTotalMentors(Long totalMentors) { this.totalMentors = totalMentors; }
    public Long getTotalCourses() { return totalCourses; }
    public void setTotalCourses(Long totalCourses) { this.totalCourses = totalCourses; }
    public Long getTotalSessions() { return totalSessions; }
    public void setTotalSessions(Long totalSessions) { this.totalSessions = totalSessions; }
    public Double getSuccessRate() { return successRate; }
    public void setSuccessRate(Double successRate) { this.successRate = successRate; }
}