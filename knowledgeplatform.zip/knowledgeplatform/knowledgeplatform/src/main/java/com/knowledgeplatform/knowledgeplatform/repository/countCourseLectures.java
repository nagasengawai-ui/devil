package com.knowledgeplatform.knowledgeplatform.repository;

import java.util.*;

import java.lang.*;
import com.knowledgeplatform.knowledgeplatform.*;
public interface countCourseLectures {
	// In CourseRepository
	Long countCourseLectures(Long courseId); // Custom query to count lectures
	List findByStatusOrderByCreatedAtDesc(String status);
	List findByStatus(String status);

}
