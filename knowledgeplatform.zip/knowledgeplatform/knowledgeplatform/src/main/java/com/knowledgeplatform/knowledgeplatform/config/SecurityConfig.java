package com.knowledgeplatform.knowledgeplatform.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(authz -> authz
                // Public endpoints
                .antMatchers("/", "/home", "/css/**", "/js/**", "/images/**", "/webjars/**", "/h2-console/**").permitAll()
                .antMatchers("/auth/**", "/courses/**", "/sessions/**").permitAll()
                
                // User endpoints
                .antMatchers("/user/**", "/learn/**", "/wallet/**").hasAnyRole("USER", "MENTOR", "ADMIN")
                
                // Mentor endpoints
                .antMatchers("/mentor/**").hasAnyRole("MENTOR", "ADMIN")
                
                // Admin endpoints
                .antMatchers("/admin/**").hasRole("ADMIN")
                
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/auth/login")
                .loginProcessingUrl("/auth/login")
                .defaultSuccessUrl("/")
                .failureUrl("/auth/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/auth/logout")
                .logoutSuccessUrl("/")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            )
            .rememberMe(remember -> remember
                .key("uniqueAndSecretKeyForKnowledgePlatform")
                .tokenValiditySeconds(86400) // 24 hours
            )
            .exceptionHandling(exceptions -> exceptions
                .accessDeniedPage("/auth/access-denied")
            )
            .csrf(csrf -> csrf
                .ignoringAntMatchers("/h2-console/**")
            )
            .headers(headers -> headers
                .frameOptions().sameOrigin()
            );

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}