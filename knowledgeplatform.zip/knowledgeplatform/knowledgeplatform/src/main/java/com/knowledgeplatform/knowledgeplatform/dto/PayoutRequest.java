package com.knowledgeplatform.knowledgeplatform.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class PayoutRequest {
    public PayoutRequest(Long id, Long mentorId, String mentorName, BigDecimal amount, String status,
			LocalDateTime requestedAt, LocalDateTime processedAt) {
		super();
		this.id = id;
		this.mentorId = mentorId;
		this.mentorName = mentorName;
		this.amount = amount;
		this.status = status;
		this.requestedAt = requestedAt;
		this.processedAt = processedAt;
	}

	private Long id;
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMentorId() {
		return mentorId;
	}

	public void setMentorId(Long mentorId) {
		this.mentorId = mentorId;
	}

	public String getMentorName() {
		return mentorName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getRequestedAt() {
		return requestedAt;
	}

	public void setRequestedAt(LocalDateTime requestedAt) {
		this.requestedAt = requestedAt;
	}

	public LocalDateTime getProcessedAt() {
		return processedAt;
	}

	public void setProcessedAt(LocalDateTime processedAt) {
		this.processedAt = processedAt;
	}

	private Long mentorId;
    private String mentorName;
    private BigDecimal amount;
    private String status;
    private LocalDateTime requestedAt;
    private LocalDateTime processedAt;
    
    // Constructors, getters, setters
    public PayoutRequest() {}
    
    // Add constructor and getters/setters
}