package com.knowledgeplatform.knowledgeplatform.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.knowledgeplatform.knowledgeplatform.dto.CourseProgress;
import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.Enrollment;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.Review;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.repository.CourseRepository;
import com.knowledgeplatform.knowledgeplatform.repository.EnrollmentRepository;
import com.knowledgeplatform.knowledgeplatform.repository.MentorRepository;
import com.knowledgeplatform.knowledgeplatform.repository.ReviewRepository;
import com.knowledgeplatform.knowledgeplatform.repository.UserRepository;

@Service
@Transactional
public class CourseService {
	@Autowired
	private CourseRepository courseLectureRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MentorRepository mentorRepository;

    @Autowired
    private MentorService mentorService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private NotificationService notificationService;

	private Double minPrice;

	private String sortBy;

	private String level;

	private String category;

    public Course getCourseById(Long courseId) {
        return courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found with id: " + courseId));
    }

    private User getUserById(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
    }

    private MentorProfile getMentorById(Long mentorId) {
        return mentorRepository.findById(mentorId)
                .orElseThrow(() -> new RuntimeException("Mentor not found with id: " + mentorId));
    }

    @Transactional
    public Enrollment enrollInCourse(Long courseId, Long userId) {
        Course course = getCourseById(courseId);
        User user = getUserById(userId);

        if (enrollmentRepository.existsByUserIdAndCourseId(userId, courseId)) {
            throw new RuntimeException("User is already enrolled in this course");
        }

        if (!"PUBLISHED".equals(course.getStatus())) {
            throw new RuntimeException("Course is not available for enrollment");
        }

        Double amountPaid = 0.0;
        if (course.getPrice() != null && course.getPrice() > 0) {
            amountPaid = paymentService.processCoursePayment(user, course);
        }

        Enrollment enrollment = new Enrollment();
        enrollment.setUser(user);
        enrollment.setCourse(course);
        enrollment.setEnrolledAt(LocalDateTime.now());
        enrollment.setStatus("ACTIVE");
        enrollment.setProgress(0.0);
        enrollment.setAmountPaid(amountPaid);
        
        if (amountPaid > 0) {
            enrollment.setPlatformCommission(amountPaid * 0.20);
        } else {
            enrollment.setPlatformCommission(0.0);
        }
        
        enrollment.setPaymentMethod("WALLET");
        enrollment.setPaymentStatus("COMPLETED");

        Enrollment savedEnrollment = enrollmentRepository.save(enrollment);

        course.setTotalEnrollments(course.getTotalEnrollments() != null ? course.getTotalEnrollments() + 1 : 1);
        courseRepository.save(course);

        updateMentorStudentCount(course.getMentor());

        notificationService.notifyEnrollmentConfirmation(user, course);
        
        if (course.getMentor() != null) {
            notificationService.notifyMentorAboutEnrollment(course.getMentor(), course, user);
        }

        return savedEnrollment;
    }

    @Transactional
    public void incrementViewCount(Long courseId) {
        try {
            Course course = getCourseById(courseId);
            Long currentViews = course.getTotalViews() != null ? course.getTotalViews() : 0L;
            course.setTotalViews(currentViews + 1);
            course.setTrendingScore(calculateTrendingScore(course));
            course.setUpdatedAt(LocalDateTime.now());
            courseRepository.save(course);
        } catch (Exception e) {
            System.err.println("Error incrementing view count for course " + courseId + ": " + e.getMessage());
        }
    }

    private Double calculateTrendingScore(Course course) {
        double score = 0.0;
        
        Long views = course.getTotalViews() != null ? course.getTotalViews() : 0L;
        score += Math.log(views + 1) * 0.4;
        
        Long enrollments = course.getTotalEnrollments() != null ? course.getTotalEnrollments() : 0L;
        score += Math.log(enrollments + 1) * 0.3;
        
        Double rating = course.getAverageRating() != null ? course.getAverageRating() : 0.0;
        score += (rating / 5.0) * 0.2;
        
        if (course.getPublishedAt() != null) {
            long daysSincePublished = java.time.Duration.between(course.getPublishedAt(), LocalDateTime.now()).toDays();
            double recencyFactor = Math.max(0, 30 - daysSincePublished) / 30.0;
            score += recencyFactor * 0.1;
        }
        
        return score;
    }

    public List<Course> searchCourses(String query) {
        Object maxPrice = null;
		if (query != null || category != null || level != null || minPrice != null || maxPrice != null) {
            return courseRepository.searchCoursesWithSorting(query, category, level, minPrice, (Double) maxPrice, sortBy);
        }
        return courseRepository.findByStatus("PUBLISHED");
    }

    public List<Course> getPopularCourses(int limit) {
        return courseRepository.findTopPublishedByEnrollments(limit);
    }

    public List<Course> getCoursesByMentor(Long mentorId) {
        return courseRepository.findByMentorIdAndStatus(mentorId, "PUBLISHED");
    }

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public List<Course> getPendingReviewCourses() {
        return courseRepository.findByStatus("PENDING");
    }

    @Transactional
    public Course submitForReview(Long courseId) {
        Course course = getCourseById(courseId);
        
        if (!isCourseReadyForReview(course)) {
            throw new RuntimeException("Course is not ready for review. Please complete all required sections.");
        }

        course.setStatus("PENDING");
        course.setUpdatedAt(LocalDateTime.now());

        Course updatedCourse = courseRepository.save(course);
        notificationService.notifyAdminForCourseReview(updatedCourse);
        return updatedCourse;
    }

    @Transactional
    public Course publishCourse(Long courseId) {
        Course course = getCourseById(courseId);
        
        course.setStatus("PUBLISHED");
        course.setIsApproved(true);
        course.setPublishedAt(LocalDateTime.now());
        course.setUpdatedAt(LocalDateTime.now());

        Course publishedCourse = courseRepository.save(course);

        if (course.getMentor() != null) {
            notificationService.notifyMentorAboutCourseApproval(course.getMentor(), course);
        }

        return publishedCourse;
    }

    @Transactional
    public Course rejectCourse(Long courseId, String reason) {
        Course course = getCourseById(courseId);
        
        course.setStatus("REJECTED");
        course.setIsApproved(false);
        course.setRejectionNotes(reason);
        course.setUpdatedAt(LocalDateTime.now());

        Course rejectedCourse = courseRepository.save(course);

        if (course.getMentor() != null) {
            notificationService.notifyMentorAboutCourseRejection(course.getMentor(), course, reason);
        }

        return rejectedCourse;
    }

    @Transactional
    public Review addCourseReview(Long courseId, Long userId, Integer rating, String comment) {
        Course course = getCourseById(courseId);
        User user = getUserById(userId);

        if (!enrollmentRepository.existsByUserIdAndCourseId(userId, courseId)) {
            throw new RuntimeException("You must be enrolled to review this course");
        }

        if (reviewRepository.existsByUserIdAndCourseId(userId, courseId)) {
            throw new RuntimeException("You have already reviewed this course");
        }

        if (rating < 1 || rating > 5) {
            throw new RuntimeException("Rating must be between 1 and 5");
        }

        Review review = new Review();
        review.setUser(user);
        review.setCourse(course);
        review.setRating(rating);
        review.setComment(comment);
        review.setCreatedAt(LocalDateTime.now());
        review.setIsVerified(true);

        Review savedReview = reviewRepository.save(review);
        updateCourseRating(course);

        if (course.getMentor() != null) {
            notificationService.notifyNewReview(course.getMentor(), savedReview);
        }

        return savedReview;
    }

    public List<Review> getCourseReviews(Long courseId) {
        return reviewRepository.findByCourseIdOrderByCreatedAtDesc(courseId);
    }

    public CourseProgress getCourseProgress(Long courseId, Long userId) {
        Enrollment enrollment = enrollmentRepository.findByUserIdAndCourseId(userId, courseId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));

        CourseProgress progress = new CourseProgress(null, null, null, null, userId);
        progress.setProgressPercentage(enrollment.getProgress());
        progress.setCompletedLectures(enrollment.getCompletedLectures() != null ? enrollment.getCompletedLectures() : 0);
        
        Long totalLecturesCount = courseRepository.countCourseLectures(courseId);
        progress.setTotalLectures(totalLecturesCount != null ? totalLecturesCount.intValue() : 0);
        
        progress.setLastActivity(enrollment.getLastActivityAt());
        progress.setTimeSpent(calculateTimeSpent(courseId, userId));

        return progress;
    }

    @Transactional
    public Enrollment updateCourseProgress(Long courseId, Long userId, Double progress, Integer completedLectures) {
        Enrollment enrollment = enrollmentRepository.findByUserIdAndCourseId(userId, courseId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));

        if (progress != null) {
            enrollment.setProgress(progress);
        }
        if (completedLectures != null) {
            enrollment.setCompletedLectures(completedLectures);
        }
        enrollment.setLastActivityAt(LocalDateTime.now());

        if (enrollment.getProgress() >= 100.0) {
            enrollment.setStatus("COMPLETED");
            enrollment.setCompletedAt(LocalDateTime.now());
            notificationService.notifyCourseCompletion(enrollment.getUser(), enrollment.getCourse());
        }

        return enrollmentRepository.save(enrollment);
    }

    @Transactional
    public Enrollment completeLecture(Long courseId, Long userId) {
        Enrollment enrollment = enrollmentRepository.findByUserIdAndCourseId(userId, courseId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));

        enrollment.completeLecture();
        Enrollment updatedEnrollment = enrollmentRepository.save(enrollment);

        if (updatedEnrollment.isCompleted()) {
            notificationService.notifyCourseCompletion(updatedEnrollment.getUser(), updatedEnrollment.getCourse());
        }

        return updatedEnrollment;
    }

    private void updateCourseRating(Course course) {
        Double averageRating = reviewRepository.calculateAverageRatingByCourseId(course.getId());
        Long totalReviews = reviewRepository.countByCourseId(course.getId());
        
        course.setAverageRating(averageRating != null ? averageRating : 0.0);
        course.setTotalReviews(totalReviews != null ? totalReviews.intValue() : 0);
        courseRepository.save(course);
    }

    private boolean isCourseReadyForReview(Course course) {
        return course.getTitle() != null && !course.getTitle().trim().isEmpty() &&
               course.getDescription() != null && !course.getDescription().trim().isEmpty() &&
               course.getPrice() != null &&
               course.getCategory() != null && !course.getCategory().trim().isEmpty() &&
               course.getLevel() != null && !course.getLevel().trim().isEmpty() &&
               course.getThumbnailUrl() != null && !course.getThumbnailUrl().trim().isEmpty() &&
               course.getTotalVideoHours() != null && course.getTotalVideoHours() > 0;
    }

    private void updateMentorStudentCount(MentorProfile mentor) {
        Long totalStudents = enrollmentRepository.countByMentorId(mentor.getId());
        mentor.setTotalStudents(totalStudents != null ? totalStudents : 0L);
        mentorRepository.save(mentor);
    }

    private Long calculateTimeSpent(Long courseId, Long userId) {
        return 120L;
    }

    public List<Course> getEnrolledCourses(Long userId) {
        List<Enrollment> enrollments = enrollmentRepository.findByUserId(userId);
        return enrollments.stream()
                .map(Enrollment::getCourse)
                .collect(Collectors.toList());
    }

    public List<Enrollment> getActiveEnrollments(Long userId) {
        return enrollmentRepository.findByUserIdAndStatus(userId, "ACTIVE");
    }

    public boolean isUserEnrolled(Long courseId, Long userId) {
        return enrollmentRepository.existsByUserIdAndCourseId(userId, courseId);
    }

    public Enrollment getEnrollment(Long courseId, Long userId) {
        return enrollmentRepository.findByUserIdAndCourseId(userId, courseId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));
    }

    @Transactional
    public void cancelEnrollment(Long courseId, Long userId) {
        Enrollment enrollment = enrollmentRepository.findByUserIdAndCourseId(userId, courseId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));

        enrollment.setStatus("CANCELLED");
        enrollmentRepository.save(enrollment);

        Course course = getCourseById(courseId);
        if (course.getTotalEnrollments() != null && course.getTotalEnrollments() > 0) {
            course.setTotalEnrollments(course.getTotalEnrollments() - 1);
            courseRepository.save(course);
        }
    }

    @Transactional
    public Course createCourse(Long mentorId, Course course) {
        MentorProfile mentor = getMentorById(mentorId);
        course.setMentor(mentor);
        course.setStatus("DRAFT");
        course.setCreatedAt(LocalDateTime.now());
        course.setUpdatedAt(LocalDateTime.now());
        
        return courseRepository.save(course);
    }

    @Transactional
    public Course updateCourse(Long courseId, Course updatedCourse) {
        Course existingCourse = getCourseById(courseId);
        
        if (updatedCourse.getTitle() != null) {
            existingCourse.setTitle(updatedCourse.getTitle());
        }
        if (updatedCourse.getDescription() != null) {
            existingCourse.setDescription(updatedCourse.getDescription());
        }
        if (updatedCourse.getPrice() != null) {
            existingCourse.setPrice(updatedCourse.getPrice());
        }
        if (updatedCourse.getCategory() != null) {
            existingCourse.setCategory(updatedCourse.getCategory());
        }
        if (updatedCourse.getLevel() != null) {
            existingCourse.setLevel(updatedCourse.getLevel());
        }
        if (updatedCourse.getThumbnailUrl() != null) {
            existingCourse.setThumbnailUrl(updatedCourse.getThumbnailUrl());
        }
        if (updatedCourse.getTotalVideoHours() != null) {
            existingCourse.setTotalVideoHours(updatedCourse.getTotalVideoHours());
        }
        
        existingCourse.setUpdatedAt(LocalDateTime.now());
        return courseRepository.save(existingCourse);
    }

	public Long getPreviewLectures(Long courseId) {
		// TODO Auto-generated method stub
		return courseId;
	}
	public Course getLectureById(Long lectureId) {
	    Optional<Course> lecture = courseRepository.findById(lectureId);
	    
	    if (lecture.isPresent()) {
	        Course courseLecture = lecture.get();
	        // Eagerly fetch related entities if needed
	        if (courseLecture.getSections() != null && ((Enrollment) courseLecture.getSections()).getCourse() != null) {
	            // This ensures the section and course are loaded
	        }
	        return courseLecture;
	    }
	    
	    throw new RuntimeException("Lecture not found with id: " + lectureId);
	}

	public Object findById(Long courseId) {
		// TODO Auto-generated method stub
		return null;
	}
	}