package com.knowledgeplatform.knowledgeplatform.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "mentor_stats")
public class MentorStats {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "mentor_id")
    private Long mentorId;

    @Column(name = "mentor_name")
    private String mentorName;

    @Column(name = "total_courses")
    private Integer totalCourses;

    @Column(name = "published_courses")
    private Integer publishedCourses;

    @Column(name = "total_students")
    private Integer totalStudents;

    @Column(name = "active_students")
    private Integer activeStudents;

    @Column(name = "total_sessions")
    private Integer totalSessions;

    @Column(name = "completed_sessions")
    private Integer completedSessions;

    @Column(name = "total_earnings")
    private BigDecimal totalEarnings;

    @Column(name = "available_balance")
    private BigDecimal availableBalance;

    @Column(name = "pending_balance")
    private BigDecimal pendingBalance;

    @Column(name = "average_rating")
    private Double averageRating;

    @Column(name = "total_reviews")
    private Integer totalReviews;

    @Column(name = "response_rate")
    private Double responseRate;

    @Column(name = "completion_rate")
    private Double completionRate;

    @Column(name = "satisfaction_score")
    private Double satisfactionScore;

    @Column(name = "period_date")
    private LocalDateTime periodDate;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

	private Long countByIsVerified;

	private Long countByVerificationStatus;

    // Constructors
    public MentorStats() {
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getMentorId() { return mentorId; }
    public void setMentorId(Long mentorId) { this.mentorId = mentorId; }

    public String getMentorName() { return mentorName; }
    public void setMentorName(String mentorName) { this.mentorName = mentorName; }

    public Integer getTotalCourses() { return totalCourses; }
    public void setTotalCourses(Integer totalCourses) { this.totalCourses = totalCourses; }

    public Integer getPublishedCourses() { return publishedCourses; }
    public void setPublishedCourses(Integer publishedCourses) { this.publishedCourses = publishedCourses; }

    public Integer getTotalStudents() { return totalStudents; }
    public void setTotalStudents(Integer totalStudents) { this.totalStudents = totalStudents; }

    public Integer getActiveStudents() { return activeStudents; }
    public void setActiveStudents(Integer activeStudents) { this.activeStudents = activeStudents; }

    public Integer getTotalSessions() { return totalSessions; }
    public void setTotalSessions(Integer totalSessions) { this.totalSessions = totalSessions; }

    public Integer getCompletedSessions() { return completedSessions; }
    public void setCompletedSessions(Integer completedSessions) { this.completedSessions = completedSessions; }

    public BigDecimal getTotalEarnings() { return totalEarnings; }
    public void setTotalEarnings(BigDecimal totalEarnings) { this.totalEarnings = totalEarnings; }

    public BigDecimal getAvailableBalance() { return availableBalance; }
    public void setAvailableBalance(BigDecimal availableBalance) { this.availableBalance = availableBalance; }

    public BigDecimal getPendingBalance() { return pendingBalance; }
    public void setPendingBalance(BigDecimal pendingBalance) { this.pendingBalance = pendingBalance; }

    public Double getAverageRating() { return averageRating; }
    public void setAverageRating(Double averageRating) { this.averageRating = averageRating; }

    public Integer getTotalReviews() { return totalReviews; }
    public void setTotalReviews(Integer totalReviews) { this.totalReviews = totalReviews; }

    public Double getResponseRate() { return responseRate; }
    public void setResponseRate(Double responseRate) { this.responseRate = responseRate; }

    public Double getCompletionRate() { return completionRate; }
    public void setCompletionRate(Double completionRate) { this.completionRate = completionRate; }

    public Double getSatisfactionScore() { return satisfactionScore; }
    public void setSatisfactionScore(Double satisfactionScore) { this.satisfactionScore = satisfactionScore; }

    public LocalDateTime getPeriodDate() { return periodDate; }
    public void setPeriodDate(LocalDateTime periodDate) { this.periodDate = periodDate; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

	public void setTotalMentors(long count) {
		this.setTotalMentors(count);
		// TODO Auto-generated method stub
		
	}

	public void setVerifiedMentors(Long countByIsVerified) {
		this.countByIsVerified=countByIsVerified;
		// TODO Auto-generated method stub
		
	}

	public void setPendingVerification(Long countByVerificationStatus) {
		// TODO Auto-generated method stub
		this.countByVerificationStatus=countByVerificationStatus;
		
	}
}