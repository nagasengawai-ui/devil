package com.knowledgeplatform.knowledgeplatform.dto;

import javax.validation.constraints.Min;

import javax.validation.constraints.NotNull;

public class AdminDashboardStats {
    @NotNull
    @Min(0)
    private Long totalUsers;
    
    @NotNull
    @Min(0)
    private Long totalMentors;
    
    @NotNull
    @Min(0)
    private Long totalCourses;
    
    @NotNull
    @Min(0)
    private Long pendingVerifications;
    
    @NotNull
    @Min(0)
    private Long pendingCourses;
    
    @NotNull
    @Min(0)
    private Double todayRevenue;
    
    @NotNull
    private Double platformGrowth;

    // Constructors
    public AdminDashboardStats() {}
    
    public AdminDashboardStats(Long totalUsers, Long totalMentors, Long totalCourses, 
                              Long pendingVerifications, Long pendingCourses, 
                              Double todayRevenue, Double platformGrowth) {
        this.totalUsers = totalUsers;
        this.totalMentors = totalMentors;
        this.totalCourses = totalCourses;
        this.pendingVerifications = pendingVerifications;
        this.pendingCourses = pendingCourses;
        this.todayRevenue = todayRevenue;
        this.platformGrowth = platformGrowth;
    }

    // Getters and setters
    public Long getTotalUsers() { return totalUsers; }
    public void setTotalUsers(Long totalUsers) { this.totalUsers = totalUsers; }
    public Long getTotalMentors() { return totalMentors; }
    public void setTotalMentors(Long totalMentors) { this.totalMentors = totalMentors; }
    public Long getTotalCourses() { return totalCourses; }
    public void setTotalCourses(Long totalCourses) { this.totalCourses = totalCourses; }
    public Long getPendingVerifications() { return pendingVerifications; }
    public void setPendingVerifications(Long pendingVerifications) { this.pendingVerifications = pendingVerifications; }
    public Long getPendingCourses() { return pendingCourses; }
    public void setPendingCourses(Long pendingCourses) { this.pendingCourses = pendingCourses; }
    public Double getTodayRevenue() { return todayRevenue; }
    public void setTodayRevenue(Double todayRevenue) { this.todayRevenue = todayRevenue; }
    public Double getPlatformGrowth() { return platformGrowth; }
    public void setPlatformGrowth(Double platformGrowth) { this.platformGrowth = platformGrowth; }
}