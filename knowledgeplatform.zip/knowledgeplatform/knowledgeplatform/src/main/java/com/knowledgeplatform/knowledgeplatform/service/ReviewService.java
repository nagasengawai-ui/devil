package com.knowledgeplatform.knowledgeplatform.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.Review;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.repository.ReviewRepository;

@Service
@Transactional
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private CourseService courseService;

    @Autowired
    private MentorService mentorService;

    @Autowired
    private UserService userService;

    // Basic CRUD operations
    public Review saveReview(Review review) {
        // Validate rating range
        if (review.getOverallRating() < 1 || review.getOverallRating() > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5");
        }

        // Set default status if not provided
        if (review.getStatus() == null) {
            review.setStatus("PENDING");
        }

        // Auto-verify if user is enrolled in course (for course reviews)
        if (review.getCourse() != null && review.getUser() != null) {
            boolean isEnrolled = courseService.isUserEnrolled(review.getCourse().getId(), review.getUser().getId());
            review.setIsVerified(isEnrolled);
        }

        review.setUpdatedAt(LocalDateTime.now());
        return reviewRepository.save(review);
    }

    public Optional<Review> findById(Long id) {
        return reviewRepository.findById(id);
    }

    public List<Review> findAll() {
        return reviewRepository.findAll();
    }

    public Page<Review> findAll(Pageable pageable) {
        return reviewRepository.findAll(pageable);
    }

    public void deleteReview(Long id) {
        reviewRepository.deleteById(id);
    }

    // Course reviews
    public List<Review> getCourseReviews(Long courseId) {
        return reviewRepository.findByCourseIdAndStatus(courseId, "APPROVED");
    }

    public Page<Review> getCourseReviews(Long courseId, Pageable pageable) {
        return reviewRepository.findByCourseId(courseId, pageable);
    }

    public Review createCourseReview(Long userId, Long courseId, Integer rating, String comment, String title) {
        // Check if user has already reviewed this course
        if (reviewRepository.existsByUserIdAndCourseId(userId, courseId)) {
            throw new IllegalStateException("User has already reviewed this course");
        }

        User user = userService.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        Course course = courseService.findById(courseId)
                .orElseThrow(() -> new IllegalArgumentException("Course not found"));

        Review review = new Review(user, course, rating, comment);
        review.setTitle(title);
        review.setReviewType("COURSE_REVIEW");
        
        // Verify if user is enrolled
        boolean isEnrolled = courseService.isUserEnrolled(courseId, userId);
        review.setIsVerified(isEnrolled);

        return saveReview(review);
    }

    // Mentor reviews
    public List<Review> getMentorReviews(Long mentorId) {
        return reviewRepository.findByMentorIdAndStatus(mentorId, "APPROVED");
    }

    public Review createMentorReview(Long userId, Long mentorId, Integer rating, String comment, String title) {
        if (reviewRepository.existsByUserIdAndMentorId(userId, mentorId)) {
            throw new IllegalStateException("User has already reviewed this mentor");
        }

        User user = userService.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        MentorProfile mentor = mentorService.findById(mentorId)
                .orElseThrow(() -> new IllegalArgumentException("Mentor not found"));

        Review review = new Review(user, mentor, rating, comment);
        review.setTitle(title);
        review.setReviewType("MENTOR_REVIEW");

        return saveReview(review);
    }

    // Rating calculations
    public Double getCourseAverageRating(Long courseId) {
        return reviewRepository.findAverageRatingByCourseId(courseId).orElse(0.0);
    }

    public Double getMentorAverageRating(Long mentorId) {
        return reviewRepository.findAverageRatingByMentorId(mentorId).orElse(0.0);
    }

    public Long getCourseReviewCount(Long courseId) {
        return reviewRepository.countByCourseId(courseId);
    }

    public Long getMentorReviewCount(Long mentorId) {
        return reviewRepository.countByMentorId(mentorId);
    }

    // Review engagement
    public Review markHelpful(Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Review not found"));
        review.markHelpful();
        return reviewRepository.save(review);
    }

    public Review markNotHelpful(Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Review not found"));
        review.markNotHelpful();
        return reviewRepository.save(review);
    }

    public Review reportReview(Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Review not found"));
        review.report();
        return reviewRepository.save(review);
    }

    // Mentor responses
    public Review addMentorResponse(Long reviewId, String response) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Review not found"));
        
        if (review.getMentor() == null) {
            throw new IllegalStateException("This review is not for a mentor");
        }

        review.addMentorResponse(response);
        return reviewRepository.save(review);
    }

    // Moderation
    public List<Review> getReviewsNeedingModeration() {
        return reviewRepository.findReviewsNeedingModeration();
    }

    public Review approveReview(Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Review not found"));
        review.setStatus("APPROVED");
        review.setUpdatedAt(LocalDateTime.now());
        return reviewRepository.save(review);
    }

    public Review rejectReview(Long reviewId, String moderatorNotes) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Review not found"));
        review.setStatus("REJECTED");
        review.setModeratorNotes(moderatorNotes);
        review.setUpdatedAt(LocalDateTime.now());
        return reviewRepository.save(review);
    }

    public Review flagReview(Long reviewId, String moderatorNotes) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Review not found"));
        review.setStatus("FLAGGED");
        review.setModeratorNotes(moderatorNotes);
        review.setUpdatedAt(LocalDateTime.now());
        return reviewRepository.save(review);
    }

    // Analytics and reporting
    public List<Review> getPositiveReviews() {
        return reviewRepository.findPositiveReviews();
    }

    public List<Review> getNegativeReviews() {
        return reviewRepository.findNegativeReviews();
    }

    public Page<Review> getMostHelpfulReviews(Pageable pageable) {
        return reviewRepository.findMostHelpfulReviews(pageable);
    }

    public List<Review> getVerifiedReviews(Long courseId) {
        return reviewRepository.findByCourseIdAndIsVerifiedTrue(courseId);
    }

    // User-specific queries
    public List<Review> getUserReviews(Long userId) {
        return reviewRepository.findByUserId(userId);
    }

    public boolean hasUserReviewedCourse(Long userId, Long courseId) {
        return reviewRepository.existsByUserIdAndCourseId(userId, courseId);
    }

    public boolean hasUserReviewedMentor(Long userId, Long mentorId) {
        return reviewRepository.existsByUserIdAndMentorId(userId, mentorId);
    }

    // Review statistics
    public ReviewStatistics getCourseReviewStatistics(Long courseId) {
        Double averageRating = getCourseAverageRating(courseId);
        Long totalReviews = getCourseReviewCount(courseId);
        int verifiedReviews = reviewRepository.findByCourseIdAndIsVerifiedTrue(courseId).size();
        
        return new ReviewStatistics(averageRating, totalReviews, verifiedReviews);
    }

    // DTO for statistics
    public static class ReviewStatistics {
        private final Double averageRating;
        private final Long totalReviews;
        private final Long verifiedReviews;

        public ReviewStatistics(Double averageRating, Long totalReviews, int verifiedReviews2) {
            this.averageRating = averageRating;
            this.totalReviews = totalReviews;
            this.verifiedReviews = verifiedReviews2;
        }

        // Getters
        public Double getAverageRating() { return averageRating; }
        public Long getTotalReviews() { return totalReviews; }
        public Long getVerifiedReviews() { return verifiedReviews; }
    }
}