package com.knowledgeplatform.knowledgeplatform.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.knowledgeplatform.knowledgeplatform.dto.ContentOverview;
import com.knowledgeplatform.knowledgeplatform.dto.CourseStats;
import com.knowledgeplatform.knowledgeplatform.dto.PayoutRequest;
import com.knowledgeplatform.knowledgeplatform.dto.PlatformAnalytics;
import com.knowledgeplatform.knowledgeplatform.dto.PlatformRevenue;
import com.knowledgeplatform.knowledgeplatform.dto.PlatformSettings;
import com.knowledgeplatform.knowledgeplatform.dto.SystemHealth;
import com.knowledgeplatform.knowledgeplatform.dto.UserAdminDetail;
import com.knowledgeplatform.knowledgeplatform.dto.UserStats;
import com.knowledgeplatform.knowledgeplatform.model.ContentAnalytics;
import com.knowledgeplatform.knowledgeplatform.model.ContentReport;
import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.FinancialTransaction;
import com.knowledgeplatform.knowledgeplatform.model.HealthMetrics;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.MentorStats;
import com.knowledgeplatform.knowledgeplatform.model.PlatformActivity;
import com.knowledgeplatform.knowledgeplatform.model.Report;
import com.knowledgeplatform.knowledgeplatform.model.RevenueAnalytics;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.model.UserGrowth;
import com.knowledgeplatform.knowledgeplatform.repository.CourseRepository;
import com.knowledgeplatform.knowledgeplatform.repository.EnrollmentRepository;
import com.knowledgeplatform.knowledgeplatform.repository.FinancialTransactionRepository;
import com.knowledgeplatform.knowledgeplatform.repository.MentorRepository;
import com.knowledgeplatform.knowledgeplatform.repository.ReviewRepository;
import com.knowledgeplatform.knowledgeplatform.repository.UserRepository;

@Service
@Transactional
public class AdminService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MentorRepository mentorRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private FinancialTransactionRepository transactionRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    public AdminDashboardStats getDashboardStats() {
        AdminDashboardStats stats = new AdminDashboardStats();
        
        stats.setTotalUsers(userRepository.count());
        stats.setTotalMentors(mentorRepository.countByIsVerified(true));
        stats.setTotalCourses(courseRepository.countByStatus("PUBLISHED"));
        stats.setPendingVerifications(mentorRepository.countByVerificationStatus("PENDING"));
        stats.setPendingCourses(courseRepository.countByStatus("PENDING"));
        stats.setTodayRevenue(calculateTodayRevenue());
        stats.setPlatformGrowth(calculatePlatformGrowth());
        
        return stats;
    }

    public PlatformRevenue getPlatformRevenue() {
        PlatformRevenue revenue = new PlatformRevenue();
        revenue.setTotalRevenue(transactionRepository.getTotalRevenue() != null ? transactionRepository.getTotalRevenue() : 0.0);
        revenue.setTodayRevenue(calculateTodayRevenue());
        revenue.setMonthlyRevenue(calculateMonthlyRevenue());
        revenue.setPlatformCommission(transactionRepository.getTotalCommission() != null ? transactionRepository.getTotalCommission() : 0.0);
        revenue.setActiveSubscriptions(calculateActiveSubscriptions());
        revenue.setPendingPayouts(calculatePendingPayouts());
        return revenue;
    }

    public List<PlatformActivity> getRecentActivities() {
        List<PlatformActivity> activities = new ArrayList<>();
        
        List<User> recentUsers = userRepository.findTop5ByOrderByCreatedAtDesc();
        for (User user : recentUsers) {
            activities.add(PlatformActivity.builder()
                .type("USER_REGISTRATION")
                .description(user.getFirstName() + " " + user.getLastName() + " registered")
                .timestamp(user.getCreatedAt())
                .userId(user.getId())
                .userFullName(user.getFirstName() + " " + user.getLastName())
                .build());
        }
        
        List<Course> recentCourses = courseRepository.findTop5ByStatusOrderByCreatedAtDesc("PUBLISHED");
        for (Course course : recentCourses) {
            activities.add(PlatformActivity.builder()
                .type("COURSE_PUBLISHED")
                .description("Course '" + course.getTitle() + "' published")
                .timestamp(course.getCreatedAt())
                .entityId(course.getId())
                .entityType("COURSE")
                .build());
        }
        
        return activities;
    }

    public SystemHealth getSystemHealth() {
        try {
            HealthMetrics metrics = new HealthMetrics();
            metrics.setTotalRequests(10000L);
            metrics.setSuccessfulRequests(9800L);
            metrics.setFailedRequests(200L);
            metrics.setErrorRate(2.0);
            metrics.setDatabaseConnections(25);
            metrics.setActiveUsers(50);
            metrics.setAverageLoad(1.2);
            
            SystemHealth health = SystemHealth.builder()
                .serverStatus("HEALTHY")
                .databaseStatus(checkDatabaseHealth())
                .apiStatus("HEALTHY")
                .cacheStatus("HEALTHY")
                .storageStatus("HEALTHY")
                .overallStatus("HEALTHY")
                .uptime(calculateUptime())
                .responseTime(calculateAverageResponseTime())
                .activeUsers(getActiveUsersCount())
                .memoryUsage(8192.0)
                .memoryTotal(16384.0)
                .diskUsage(250000.0)
                .diskTotal(1000000.0)
                .cpuUsage(calculateCpuUsage())
                .metrics(metrics)
                .build();

            return health;
            
        } catch (Exception e) {
            return SystemHealth.builder()
                .serverStatus("UNKNOWN")
                .databaseStatus("UNKNOWN")
                .apiStatus("UNKNOWN")
                .overallStatus("UNKNOWN")
                .build();
        }
    }

    public List<User> getUsers(String search, String status) {
        if (search != null && !search.trim().isEmpty()) {
            return userRepository.findByFirstNameContainingOrLastNameContainingOrEmailContaining(search, search, search);
        } else if (status != null && !status.trim().isEmpty()) {
            return userRepository.findByStatus(status);
        } else {
            return userRepository.findAll();
        }
    }

    public UserStats getUserStats() {
        UserStats stats = new UserStats();
        
        try {
            stats.setTotalUsers(userRepository.count());
            stats.setActiveUsers(userRepository.countByStatus("ACTIVE"));
            stats.setSuspendedUsers(userRepository.countByStatus("SUSPENDED"));
            stats.setNewUsersToday(userRepository.countByCreatedAtAfter(LocalDateTime.now().minusDays(1)));
            stats.setNewUsersThisWeek(userRepository.countByCreatedAtAfter(LocalDateTime.now().minusWeeks(1)));
            stats.setNewUsersThisMonth(userRepository.countByCreatedAtAfter(LocalDateTime.now().minusMonths(1)));
            stats.setMentorUsers(userRepository.countByRole("MENTOR"));
            stats.setStudentUsers(userRepository.countByRole("STUDENT"));
            stats.setVerifiedUsers(userRepository.countByEmailVerifiedTrue());
            stats.setUnverifiedUsers(userRepository.countByEmailVerifiedFalse());
            stats.setGrowthRate(calculateUserGrowthRate());
            
        } catch (Exception e) {
            stats.setTotalUsers(0L);
            stats.setActiveUsers(0L);
            stats.setSuspendedUsers(0L);
            stats.setNewUsersToday(0L);
            stats.setGrowthRate(0.0);
        }
        
        return stats;
    }

    public UserAdminDetail getUserAdminDetail(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            return null;
        }
        
        UserAdminDetail detail = new UserAdminDetail();
        detail.setUser(user);
        detail.setTotalEnrollments(enrollmentRepository.countByUserId(userId));
        detail.setTransactions(transactionRepository.findByUserId(userId));
        detail.setReviews(reviewRepository.findByUserId(userId));
        return detail;
    }

    public void updateUserStatus(Long userId, String status, String reason) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        user.setStatus(status);
        userRepository.save(user);
        
        // Log the status change
        System.out.println("User " + userId + " status changed to " + status + ". Reason: " + reason);
    }

    public List<MentorProfile> getPendingMentorVerifications() {
        return mentorRepository.findByVerificationStatus("PENDING");
    }

    public List<MentorProfile> getRejectedMentors() {
        return mentorRepository.findByVerificationStatus("REJECTED");
    }

    public List<MentorProfile> getMentors(String search, String status) {
        if (search != null && !search.trim().isEmpty()) {
            return mentorRepository.findByUserFirstNameContainingOrUserLastNameContainingOrProfessionalTitleContaining(search, search, search);
        } else if (status != null && !status.trim().isEmpty()) {
            return mentorRepository.findByVerificationStatus(status);
        } else {
            return mentorRepository.findAll();
        }
    }

    public MentorStats getMentorStats() {
        MentorStats stats = new MentorStats();
        stats.setTotalMentors(mentorRepository.count());
        stats.setVerifiedMentors(mentorRepository.countByIsVerified(true));
        stats.setPendingVerification(mentorRepository.countByVerificationStatus("PENDING"));
        stats.setRejectedMentors(mentorRepository.countByVerificationStatus("REJECTED"));
        return stats;
    }

    public List<Course> getCourses(String search, String status) {
        if (search != null && !search.trim().isEmpty()) {
            return courseRepository.findByTitleContainingOrDescriptionContaining(search, search);
        } else if (status != null && !status.trim().isEmpty()) {
            return courseRepository.findByStatus(status);
        } else {
            return courseRepository.findAll();
        }
    }

    public CourseStats getCourseStats() {
        CourseStats stats = new CourseStats();
        stats.setTotalCourses(courseRepository.count());
        stats.setPublishedCourses(courseRepository.countByStatus("PUBLISHED"));
        stats.setPendingApproval(courseRepository.countByStatus("PENDING"));
        stats.setDraftCourses(courseRepository.countByStatus("DRAFT"));
        stats.setRejectedCourses(courseRepository.countByStatus("REJECTED"));
        return stats;
    }

    public List<Course> getFlaggedCourses() {
        return courseRepository.findByStatus("FLAGGED");
    }

    public List<Course> getPendingCourses() {
        return courseRepository.findByStatus("PENDING");
    }

    public void approveCourse(Long courseId) {
        Course course = courseRepository.findById(courseId)
            .orElseThrow(() -> new RuntimeException("Course not found"));
        course.setStatus("PUBLISHED");
        course.setPublishedAt(LocalDateTime.now());
        courseRepository.save(course);
    }

    public void requestCourseChanges(Long courseId, String notes) {
        Course course = courseRepository.findById(courseId)
            .orElseThrow(() -> new RuntimeException("Course not found"));
        course.setStatus("CHANGES_REQUESTED");
        course.setAdminNotes(notes);
        courseRepository.save(course);
    }

    public void rejectCourse(Long courseId, String notes) {
        Course course = courseRepository.findById(courseId)
            .orElseThrow(() -> new RuntimeException("Course not found"));
        course.setStatus("REJECTED");
        course.setRejectionNotes(notes);
        courseRepository.save(course);
    }

    public List<FinancialTransaction> getRecentTransactions() {
        return transactionRepository.findTop10ByOrderByCreatedAtDesc();
    }

    public List<PayoutRequest> getPendingPayouts() {
        // This would typically come from a PayoutRequestRepository
        return new ArrayList<>();
    }

    public List<FinancialTransaction> getTransactions(String type, String status) {
        if (type != null && status != null) {
            return transactionRepository.findByTransactionTypeAndStatus(type, status);
        } else if (type != null) {
            return transactionRepository.findByTransactionType(type);
        } else if (status != null) {
            return transactionRepository.findByStatus(status);
        } else {
            return transactionRepository.findAll();
        }
    }

    public void processPayout(Long payoutId) {
        // Implementation for processing payouts
        System.out.println("Processing payout: " + payoutId);
    }

    public ContentOverview getContentOverview() {
        ContentOverview overview = new ContentOverview();
        overview.setTotalCourses(courseRepository.count());
        overview.setTotalReviews(reviewRepository.count());
        overview.setPublishedCourses(courseRepository.countByStatus("PUBLISHED"));
        overview.setTotalEnrollments(enrollmentRepository.count());
        return overview;
    }

    public List<ContentReport> getReportedContent() {
        // This would typically come from a ContentReportRepository
        return new ArrayList<>();
    }

    public PlatformSettings getPlatformSettings() {
        PlatformSettings settings = new PlatformSettings();
        settings.setCommissionRate(20.0);
        settings.setMinimumPayout(50.0);
        settings.setEmailVerificationRequired(true);
        settings.setMentorVerificationRequired(true);
        settings.setPlatformName("Knowledge Platform");
        settings.setSupportEmail("support@knowledgeplatform.com");
        settings.setMaxCourseDuration(365); // days
        settings.setAutoApproveCourses(false);
        return settings;
    }

    public void updatePlatformSettings(PlatformSettings settings) {
        // Implementation to save platform settings to database
        System.out.println("Updating platform settings: " + settings);
    }

    public PlatformAnalytics getPlatformAnalytics() {
        PlatformAnalytics analytics = new PlatformAnalytics();
        
        UserGrowth userGrowth = new UserGrowth();
        userGrowth.setTotalUsers(userRepository.count());
        userGrowth.setMonthlyGrowth(calculateUserGrowthRate());
        
        RevenueAnalytics revenueAnalytics = new RevenueAnalytics();
        revenueAnalytics.setTotalRevenue(transactionRepository.getTotalRevenue());
        revenueAnalytics.setMonthlyRevenue(calculateMonthlyRevenue());
        
        ContentAnalytics contentAnalytics = new ContentAnalytics();
        contentAnalytics.setTotalCourses(courseRepository.count());
        contentAnalytics.setTotalEnrollments(enrollmentRepository.count());
        
        analytics.setUserGrowth(userGrowth);
        analytics.setRevenueAnalytics(revenueAnalytics);
        analytics.setContentAnalytics(contentAnalytics);
        
        return analytics;
    }

    public Report generateReport(String reportType, String startDate, String endDate) {
        Report report = new Report();
        report.setReportType(reportType);
        report.setGeneratedAt(LocalDateTime.now());
        report.setReportData("Report data for " + reportType + " from " + startDate + " to " + endDate);
        return report;
    }

    // Helper methods
    private String checkDatabaseHealth() {
        try {
            userRepository.count();
            return "HEALTHY";
        } catch (Exception e) {
            return "CRITICAL";
        }
    }

    private Double calculateUptime() {
        return 99.95; // Uptime percentage
    }

    private Double calculateAverageResponseTime() {
        return 125.5; // milliseconds
    }

    private Integer getActiveUsersCount() {
        return userRepository.countActiveUsersLast30Minutes();
    }

    private Double calculateCpuUsage() {
        return 15.5; // percentage
    }

    private Double calculateUserGrowthRate() {
        try {
            LocalDateTime oneMonthAgo = LocalDateTime.now().minusMonths(1);
            Long usersLastMonth = userRepository.countByCreatedAtBefore(oneMonthAgo);
            Long usersNow = userRepository.count();
            
            if (usersLastMonth == null || usersLastMonth == 0) {
                return usersNow > 0 ? 100.0 : 0.0;
            }
            
            return ((usersNow - usersLastMonth) / (double) usersLastMonth) * 100.0;
        } catch (Exception e) {
            return 0.0;
        }
    }

    private Double calculateTodayRevenue() {
        LocalDateTime startOfDay = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0);
        Double revenue = transactionRepository.getRevenueSince(startOfDay);
        return revenue != null ? revenue : 0.0;
    }

    private Double calculateMonthlyRevenue() {
        LocalDateTime startOfMonth = LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0).withNano(0);
        Double revenue = transactionRepository.getRevenueSince(startOfMonth);
        return revenue != null ? revenue : 0.0;
    }

    private Double calculatePlatformGrowth() {
        LocalDateTime lastMonth = LocalDateTime.now().minusMonths(1);
        Long usersLastMonth = userRepository.countByCreatedAtBefore(lastMonth);
        Long usersNow = userRepository.count();
        
        if (usersLastMonth == 0) return 100.0;
        return ((usersNow - usersLastMonth) / (double) usersLastMonth) * 100.0;
    }

    private Long calculateActiveSubscriptions() {
        // This would typically come from a subscription repository
        return userRepository.countByStatus("ACTIVE") / 2L; // Example calculation
    }

    private Double calculatePendingPayouts() {
        // This would typically calculate pending payouts to mentors
        return transactionRepository.getPendingPayoutsAmount();
    }
}