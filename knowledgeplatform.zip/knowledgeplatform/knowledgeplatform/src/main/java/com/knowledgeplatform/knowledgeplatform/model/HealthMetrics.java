package com.knowledgeplatform.knowledgeplatform.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "health_metrics")
public class HealthMetrics {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cpu_usage")
    private Double cpuUsage;

    @Column(name = "memory_usage")
    private Double memoryUsage;

    @Column(name = "disk_usage")
    private Double diskUsage;

    @Column(name = "active_users")
    private Integer activeUsers;

    @Column(name = "total_requests")
    private Long totalRequests;

    @Column(name = "error_rate")
    private Double errorRate;

    @Column(name = "response_time")
    private Double responseTime;

    @Column(name = "database_connections")
    private Integer databaseConnections;

    @Column(name = "status")
    private String status; // "HEALTHY", "WARNING", "CRITICAL"

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    // Constructors
    public HealthMetrics() {
        this.createdAt = LocalDateTime.now();
    }

    public HealthMetrics(Double cpuUsage, Double memoryUsage, Double diskUsage, 
                        Integer activeUsers, Long totalRequests, Double errorRate) {
        this();
        this.cpuUsage = cpuUsage;
        this.memoryUsage = memoryUsage;
        this.diskUsage = diskUsage;
        this.activeUsers = activeUsers;
        this.totalRequests = totalRequests;
        this.errorRate = errorRate;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Double getCpuUsage() { return cpuUsage; }
    public void setCpuUsage(Double cpuUsage) { this.cpuUsage = cpuUsage; }

    public Double getMemoryUsage() { return memoryUsage; }
    public void setMemoryUsage(Double memoryUsage) { this.memoryUsage = memoryUsage; }

    public Double getDiskUsage() { return diskUsage; }
    public void setDiskUsage(Double diskUsage) { this.diskUsage = diskUsage; }

    public Integer getActiveUsers() { return activeUsers; }
    public void setActiveUsers(Integer activeUsers) { this.activeUsers = activeUsers; }

    public Long getTotalRequests() { return totalRequests; }
    public void setTotalRequests(long i) { this.totalRequests = i; }

    public Double getErrorRate() { return errorRate; }
    public void setErrorRate(Double errorRate) { this.errorRate = errorRate; }

    public Double getResponseTime() { return responseTime; }
    public void setResponseTime(Double responseTime) { this.responseTime = responseTime; }

    public Integer getDatabaseConnections() { return databaseConnections; }
    public void setDatabaseConnections(Integer databaseConnections) { this.databaseConnections = databaseConnections; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public double getAverageLoad() {
		return AverageLoad;
	}

	public void setAverageLoad(double d) {
		AverageLoad = d;
	}

	private double AverageLoad;


	public void setTotalRequests(Long totalRequests) {
		this.totalRequests = totalRequests;
	}
}