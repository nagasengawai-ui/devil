package com.knowledgeplatform.knowledgeplatform.service;

import java.time.LocalDateTime;
import java.util.List;

// DTO Classes for Admin
public class AdminDashboardStats {
    private Long totalUsers;
    private Long totalMentors;
    private Long totalCourses;
    private Long pendingVerifications;
    private Long pendingCourses;
    private Double todayRevenue;
    private Double platformGrowth;

    // Getters and setters
    public Long getTotalUsers() { return totalUsers; }
    public void setTotalUsers(Long totalUsers) { this.totalUsers = totalUsers; }
    public Long getTotalMentors() { return totalMentors; }
    public void setTotalMentors(Long totalMentors) { this.totalMentors = totalMentors; }
    public Long getTotalCourses() { return totalCourses; }
    public void setTotalCourses(Long totalCourses) { this.totalCourses = totalCourses; }
    public Long getPendingVerifications() { return pendingVerifications; }
    public void setPendingVerifications(Long pendingVerifications) { this.pendingVerifications = pendingVerifications; }
    public Long getPendingCourses() { return pendingCourses; }
    public void setPendingCourses(Long pendingCourses) { this.pendingCourses = pendingCourses; }
    public Double getTodayRevenue() { return todayRevenue; }
    public void setTodayRevenue(Double todayRevenue) { this.todayRevenue = todayRevenue; }
    public Double getPlatformGrowth() { return platformGrowth; }
    public void setPlatformGrowth(Double platformGrowth) { this.platformGrowth = platformGrowth; }
}

// ... Add other DTO classes similarly (UserStats, MentorStats, CourseStats, etc.)