package com.knowledgeplatform.knowledgeplatform.model;

import java.time.LocalDateTime;

public class ContentReport {
    private Long id;
    private String reportId;
    private Long reporterUserId;
    private String reporterName;
    private String reporterEmail;
    private Long reportedEntityId;
    private String reportedEntityType; // COURSE, REVIEW, MENTOR_PROFILE, LIVE_SESSION, COMMENT
    private String reportedEntityTitle;
    private String reportCategory;
    private String reportReason;
    private String detailedDescription;
    private String status; // PENDING, UNDER_REVIEW, RESOLVED, DISMISSED, ESCALATED
    private Integer severity; // 1 (Low) to 5 (Critical)
    private Integer priority; // 1 (Low) to 3 (High)
    private Long assignedAdminId;
    private String assignedAdminName;
    private LocalDateTime reportedAt;
    private LocalDateTime reviewedAt;
    private LocalDateTime resolvedAt;
    private String adminNotes;
    private String resolutionNotes;
    private String resolutionAction; // NO_ACTION, CONTENT_REMOVED, WARNING_ISSUED, USER_SUSPENDED
    private String evidenceUrls; // JSON array of URLs
    private Integer similarReportsCount;
    private Boolean isAnonymous;
    private String reporterIpAddress;
    private String platform; // WEB, MOBILE, TABLET
    private String browserInfo;
    private String metadata;

    // Default constructor
    public ContentReport() {
        this.reportedAt = LocalDateTime.now();
        this.status = Status.PENDING;
        this.severity = 1;
        this.priority = 1;
        this.isAnonymous = false;
        generateReportId();
    }

    // Constructor with required fields
    public ContentReport(Long reporterUserId, Long reportedEntityId, String reportedEntityType, 
                        String reportCategory, String reportReason) {
        this();
        this.reporterUserId = reporterUserId;
        this.reportedEntityId = reportedEntityId;
        this.reportedEntityType = reportedEntityType;
        this.reportCategory = reportCategory;
        this.reportReason = reportReason;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getReportId() { return reportId; }
    public void setReportId(String reportId) { this.reportId = reportId; }

    public Long getReporterUserId() { return reporterUserId; }
    public void setReporterUserId(Long reporterUserId) { this.reporterUserId = reporterUserId; }

    public String getReporterName() { return reporterName; }
    public void setReporterName(String reporterName) { this.reporterName = reporterName; }

    public String getReporterEmail() { return reporterEmail; }
    public void setReporterEmail(String reporterEmail) { this.reporterEmail = reporterEmail; }

    public Long getReportedEntityId() { return reportedEntityId; }
    public void setReportedEntityId(Long reportedEntityId) { this.reportedEntityId = reportedEntityId; }

    public String getReportedEntityType() { return reportedEntityType; }
    public void setReportedEntityType(String reportedEntityType) { this.reportedEntityType = reportedEntityType; }

    public String getReportedEntityTitle() { return reportedEntityTitle; }
    public void setReportedEntityTitle(String reportedEntityTitle) { this.reportedEntityTitle = reportedEntityTitle; }

    public String getReportCategory() { return reportCategory; }
    public void setReportCategory(String reportCategory) { this.reportCategory = reportCategory; }

    public String getReportReason() { return reportReason; }
    public void setReportReason(String reportReason) { this.reportReason = reportReason; }

    public String getDetailedDescription() { return detailedDescription; }
    public void setDetailedDescription(String detailedDescription) { this.detailedDescription = detailedDescription; }

    public String getStatus() { return status; }
    public void setStatus(String status) { 
        this.status = status;
        updateTimestamps();
    }

    public Integer getSeverity() { return severity; }
    public void setSeverity(Integer severity) { 
        this.severity = severity;
        updatePriority();
    }

    public Integer getPriority() { return priority; }
    public void setPriority(Integer priority) { this.priority = priority; }

    public Long getAssignedAdminId() { return assignedAdminId; }
    public void setAssignedAdminId(Long assignedAdminId) { this.assignedAdminId = assignedAdminId; }

    public String getAssignedAdminName() { return assignedAdminName; }
    public void setAssignedAdminName(String assignedAdminName) { this.assignedAdminName = assignedAdminName; }

    public LocalDateTime getReportedAt() { return reportedAt; }
    public void setReportedAt(LocalDateTime reportedAt) { this.reportedAt = reportedAt; }

    public LocalDateTime getReviewedAt() { return reviewedAt; }
    public void setReviewedAt(LocalDateTime reviewedAt) { this.reviewedAt = reviewedAt; }

    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime resolvedAt) { this.resolvedAt = resolvedAt; }

    public String getAdminNotes() { return adminNotes; }
    public void setAdminNotes(String adminNotes) { this.adminNotes = adminNotes; }

    public String getResolutionNotes() { return resolutionNotes; }
    public void setResolutionNotes(String resolutionNotes) { this.resolutionNotes = resolutionNotes; }

    public String getResolutionAction() { return resolutionAction; }
    public void setResolutionAction(String resolutionAction) { this.resolutionAction = resolutionAction; }

    public String getEvidenceUrls() { return evidenceUrls; }
    public void setEvidenceUrls(String evidenceUrls) { this.evidenceUrls = evidenceUrls; }

    public Integer getSimilarReportsCount() { return similarReportsCount; }
    public void setSimilarReportsCount(Integer similarReportsCount) { this.similarReportsCount = similarReportsCount; }

    public Boolean getIsAnonymous() { return isAnonymous; }
    public void setIsAnonymous(Boolean isAnonymous) { this.isAnonymous = isAnonymous; }

    public String getReporterIpAddress() { return reporterIpAddress; }
    public void setReporterIpAddress(String reporterIpAddress) { this.reporterIpAddress = reporterIpAddress; }

    public String getPlatform() { return platform; }
    public void setPlatform(String platform) { this.platform = platform; }

    public String getBrowserInfo() { return browserInfo; }
    public void setBrowserInfo(String browserInfo) { this.browserInfo = browserInfo; }

    public String getMetadata() { return metadata; }
    public void setMetadata(String metadata) { this.metadata = metadata; }

    // Business logic methods
    private void generateReportId() {
        if (this.reportId == null) {
            String timestamp = String.valueOf(System.currentTimeMillis());
            String random = String.valueOf((int) (Math.random() * 1000));
            this.reportId = "REPORT_" + timestamp + "_" + random;
        }
    }

    private void updateTimestamps() {
        LocalDateTime now = LocalDateTime.now();
        
        if (Status.UNDER_REVIEW.equals(this.status) && this.reviewedAt == null) {
            this.reviewedAt = now;
        } else if (Status.RESOLVED.equals(this.status) && this.resolvedAt == null) {
            this.resolvedAt = now;
        } else if (Status.DISMISSED.equals(this.status) && this.resolvedAt == null) {
            this.resolvedAt = now;
        }
    }

    private void updatePriority() {
        if (this.severity != null) {
            if (this.severity >= 4) {
                this.priority = 3; // High priority for critical severity
            } else if (this.severity >= 3) {
                this.priority = 2; // Medium priority
            } else {
                this.priority = 1; // Low priority
            }
        }
    }

    // Utility methods
    public boolean isPending() {
        return Status.PENDING.equals(this.status);
    }

    public boolean isUnderReview() {
        return Status.UNDER_REVIEW.equals(this.status);
    }

    public boolean isResolved() {
        return Status.RESOLVED.equals(this.status);
    }

    public boolean isDismissed() {
        return Status.DISMISSED.equals(this.status);
    }

    public boolean isEscalated() {
        return Status.ESCALATED.equals(this.status);
    }

    public boolean isHighPriority() {
        return this.priority != null && this.priority >= 3;
    }

    public boolean isMediumPriority() {
        return this.priority != null && this.priority == 2;
    }

    public boolean isLowPriority() {
        return this.priority != null && this.priority == 1;
    }

    public boolean isCriticalSeverity() {
        return this.severity != null && this.severity >= 4;
    }

    public boolean isCourseReport() {
        return EntityType.COURSE.equals(this.reportedEntityType);
    }

    public boolean isReviewReport() {
        return EntityType.REVIEW.equals(this.reportedEntityType);
    }

    public boolean isMentorProfileReport() {
        return EntityType.MENTOR_PROFILE.equals(this.reportedEntityType);
    }

    public boolean isLiveSessionReport() {
        return EntityType.LIVE_SESSION.equals(this.reportedEntityType);
    }

    public boolean isCommentReport() {
        return EntityType.COMMENT.equals(this.reportedEntityType);
    }

    public void assignToAdmin(Long adminId, String adminName) {
        this.assignedAdminId = adminId;
        this.assignedAdminName = adminName;
        if (this.isPending()) {
            this.setStatus(Status.UNDER_REVIEW);
        }
    }

    public void resolveReport(String resolutionAction, String resolutionNotes) {
        this.resolutionAction = resolutionAction;
        this.resolutionNotes = resolutionNotes;
        this.setStatus(Status.RESOLVED);
    }

    public void dismissReport(String adminNotes) {
        this.adminNotes = adminNotes;
        this.setStatus(Status.DISMISSED);
    }

    public void escalateReport(String adminNotes) {
        this.adminNotes = adminNotes;
        this.setStatus(Status.ESCALATED);
    }

    public String getPriorityBadge() {
        switch (this.priority) {
            case 3: return "danger";
            case 2: return "warning";
            case 1: return "info";
            default: return "secondary";
        }
    }

    public String getSeverityBadge() {
        switch (this.severity) {
            case 5: return "danger";
            case 4: return "warning";
            case 3: return "info";
            case 2: return "success";
            case 1: return "secondary";
            default: return "light";
        }
    }

    public String getStatusBadge() {
        switch (this.status) {
            case Status.PENDING: return "warning";
            case Status.UNDER_REVIEW: return "info";
            case Status.RESOLVED: return "success";
            case Status.DISMISSED: return "secondary";
            case Status.ESCALATED: return "danger";
            default: return "light";
        }
    }

    public String getEntityTypeIcon() {
        switch (this.reportedEntityType) {
            case EntityType.COURSE: return "📚";
            case EntityType.REVIEW: return "⭐";
            case EntityType.MENTOR_PROFILE: return "👨‍🏫";
            case EntityType.LIVE_SESSION: return "🎥";
            case EntityType.COMMENT: return "💬";
            default: return "📄";
        }
    }

    public Long getDaysSinceReported() {
        if (this.reportedAt == null) return 0L;
        return java.time.Duration.between(this.reportedAt, LocalDateTime.now()).toDays();
    }

    // Builder pattern
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private ContentReport report = new ContentReport();

        public Builder reporterUserId(Long reporterUserId) {
            report.reporterUserId = reporterUserId;
            return this;
        }

        public Builder reporterName(String reporterName) {
            report.reporterName = reporterName;
            return this;
        }

        public Builder reporterEmail(String reporterEmail) {
            report.reporterEmail = reporterEmail;
            return this;
        }

        public Builder reportedEntityId(Long reportedEntityId) {
            report.reportedEntityId = reportedEntityId;
            return this;
        }

        public Builder reportedEntityType(String reportedEntityType) {
            report.reportedEntityType = reportedEntityType;
            return this;
        }

        public Builder reportedEntityTitle(String reportedEntityTitle) {
            report.reportedEntityTitle = reportedEntityTitle;
            return this;
        }

        public Builder reportCategory(String reportCategory) {
            report.reportCategory = reportCategory;
            return this;
        }

        public Builder reportReason(String reportReason) {
            report.reportReason = reportReason;
            return this;
        }

        public Builder detailedDescription(String detailedDescription) {
            report.detailedDescription = detailedDescription;
            return this;
        }

        public Builder severity(Integer severity) {
            report.severity = severity;
            return this;
        }

        public Builder isAnonymous(Boolean isAnonymous) {
            report.isAnonymous = isAnonymous;
            return this;
        }

        public Builder evidenceUrls(String evidenceUrls) {
            report.evidenceUrls = evidenceUrls;
            return this;
        }

        public Builder reporterIpAddress(String reporterIpAddress) {
            report.reporterIpAddress = reporterIpAddress;
            return this;
        }

        public Builder platform(String platform) {
            report.platform = platform;
            return this;
        }

        public Builder browserInfo(String browserInfo) {
            report.browserInfo = browserInfo;
            return this;
        }

        public ContentReport build() {
            report.generateReportId();
            report.updatePriority();
            return report;
        }
    }

    // Status constants
    public static class Status {
        public static final String PENDING = "PENDING";
        public static final String UNDER_REVIEW = "UNDER_REVIEW";
        public static final String RESOLVED = "RESOLVED";
        public static final String DISMISSED = "DISMISSED";
        public static final String ESCALATED = "ESCALATED";
    }

    // Entity type constants
    public static class EntityType {
        public static final String COURSE = "COURSE";
        public static final String REVIEW = "REVIEW";
        public static final String MENTOR_PROFILE = "MENTOR_PROFILE";
        public static final String LIVE_SESSION = "LIVE_SESSION";
        public static final String COMMENT = "COMMENT";
        public static final String MESSAGE = "MESSAGE";
        public static final String FORUM_POST = "FORUM_POST";
    }

    // Report category constants
    public static class Category {
        public static final String INAPPROPRIATE_CONTENT = "INAPPROPRIATE_CONTENT";
        public static final String COPYRIGHT_INFRINGEMENT = "COPYRIGHT_INFRINGEMENT";
        public static final String SPAM = "SPAM";
        public static final String HARASSMENT = "HARASSMENT";
        public static final String MISLEADING = "MISLEADING";
        public static final String PLAGIARISM = "PLAGIARISM";
        public static final String FALSE_INFORMATION = "FALSE_INFORMATION";
        public static final String TECHNICAL_ISSUE = "TECHNICAL_ISSUE";
        public static final String PRIVACY_VIOLATION = "PRIVACY_VIOLATION";
        public static final String OTHER = "OTHER";
    }

    // Resolution action constants
    public static class ResolutionAction {
        public static final String NO_ACTION = "NO_ACTION";
        public static final String CONTENT_REMOVED = "CONTENT_REMOVED";
        public static final String CONTENT_EDITED = "CONTENT_EDITED";
        public static final String WARNING_ISSUED = "WARNING_ISSUED";
        public static final String USER_SUSPENDED = "USER_SUSPENDED";
        public static final String USER_BANNED = "USER_BANNED";
        public static final String CONTENT_RESTORED = "CONTENT_RESTORED";
        public static final String ESCALATED_TO_LEGAL = "ESCALATED_TO_LEGAL";
    }

    // Platform constants
    public static class Platform {
        public static final String WEB = "WEB";
        public static final String MOBILE = "MOBILE";
        public static final String TABLET = "TABLET";
    }

    @Override
    public String toString() {
        return "ContentReport{" +
                "id=" + id +
                ", reportId='" + reportId + '\'' +
                ", reportedEntityType='" + reportedEntityType + '\'' +
                ", reportCategory='" + reportCategory + '\'' +
                ", status='" + status + '\'' +
                ", severity=" + severity +
                ", priority=" + priority +
                ", reportedAt=" + reportedAt +
                '}';
    }
}