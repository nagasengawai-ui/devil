package com.knowledgeplatform.knowledgeplatform.repository;

public interface courseLectureRepository {

}
