package com.knowledgeplatform.knowledgeplatform.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table(name = "courses")
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Size(max = 255)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(columnDefinition = "TEXT")
    private String shortDescription;

    private String category;
    private String subcategory;
    private String level;
    private String language = "English";
    private String thumbnailUrl;

    @DecimalMin("0.0")
    private Double price = 0.0;

    @DecimalMin("0.0")
    private Double discountedPrice;

    private Boolean isFree = false;
    private Boolean hasDiscount = false;

    private Integer totalVideoHours = 0;
    private Integer totalLectures = 0;
    private Integer totalArticles = 0;
    private Integer totalDownloads = 0;

    @ElementCollection
    private List<String> learningObjectives = new ArrayList<>();

    private String status = "DRAFT";
    private Boolean isApproved = false;
    private LocalDateTime publishedAt;

    private Integer totalEnrollments = 0;
    private Double averageRating = 0.0;
    private Integer totalReviews = 0;
    private Long totalViews = 0L;
    private Double completionRate = 0.0;
    private Double trendingScore = 0.0;

    private String rejectionNotes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mentor_id", nullable = false)
    private MentorProfile mentor;


    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CourseSection> sections = new ArrayList<>();

    @OneToMany(mappedBy = "course")
    private List<Enrollment> enrollments = new ArrayList<>();

    @OneToMany(mappedBy = "course")
    private List<Review> reviews = new ArrayList<>();

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public Course() {}

    public Course(String title, String description, MentorProfile mentor) {
        this.title = title;
        this.description = description;
        this.mentor = mentor;
    }

    // Business Methods
    public boolean isPublished() {
        return "PUBLISHED".equals(status);
    }

    public boolean canEnroll() {
        return isPublished() && (isFree || price > 0);
    }

    public Double getCurrentPrice() {
        return hasDiscount && discountedPrice != null ? discountedPrice : price;
    }

    public Double calculateRevenue() {
        return getCurrentPrice() * totalEnrollments;
    }

    public void addEnrollment() {
        this.totalEnrollments++;
    }

    public void updateRating(Integer newRating) {
        if (totalReviews == null) totalReviews = 0;
        if (averageRating == null) averageRating = 0.0;
        
        double currentTotal = averageRating * totalReviews;
        totalReviews++;
        averageRating = (currentTotal + newRating) / totalReviews;
    }

    public String getStatusBadge() {
        switch (status) {
            case "PUBLISHED": return "🟢 Published";
            case "DRAFT": return "⚫ Draft";
            case "PENDING": return "🟡 Pending Review";
            case "REJECTED": return "🔴 Rejected";
            default: return "⚪ Unknown";
        }
    }

    public Integer getTotalContentItems() {
        return sections.stream()
                .mapToInt(section -> section.getLectures().size())
                .sum();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getShortDescription() { return shortDescription; }
    public void setShortDescription(String shortDescription) { this.shortDescription = shortDescription; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getSubcategory() { return subcategory; }
    public void setSubcategory(String subcategory) { this.subcategory = subcategory; }
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
    public String getThumbnailUrl() { return thumbnailUrl; }
    public void setThumbnailUrl(String thumbnailUrl) { this.thumbnailUrl = thumbnailUrl; }
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }
    public Double getDiscountedPrice() { return discountedPrice; }
    public void setDiscountedPrice(Double discountedPrice) { this.discountedPrice = discountedPrice; }
    public Boolean getIsFree() { return isFree; }
    public void setIsFree(Boolean isFree) { this.isFree = isFree; }
    public Boolean getHasDiscount() { return hasDiscount; }
    public void setHasDiscount(Boolean hasDiscount) { this.hasDiscount = hasDiscount; }
    public Integer getTotalVideoHours() { return totalVideoHours; }
    public void setTotalVideoHours(Integer totalVideoHours) { this.totalVideoHours = totalVideoHours; }
    public Integer getTotalLectures() { return totalLectures; }
    public void setTotalLectures(Integer totalLectures) { this.totalLectures = totalLectures; }
    public Integer getTotalArticles() { return totalArticles; }
    public void setTotalArticles(Integer totalArticles) { this.totalArticles = totalArticles; }
    public Integer getTotalDownloads() { return totalDownloads; }
    public void setTotalDownloads(Integer totalDownloads) { this.totalDownloads = totalDownloads; }
    public List<String> getLearningObjectives() { return learningObjectives; }
    public void setLearningObjectives(List<String> learningObjectives) { this.learningObjectives = learningObjectives; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Boolean getIsApproved() { return isApproved; }
    public void setIsApproved(Boolean isApproved) { this.isApproved = isApproved; }
    public LocalDateTime getPublishedAt() { return publishedAt; }
    public void setPublishedAt(LocalDateTime publishedAt) { this.publishedAt = publishedAt; }
    public Integer getTotalEnrollments() { return totalEnrollments; }
    public void setTotalEnrollments(Integer totalEnrollments) { this.totalEnrollments = totalEnrollments; }
    public Double getAverageRating() { return averageRating; }
    public void setAverageRating(Double averageRating) { this.averageRating = averageRating; }
    public Integer getTotalReviews() { return totalReviews; }
    public void setTotalReviews(Integer totalReviews) { this.totalReviews = totalReviews; }
    public Long getTotalViews() { return totalViews; }
    public void setTotalViews(Long totalViews) { this.totalViews = totalViews; }
    public Double getCompletionRate() { return completionRate; }
    public void setCompletionRate(Double completionRate) { this.completionRate = completionRate; }
    public Double getTrendingScore() { return trendingScore; }
    public void setTrendingScore(Double trendingScore) { this.trendingScore = trendingScore; }
    public String getRejectionNotes() { return rejectionNotes; }
    public void setRejectionNotes(String rejectionNotes) { this.rejectionNotes = rejectionNotes; }
    public MentorProfile getMentor() { return mentor; }
    public void setMentor(MentorProfile mentor) { this.mentor = mentor; }
    public List<CourseSection> getSections() { return sections; }
    public void setSections(List<CourseSection> sections) { this.sections = sections; }
    public List<Enrollment> getEnrollments() { return enrollments; }
    public void setEnrollments(List<Enrollment> enrollments) { this.enrollments = enrollments; }
    public List<Review> getReviews() { return reviews; }
    public void setReviews(List<Review> reviews) { this.reviews = reviews; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}