package com.knowledgeplatform.knowledgeplatform.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.knowledgeplatform.knowledgeplatform.dto.CourseProgress;
import com.knowledgeplatform.knowledgeplatform.dto.UserStats;
import com.knowledgeplatform.knowledgeplatform.model.AISuggestions;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.service.AIService;
import com.knowledgeplatform.knowledgeplatform.service.PaymentService;
import com.knowledgeplatform.knowledgeplatform.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private PaymentService paymentService;

    // User Profile Page
    @GetMapping("/profile")
    public String profile(Model model, Principal principal) {
        User user = getUserFromPrincipal(principal);
        UserStats stats = userService.getUserStats(user.getId());

        model.addAttribute("user", user);
        model.addAttribute("stats", stats);
        model.addAttribute("enrollments", user.getEnrollments());

        return "user/profile";
    }

    // Edit Profile
    @GetMapping("/profile/edit")
    public String editProfile(Model model, Principal principal) {
        User user = getUserFromPrincipal(principal);
        model.addAttribute("user", user);
        return "user/edit-profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@ModelAttribute User updatedUser, 
                              Principal principal,
                              RedirectAttributes redirectAttributes) {
        User currentUser = getUserFromPrincipal(principal);
        
        try {
            User updated = userService.updateUserProfile(currentUser.getId(), updatedUser);
            redirectAttributes.addFlashAttribute("success", "Profile updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update profile: " + e.getMessage());
        }

        return "redirect:/user/profile";
    }

    // Wallet Management
    @GetMapping("/wallet")
    public String wallet(Model model, Principal principal) {
        User user = getUserFromPrincipal(principal);
        model.addAttribute("user", user);
        model.addAttribute("transactions", getTransactionHistory(user.getId()));
        
        return "user/wallet";
    }

    @PostMapping("/wallet/topup")
    public String topUpWallet(@RequestParam Double amount,
                            @RequestParam String paymentMethod,
                            Principal principal,
                            RedirectAttributes redirectAttributes) {
        User user = getUserFromPrincipal(principal);
        
        try {
            User updatedUser = paymentService.topUpWallet(user.getId(), amount, paymentMethod);
            redirectAttributes.addFlashAttribute("success", 
                String.format("Successfully added $%.2f to your wallet", amount));
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Top-up failed: " + e.getMessage());
        }

        return "redirect:/user/wallet";
    }

    // Become Mentor
    @GetMapping("/become-mentor")
    public String becomeMentorForm(Model model, Principal principal) {
        User user = getUserFromPrincipal(principal);
        
        if (user.isMentor()) {
            return "redirect:/mentor/dashboard";
        }

        model.addAttribute("user", user);
        return "user/become-mentor";
    }

    @PostMapping("/become-mentor")
    public String becomeMentor(@ModelAttribute MentorApplication application,
                             Principal principal,
                             RedirectAttributes redirectAttributes) {
        User user = getUserFromPrincipal(principal);
        
        try {
            userService.becomeMentor(user.getId(), application.toMentorProfile());
            redirectAttributes.addFlashAttribute("success", 
                "Mentor application submitted! We'll review it within 24 hours.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Application failed: " + e.getMessage());
        }

        return "redirect:/user/profile";
    }

    // Learning Dashboard
    @GetMapping("/learning")
    public String learningDashboard(Model model, Principal principal) {
        User user = getUserFromPrincipal(principal);
        List<CourseProgress> progressList = getCourseProgressList(user.getId());
        AISuggestions suggestions = aiService.getSuggestionsForUser(user.getId());

        model.addAttribute("user", user);
        model.addAttribute("progressList", progressList);
        model.addAttribute("suggestions", suggestions);

        return "user/learning-dashboard";
    }

    // Settings
    @GetMapping("/settings")
    public String settings(Model model, Principal principal) {
        User user = getUserFromPrincipal(principal);
        model.addAttribute("user", user);
        return "user/settings";
    }

    private User getUserFromPrincipal(Principal principal) {
        return userService.getUserByEmail(principal.getName());
    }

    private List<Transaction> getTransactionHistory(Long userId) {
        // Implementation to get transaction history
        return List.of(); // Placeholder
    }

    private List<CourseProgress> getCourseProgressList(Long userId) {
        // Implementation to get course progress for all enrolled courses
        return List.of(); // Placeholder
    }

    @Autowired
    private AIService aiService;
}

// DTO for mentor application
class MentorApplication {
    private String professionalTitle;
    private String bio;
    private List<String> expertiseAreas;
    private List<String> skills;
    private Integer yearsOfExperience;
    private String company;
    private String website;
    private List<String> socialLinks;

    public MentorProfile toMentorProfile() {
        MentorProfile profile = new MentorProfile();
        profile.setProfessionalTitle(this.professionalTitle);
        profile.setBio(this.bio);
        profile.setExpertiseAreas(this.expertiseAreas);
        profile.setSkills(this.skills);
        profile.setYearsOfExperience(this.yearsOfExperience);
        profile.setCompany(this.company);
        profile.setWebsite(this.website);
        profile.setSocialLinks(this.socialLinks);
        profile.setOffersMentoring(true);
        
        return profile;
    }

    // Getters and setters
    public String getProfessionalTitle() { return professionalTitle; }
    public void setProfessionalTitle(String professionalTitle) { this.professionalTitle = professionalTitle; }
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    public List<String> getExpertiseAreas() { return expertiseAreas; }
    public void setExpertiseAreas(List<String> expertiseAreas) { this.expertiseAreas = expertiseAreas; }
    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }
    public Integer getYearsOfExperience() { return yearsOfExperience; }
    public void setYearsOfExperience(Integer yearsOfExperience) { this.yearsOfExperience = yearsOfExperience; }
    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }
    public String getWebsite() { return website; }
    public void setWebsite(String website) { this.website = website; }
    public List<String> getSocialLinks() { return socialLinks; }
    public void setSocialLinks(List<String> socialLinks) { this.socialLinks = socialLinks; }
}

// Transaction entity (simplified)
class Transaction {
    private String id;
    private Double amount;
    private String type;
    private String description;
    private String status;
    // ... other fields
}