package com.knowledgeplatform.knowledgeplatform.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "user_growth")
public class UserGrowth {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "period_date")
    private LocalDateTime periodDate;

    @Column(name = "new_users")
    private Integer newUsers;

    @Column(name = "total_users")
    private Integer totalUsers;

    @Column(name = "growth_rate")
    private Double growthRate;

    @Column(name = "active_users")
    private Integer activeUsers;

    @Column(name = "retention_rate")
    private Double retentionRate;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "monthlyGrowth")
    private String monthlyGrowth;
    public String getMonthlyGrowth() {
		return monthlyGrowth;
	}

	public void setMonthlyGrowth(String monthlyGrowth) {
		this.monthlyGrowth = monthlyGrowth;
	}

	// Constructors
    public UserGrowth() {
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getPeriodDate() { return periodDate; }
    public void setPeriodDate(LocalDateTime periodDate) { this.periodDate = periodDate; }

    public Integer getNewUsers() { return newUsers; }
    public void setNewUsers(Integer newUsers) { this.newUsers = newUsers; }

    public Integer getTotalUsers() { return totalUsers; }
    public void setTotalUsers(Integer totalUsers) { this.totalUsers = totalUsers; }

    public Double getGrowthRate() { return growthRate; }
    public void setGrowthRate(Double growthRate) { this.growthRate = growthRate; }

    public Integer getActiveUsers() { return activeUsers; }
    public void setActiveUsers(Integer activeUsers) { this.activeUsers = activeUsers; }

    public Double getRetentionRate() { return retentionRate; }
    public void setRetentionRate(Double retentionRate) { this.retentionRate = retentionRate; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
