package com.knowledgeplatform.knowledgeplatform.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.Review;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    // Find reviews by course ID
    List<Review> findByCourseId(Long courseId);
    
    // Find reviews by mentor ID
    List<Review> findByMentorId(Long mentorId);
    
    // Find reviews by user ID
    List<Review> findByUserId(Long userId);
    
    // Find review by user and course (to prevent duplicate reviews)
    Optional<Review> findByUserIdAndCourseId(Long userId, Long courseId);
    
    // Find review by user and mentor
    Optional<Review> findByUserIdAndMentorId(Long userId, Long mentorId);
    
    // Find reviews by rating
    List<Review> findByRating(Integer rating);
    
    // Find reviews with rating greater than or equal to
    List<Review> findByRatingGreaterThanEqual(Integer minRating);
    
    // Find reviews by course and rating
    List<Review> findByCourseIdAndRating(Long courseId, Integer rating);
    
    // Calculate average rating for a course
    @Query("SELECT COALESCE(AVG(r.rating), 0) FROM Review r WHERE r.course.id = :courseId")
    Double calculateAverageRatingByCourseId(@Param("courseId") Long courseId);
    
    // Calculate average rating for a mentor
    @Query("SELECT COALESCE(AVG(r.rating), 0) FROM Review r WHERE r.mentor.id = :mentorId")
    Double calculateAverageRatingByMentorId(@Param("mentorId") Long mentorId);
    
    // Count reviews by course
    Long countByCourseId(Long courseId);
    
    // Count reviews by mentor
    Long countByMentorId(Long mentorId);
    
    // Count reviews by rating for a course
    @Query("SELECT COUNT(r) FROM Review r WHERE r.course.id = :courseId AND r.rating = :rating")
    Long countByCourseIdAndRating(@Param("courseId") Long courseId, @Param("rating") Integer rating);
    
    // Get recent reviews for a course
    List<Review> findByCourseIdOrderByCreatedAtDesc(Long courseId);
    
    // Get recent reviews for a mentor
    List<Review> findByMentorIdOrderByCreatedAtDesc(Long mentorId);
    
    // Get top rated reviews (4-5 stars)
    List<Review> findByRatingBetweenOrderByCreatedAtDesc(Integer minRating, Integer maxRating);
    
    // Check if user has reviewed a course
    Boolean existsByUserIdAndCourseId(Long userId, Long courseId);
    
    // Check if user has reviewed a mentor
    Boolean existsByUserIdAndMentorId(Long userId, Long mentorId);
    
    // Find reviews with comments (not empty)
    List<Review> findByCommentIsNotNull();
    
    // Find reviews by course with comments
    List<Review> findByCourseIdAndCommentIsNotNull(Long courseId);

	List<Review> findByCourseIdAndIsVerifiedTrue(Long courseId);
}