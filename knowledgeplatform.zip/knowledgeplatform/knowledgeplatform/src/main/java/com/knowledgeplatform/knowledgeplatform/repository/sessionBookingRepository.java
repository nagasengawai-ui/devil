package com.knowledgeplatform.knowledgeplatform.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.LiveSession;

@Repository
public interface sessionBookingRepository extends JpaRepository<LiveSession, Long> {
    
    List<LiveSession> findByMentorId(Long mentorId);
    List<LiveSession> findByMentorIdAndScheduledAtAfter(Long mentorId, LocalDateTime date);
    List<LiveSession> findByStatus(String status);
    List<LiveSession> findByStatusAndScheduledAtAfter(String status, LocalDateTime date);
    List<LiveSession> findByCategoryAndStatusAndScheduledAtAfter(String category, String status, LocalDateTime date);
    List<LiveSession> findByScheduledAtAfterAndStatus(LocalDateTime date, String status);
    
    @Query("SELECT ls FROM LiveSession ls WHERE ls.title LIKE %:query% OR ls.description LIKE %:query% OR ls.category LIKE %:query%")
    List<LiveSession> searchSessions(@Param("query") String query);
    
    @Query("SELECT ls FROM LiveSession ls WHERE ls.status = 'AVAILABLE' AND ls.scheduledAt > :now ORDER BY ls.totalBookings DESC LIMIT :limit")
    List<LiveSession> findTopByOrderByTotalBookingsDesc(@Param("limit") int limit);
    
    @Query("SELECT COUNT(ls) FROM LiveSession ls WHERE ls.mentor.id = :mentorId AND ls.status = 'COMPLETED'")
    Long countCompletedSessionsByMentor(@Param("mentorId") Long mentorId);
}