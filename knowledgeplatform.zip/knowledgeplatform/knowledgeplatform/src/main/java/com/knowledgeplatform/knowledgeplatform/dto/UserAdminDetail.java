package com.knowledgeplatform.knowledgeplatform.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.knowledgeplatform.knowledgeplatform.model.Enrollment;
import com.knowledgeplatform.knowledgeplatform.model.FinancialTransaction;
import com.knowledgeplatform.knowledgeplatform.model.Review;
import com.knowledgeplatform.knowledgeplatform.model.User;

public class UserAdminDetail {
    private Long id;
    private String email;
    private String firstName;
    private String lastName;
    private String role;
    private boolean emailVerified;
    private boolean profileCompleted;
    private String status;
    private LocalDateTime createdAt;
    private int coursesCompleted;
    private int sessionsAttended;
    private int totalEnrollments;
    public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	private User user;
	private List<FinancialTransaction> transactions;
	private List<Review> reviews;
    
    // Constructors
    public UserAdminDetail() {}
    
    public UserAdminDetail(Long id, String email, String firstName, String lastName, 
                          String role, boolean emailVerified, boolean profileCompleted, 
                          String status, LocalDateTime createdAt, int coursesCompleted, 
                          int sessionsAttended, int totalEnrollments) {
        this.id = id;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.role = role;
        this.emailVerified = emailVerified;
        this.profileCompleted = profileCompleted;
        this.status = status;
        this.createdAt = createdAt;
        this.coursesCompleted = coursesCompleted;
        this.sessionsAttended = sessionsAttended;
        this.totalEnrollments = totalEnrollments;
    }
    
    // Getters and setters for all fields
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    
    public boolean isEmailVerified() { return emailVerified; }
    public void setEmailVerified(boolean emailVerified) { this.emailVerified = emailVerified; }
    
    public boolean isProfileCompleted() { return profileCompleted; }
    public void setProfileCompleted(boolean profileCompleted) { this.profileCompleted = profileCompleted; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public int getCoursesCompleted() { return coursesCompleted; }
    public void setCoursesCompleted(int coursesCompleted) { this.coursesCompleted = coursesCompleted; }
    
    public int getSessionsAttended() { return sessionsAttended; }
    public void setSessionsAttended(int sessionsAttended) { this.sessionsAttended = sessionsAttended; }
    
    public void setTotalEnrollments(List<Enrollment> enrollments) {
        if (enrollments != null)
			this.totalEnrollments = enrollments.size();
		else
			this.totalEnrollments = 0;
    }


    public void setTransactions(List<FinancialTransaction> transactions) {
        this.transactions = transactions;
    }
    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

	public void setTotalEnrollments(Long countByUserId) {
		// TODO Auto-generated method stub
		
	}}
    



