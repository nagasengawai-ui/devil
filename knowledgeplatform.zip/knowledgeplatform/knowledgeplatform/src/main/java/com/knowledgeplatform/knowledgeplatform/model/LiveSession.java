package com.knowledgeplatform.knowledgeplatform.model;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "live_sessions")
public class LiveSession {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String title;

    private String description;
    private String category;
    
    @NotBlank
    private String sessionType;

    private LocalDateTime scheduledAt;
    
    @Min(1)
    private Integer duration;

    @Min(0)
    private Integer bufferTime = 5;

    @Min(0)
    private Double pricePerMinute;

    @Min(0)
    private Double fixedPrice;

    private Boolean isFree = false;
    private Boolean freeTrialEnabled = true;
    
    @Min(1)
    private Integer freeTrialMinutes = 1;

    @Min(1)
    private Integer maxParticipants = 1;

    @Min(0)
    private Integer currentParticipants = 0;

    private String status = "AVAILABLE";
    private Boolean isActive = true;

    private String webRtcSessionId;
    private String twilioRoomId;
    private String callRecordingUrl;

    @Min(0)
    private Integer totalBookings = 0;

    @Min(0)
    private Double averageRating = 0.0;

    @Min(0)
    private Long totalViews = 0L;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mentor_id", nullable = false)
    private MentorProfile mentor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id")
    private Course course;

    @OneToMany(mappedBy = "session")
    private List<SessionBooking> bookings = new ArrayList<>();

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Business Methods
    public boolean isAvailableForBooking() {
        return "AVAILABLE".equals(status) && 
               currentParticipants < maxParticipants &&
               isActive &&
               (scheduledAt == null || scheduledAt.isAfter(LocalDateTime.now()));
    }

    public Double calculateCost(Integer minutes) {
        if (isFree) return 0.0;
        if (fixedPrice != null) return fixedPrice;
        if (pricePerMinute != null) return pricePerMinute * minutes;
        return 0.0;
    }

    public void addBooking() {
        this.totalBookings++;
        this.currentParticipants++;
        if (currentParticipants >= maxParticipants) {
            this.status = "BOOKED";
        }
    }

    public void completeSession() {
        this.status = "COMPLETED";
        this.currentParticipants = 0;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getSessionType() { return sessionType; }
    public void setSessionType(String sessionType) { this.sessionType = sessionType; }
    public LocalDateTime getScheduledAt() { return scheduledAt; }
    public void setScheduledAt(LocalDateTime scheduledAt) { this.scheduledAt = scheduledAt; }
    public Integer getDuration() { return duration; }
    public void setDuration(Integer duration) { this.duration = duration; }
    public Integer getBufferTime() { return bufferTime; }
    public void setBufferTime(Integer bufferTime) { this.bufferTime = bufferTime; }
    public Double getPricePerMinute() { return pricePerMinute; }
    public void setPricePerMinute(Double pricePerMinute) { this.pricePerMinute = pricePerMinute; }
    public Double getFixedPrice() { return fixedPrice; }
    public void setFixedPrice(Double fixedPrice) { this.fixedPrice = fixedPrice; }
    public Boolean getIsFree() { return isFree; }
    public void setIsFree(Boolean isFree) { this.isFree = isFree; }
    public Boolean getFreeTrialEnabled() { return freeTrialEnabled; }
    public void setFreeTrialEnabled(Boolean freeTrialEnabled) { this.freeTrialEnabled = freeTrialEnabled; }
    public Integer getFreeTrialMinutes() { return freeTrialMinutes; }
    public void setFreeTrialMinutes(Integer freeTrialMinutes) { this.freeTrialMinutes = freeTrialMinutes; }
    public Integer getMaxParticipants() { return maxParticipants; }
    public void setMaxParticipants(Integer maxParticipants) { this.maxParticipants = maxParticipants; }
    public Integer getCurrentParticipants() { return currentParticipants; }
    public void setCurrentParticipants(Integer currentParticipants) { this.currentParticipants = currentParticipants; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
    public String getWebRtcSessionId() { return webRtcSessionId; }
    public void setWebRtcSessionId(String webRtcSessionId) { this.webRtcSessionId = webRtcSessionId; }
    public String getTwilioRoomId() { return twilioRoomId; }
    public void setTwilioRoomId(String twilioRoomId) { this.twilioRoomId = twilioRoomId; }
    public String getCallRecordingUrl() { return callRecordingUrl; }
    public void setCallRecordingUrl(String callRecordingUrl) { this.callRecordingUrl = callRecordingUrl; }
    public Integer getTotalBookings() { return totalBookings; }
    public void setTotalBookings(Integer totalBookings) { this.totalBookings = totalBookings; }
    public Double getAverageRating() { return averageRating; }
    public void setAverageRating(Double averageRating) { this.averageRating = averageRating; }
    public Long getTotalViews() { return totalViews; }
    public void setTotalViews(Long totalViews) { this.totalViews = totalViews; }
    public MentorProfile getMentor() { return mentor; }
    public void setMentor(MentorProfile mentor) { this.mentor = mentor; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    public List<SessionBooking> getBookings() { return bookings; }
    public void setBookings(List<SessionBooking> bookings) { this.bookings = bookings; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public boolean canStartFreeTrial(User user) {
        if (user == null) {
            return false;
        }
        
        // User hasn't used free trial before and account is in good standing
        return !user.hasUsedFreeTrial() && user.isAccountActive();
    }

	


}