package com.knowledgeplatform.knowledgeplatform.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.knowledgeplatform.knowledgeplatform.dto.AdminDashboardStats;
import com.knowledgeplatform.knowledgeplatform.dto.ContentOverview;
import com.knowledgeplatform.knowledgeplatform.dto.CourseStats;
import com.knowledgeplatform.knowledgeplatform.dto.PayoutRequest;
import com.knowledgeplatform.knowledgeplatform.dto.PlatformAnalytics;
import com.knowledgeplatform.knowledgeplatform.dto.PlatformRevenue;
import com.knowledgeplatform.knowledgeplatform.dto.PlatformSettings;
import com.knowledgeplatform.knowledgeplatform.dto.UserAdminDetail;
import com.knowledgeplatform.knowledgeplatform.dto.UserStats;
import com.knowledgeplatform.knowledgeplatform.model.ContentReport;
import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.FinancialTransaction;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;
import com.knowledgeplatform.knowledgeplatform.model.MentorStats;
import com.knowledgeplatform.knowledgeplatform.model.PlatformActivity;
import com.knowledgeplatform.knowledgeplatform.model.Report;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.service.AdminService;
import com.knowledgeplatform.knowledgeplatform.service.CourseService;
import com.knowledgeplatform.knowledgeplatform.service.MentorService;
import com.knowledgeplatform.knowledgeplatform.service.UserService;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private MentorService mentorService;

    @Autowired
    private CourseService courseService;

    @Autowired
    private AdminService adminService;

    // Admin Dashboard Overview
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        AdminDashboardStats stats = adminService.getDashboardStats();
        PlatformRevenue revenue = adminService.getPlatformRevenue();
        List<PlatformActivity> recentActivities = adminService.getRecentActivities();

        model.addAttribute("stats", stats);
        model.addAttribute("revenue", revenue);
        model.addAttribute("recentActivities", recentActivities);
        model.addAttribute("systemHealth", adminService.getSystemHealth());

        return "admin/dashboard";
    }

    // User Management
    @GetMapping("/users")
    public String userManagement(@RequestParam(required = false) String search,
                               @RequestParam(required = false) String status,
                               Model model) {
        List<User> users = adminService.getUsers(search, status);
        UserStats userStats = adminService.getUserStats();

        model.addAttribute("users", users);
        model.addAttribute("userStats", userStats);
        model.addAttribute("search", search);
        model.addAttribute("status", status);

        return "admin/users/list";
    }

    @GetMapping("/users/{userId}")
    public String userDetail(@PathVariable Long userId, Model model) {
        User user = userService.getUserById(userId);
        UserAdminDetail userDetail = adminService.getUserAdminDetail(userId);

        model.addAttribute("user", user);
        model.addAttribute("userDetail", userDetail);

        return "admin/users/detail";
    }

    @PostMapping("/users/{userId}/status")
    public String updateUserStatus(@PathVariable Long userId,
                                 @RequestParam String status,
                                 @RequestParam(required = false) String reason) {
        adminService.updateUserStatus(userId, status, reason);
        return "redirect:/admin/users/" + userId;
    }

    // Mentor Verification
    @GetMapping("/mentors/verification")
    public String mentorVerification(Model model) {
        List<MentorProfile> pendingMentors = adminService.getPendingMentorVerifications();
        List<MentorProfile> rejectedMentors = adminService.getRejectedMentors();

        model.addAttribute("pendingMentors", pendingMentors);
        model.addAttribute("rejectedMentors", rejectedMentors);

        return "admin/mentors/verification";
    }

    @PostMapping("/mentors/{mentorId}/verify")
    public String verifyMentor(@PathVariable Long mentorId,
                             @RequestParam Boolean approved,
                             @RequestParam(required = false) String notes) {
        mentorService.verifyMentor(mentorId, approved, notes);
        return "redirect:/admin/mentors/verification";
    }

    @GetMapping("/mentors")
    public String mentorManagement(@RequestParam(required = false) String search,
                                 @RequestParam(required = false) String status,
                                 Model model) {
        List<MentorProfile> mentors = adminService.getMentors(search, status);
        MentorStats mentorStats = adminService.getMentorStats();

        model.addAttribute("mentors", mentors);
        model.addAttribute("mentorStats", mentorStats);

        return "admin/mentors/list";
    }

    // Course Moderation
    @GetMapping("/courses/moderation")
    public String courseModeration(Model model) {
        List<Course> pendingCourses = courseService.getPendingReviewCourses();
        List<Course> flaggedCourses = adminService.getFlaggedCourses();

        model.addAttribute("pendingCourses", pendingCourses);
        model.addAttribute("flaggedCourses", flaggedCourses);

        return "admin/courses/moderation";
    }

    @PostMapping("/courses/{courseId}/approve")
    public String approveCourse(@PathVariable Long courseId,
                              @RequestParam String action, // APPROVE, REJECT, REQUEST_CHANGES
                              @RequestParam(required = false) String notes) {
        if ("APPROVE".equals(action)) {
            courseService.publishCourse(courseId);
        } else if ("REJECT".equals(action)) {
            courseService.rejectCourse(courseId, notes != null ? notes : "No reason provided");
        } else if ("REQUEST_CHANGES".equals(action)) {
            adminService.requestCourseChanges(courseId, notes != null ? notes : "Changes requested");
        }

        return "redirect:/admin/courses/moderation";
    }

    @GetMapping("/courses")
    public String courseManagement(@RequestParam(required = false) String search,
                                 @RequestParam(required = false) String status,
                                 Model model) {
        List<Course> courses = adminService.getCourses(search, status);
        CourseStats courseStats = adminService.getCourseStats();

        model.addAttribute("courses", courses);
        model.addAttribute("courseStats", courseStats);

        return "admin/courses/list";
    }

    // Financial Management
    @GetMapping("/finance")
    public String financeDashboard(Model model) {
        PlatformRevenue revenue = adminService.getPlatformRevenue();
        List<FinancialTransaction> recentTransactions = adminService.getRecentTransactions();
        List<PayoutRequest> pendingPayouts = adminService.getPendingPayouts();

        model.addAttribute("revenue", revenue);
        model.addAttribute("recentTransactions", recentTransactions);
        model.addAttribute("pendingPayouts", pendingPayouts);

        return "admin/finance/dashboard";
    }

    @GetMapping("/finance/transactions")
    public String transactionHistory(@RequestParam(required = false) String type,
                                   @RequestParam(required = false) String status,
                                   Model model) {
        List<FinancialTransaction> transactions = adminService.getTransactions(type, status);

        model.addAttribute("transactions", transactions);
        model.addAttribute("totalAmount", calculateTotalAmount(transactions));

        return "admin/finance/transactions";
    }

    @PostMapping("/finance/payouts/{payoutId}/process")
    public String processPayout(@PathVariable Long payoutId) {
        adminService.processPayout(payoutId);
        return "redirect:/admin/finance";
    }

    // Content Management
    @GetMapping("/content")
    public String contentManagement(Model model) {
        ContentOverview overview = adminService.getContentOverview();
        List<ContentReport> reportedContent = adminService.getReportedContent();

        model.addAttribute("overview", overview);
        model.addAttribute("reportedContent", reportedContent);

        return "admin/content/dashboard";
    }

    // System Settings
    @GetMapping("/settings")
    public String systemSettings(Model model) {
        PlatformSettings settings = adminService.getPlatformSettings();
        model.addAttribute("settings", settings);
        return "admin/settings";
    }

    @PostMapping("/settings/update")
    public String updateSettings(@ModelAttribute PlatformSettings settings) {
        adminService.updatePlatformSettings(settings);
        return "redirect:/admin/settings";
    }

    // Analytics & Reports
    @GetMapping("/analytics")
    public String analyticsDashboard(Model model) {
        PlatformAnalytics analytics = adminService.getPlatformAnalytics();
        model.addAttribute("analytics", analytics);
        return "admin/analytics/dashboard";
    }

    @GetMapping("/reports/generate")
    public String generateReport(@RequestParam String reportType,
                               @RequestParam String startDate,
                               @RequestParam String endDate) {
        Report report = adminService.generateReport(reportType, startDate, endDate);
        // Implementation to download report
        return "redirect:/admin/analytics";
    }

    private Double calculateTotalAmount(List<FinancialTransaction> transactions) {
        return transactions.stream()
                .mapToDouble(FinancialTransaction::getAmount)
                .sum();
    }
}