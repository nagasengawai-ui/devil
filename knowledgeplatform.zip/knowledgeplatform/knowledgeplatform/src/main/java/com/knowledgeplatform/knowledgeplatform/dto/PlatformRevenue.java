package com.knowledgeplatform.knowledgeplatform.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class PlatformRevenue {
    @NotNull @Min(0) private Double totalRevenue;
    @NotNull @Min(0) private Double todayRevenue;
    @NotNull @Min(0) private Double monthlyRevenue;
    @NotNull @Min(0) private Double platformCommission;
    @NotNull @Min(0) private Long activeSubscriptions;
    @NotNull @Min(0) private Double pendingPayouts;

    public PlatformRevenue() {}

    // Getters and setters
    public Double getTotalRevenue() { return totalRevenue; }
    public void setTotalRevenue(Double totalRevenue) { this.totalRevenue = totalRevenue; }
    public Double getTodayRevenue() { return todayRevenue; }
    public void setTodayRevenue(Double todayRevenue) { this.todayRevenue = todayRevenue; }
    public Double getMonthlyRevenue() { return monthlyRevenue; }
    public void setMonthlyRevenue(Double monthlyRevenue) { this.monthlyRevenue = monthlyRevenue; }
    public Double getPlatformCommission() { return platformCommission; }
    public void setPlatformCommission(Double platformCommission) { this.platformCommission = platformCommission; }
    public @NotNull @Min(0) Long getActiveSubscriptions() { return activeSubscriptions; }
    public void setActiveSubscriptions(Long activeSubscriptions) { this.activeSubscriptions = activeSubscriptions; }
    public Double getPendingPayouts() { return pendingPayouts; }
    public void setPendingPayouts(Double pendingPayouts) { this.pendingPayouts = pendingPayouts; }
}