package com.knowledgeplatform.knowledgeplatform.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    
    // Find by transaction ID
    Optional<Transaction> findByTransactionId(String transactionId);
    
    // Find by user ID
    List<Transaction> findByUserId(Long userId);
    
    // Find by mentor ID
    List<Transaction> findByMentorId(Long mentorId);
    
    // Find by course ID
    List<Transaction> findByCourseId(Long courseId);
    
    // Find by status
    List<Transaction> findByStatus(String status);
    
    // Find by transaction type
    List<Transaction> findByTransactionType(String transactionType);
    
    // Find by payment method
    List<Transaction> findByPaymentMethod(String paymentMethod);
    
    // Find by status and transaction type
    List<Transaction> findByStatusAndTransactionType(String status, String transactionType);
    
    // Find transactions within date range
    List<Transaction> findByCreatedAtBetween(LocalDateTime start, LocalDateTime end);
    
    // Find recent transactions
    List<Transaction> findTop10ByOrderByCreatedAtDesc();
    
    // Calculate total revenue
    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.status = 'COMPLETED'")
    Double getTotalRevenue();
    
    // Calculate total platform commission
    @Query("SELECT COALESCE(SUM(t.platformCommission), 0) FROM Transaction t WHERE t.status = 'COMPLETED'")
    Double getTotalCommission();
    
    // Calculate revenue since a specific date
    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.status = 'COMPLETED' AND t.createdAt >= :since")
    Double getRevenueSince(@Param("since") LocalDateTime since);
    
    // Calculate mentor earnings
    @Query("SELECT COALESCE(SUM(t.mentorEarnings), 0) FROM Transaction t WHERE t.mentor.id = :mentorId AND t.status = 'COMPLETED'")
    Double getMentorEarnings(@Param("mentorId") Long mentorId);
    
    // Count transactions by status
    Long countByStatus(String status);
    
    // Find transactions by gateway transaction ID
    Optional<Transaction> findByGatewayTransactionId(String gatewayTransactionId);
    
    // Find failed transactions with reason
    List<Transaction> findByStatusAndFailureReasonIsNotNull(String status);
}