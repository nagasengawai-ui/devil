package com.knowledgeplatform.knowledgeplatform.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.CourseLecture;
import com.knowledgeplatform.knowledgeplatform.model.CourseSection;
import com.knowledgeplatform.knowledgeplatform.model.Enrollment;
import com.knowledgeplatform.knowledgeplatform.model.Review;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.service.CourseService;
import com.knowledgeplatform.knowledgeplatform.service.EnrollmentService;
import com.knowledgeplatform.knowledgeplatform.service.UserService;
import com.stripe.service.ReviewService;


@Controller
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    private ReviewService reviewService;

    @Autowired
    private UserService userService;

    // Course Detail Page
    @GetMapping("/{courseId}")
    public String courseDetail(@PathVariable Long courseId, Model model, Principal principal) {
        Course course = courseService.getCourseById(courseId);
        
        if (course == null) {
            return "redirect:/courses";
        }

        // Increment view count
        courseService.incrementViewCount(courseId);

        model.addAttribute("course", course);
        model.addAttribute("mentor", course.getMentor());
        model.addAttribute("sections", course.getSections());
        model.addAttribute("reviews", reviewService.getCourseReviews(courseId));

        // Check if user is enrolled
        if (principal != null) {
            User user = getUserFromPrincipal(principal);
            boolean isEnrolled = enrollmentService.isUserEnrolled(user.getId(), courseId);
            model.addAttribute("isEnrolled", isEnrolled);
            model.addAttribute("currentUser", user);
        }

        // Related courses
        List<Course> relatedCourses = courseService.getEnrolledCourses(courseId);
        model.addAttribute("relatedCourses", relatedCourses);

        return "courses/detail";
    }

    // Enroll in Course
    @PostMapping("/{courseId}/enroll")
    public String enrollInCourse(@PathVariable Long courseId,
                               Principal principal,
                               RedirectAttributes redirectAttributes) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = getUserFromPrincipal(principal);
        
        try {
            Enrollment enrollment = enrollmentService.enrollUserInCourse(user.getId(), courseId);
            redirectAttributes.addFlashAttribute("success", "Successfully enrolled in course!");
            return "redirect:/courses/learn/" + courseId;
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Enrollment failed: " + e.getMessage());
            return "redirect:/courses/" + courseId;
        }
    }

    // Course Learning Interface
    @GetMapping("/learn/{courseId}")
    public String learnCourse(@PathVariable Long courseId, 
                            @RequestParam(required = false) Long lectureId,
                            Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = getUserFromPrincipal(principal);
        
        // Check enrollment
        if (!enrollmentService.isUserEnrolled(user.getId(), courseId)) {
            return "redirect:/courses/" + courseId;
        }

        Course course = courseService.getCourseById(courseId);
        if (course == null) {
            return "redirect:/courses";
        }

        // Get course progress
        double progress = enrollmentService.getUserProgress(user.getId(), courseId);
        
        model.addAttribute("course", course);
        model.addAttribute("progress", progress);
        model.addAttribute("currentUser", user);

        // Get current lecture
        Course currentLecture = null;
        if (lectureId != null) {
            currentLecture = getLectureById(lectureId);
        } else {
            // Get first lecture
            currentLecture = getFirstLecture(course);
        }
        model.addAttribute("currentLecture", currentLecture);

        return "courses/learn";
    }

    // Mark Lecture as Complete
    @PostMapping("/learn/{courseId}/complete-lecture")
    @ResponseBody
    public ApiResponse completeLecture(@PathVariable Long courseId,
                                     @RequestParam Long lectureId,
                                     Principal principal) {
        if (principal == null) {
            return new ApiResponse("error", "Not authenticated");
        }

        User user = getUserFromPrincipal(principal);
        
        try {
            // Update progress (assuming each lecture contributes equally)
            double currentProgress = enrollmentService.getUserProgress(user.getId(), courseId);
            // Simple progress calculation - you might want more sophisticated logic
            double newProgress = Math.min(currentProgress + 10.0, 100.0);
            enrollmentService.updateProgress(user.getId(), courseId, newProgress);
            
            return new ApiResponse("success", "Lecture marked as complete");
        } catch (Exception e) {
            return new ApiResponse("error", e.getMessage());
        }
    }

    // Add Review
    @PostMapping("/{courseId}/review")
    public String addReview(@PathVariable Long courseId,
                          @RequestParam Integer rating,
                          @RequestParam String comment,
                          Principal principal,
                          RedirectAttributes redirectAttributes) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = getUserFromPrincipal(principal);
        
        try {
            Review review = reviewService.addReview(courseId, user.getId(), rating, comment);
            redirectAttributes.addFlashAttribute("success", "Review submitted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to submit review: " + e.getMessage());
        }

        return "redirect:/courses/" + courseId;
    }

    // Course Preview (for non-enrolled users)
    @GetMapping("/{courseId}/preview")
    public String coursePreview(@PathVariable Long courseId, Model model) {
        Course course = courseService.getCourseById(courseId);
        if (course == null) {
            return "redirect:/courses";
        }

        Long previewLectures = getPreviewLectures(courseId);

        model.addAttribute("course", course);
        model.addAttribute("previewLectures", previewLectures);
        model.addAttribute("mentor", course.getMentor());

        return "courses/preview";
    }

    // Download Course Resources
    @GetMapping("/{courseId}/download/{resourceId}")
    public String downloadResource(@PathVariable Long courseId,
                                 @PathVariable Long resourceId,
                                 Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = getUserFromPrincipal(principal);
        
        // Check enrollment and permissions
        if (!enrollmentService.isUserEnrolled(user.getId(), courseId)) {
            return "redirect:/courses/" + courseId;
        }

        // Implementation for file download would go here
        // For now, redirect back to course page
        return "redirect:/courses/" + courseId;
    }

    private User getUserFromPrincipal(Principal principal) {
        return userService.getUserByEmail(principal.getName());
    }

    private Course getLectureById(Long lectureId) {
        // Implementation to get lecture by ID - you'll need to add this to CourseService
        return courseService.getLectureById(lectureId);
    }

    private CourseLecture getFirstLecture(Course course) {
        if (course.getSections() == null || course.getSections().isEmpty()) {
            return null;
        }
        CourseSection firstSection = course.getSections().get(0);
        if (firstSection.getLectures() == null || firstSection.getLectures().isEmpty()) {
            return null;
        }
        return firstSection.getLectures().get(0);
    }

    private Long getPreviewLectures(Long courseId) {
        // Implementation to get preview lectures - you'll need to add this to CourseService
        return courseService.getPreviewLectures(courseId);
    }
}

// API Response DTO
class ApiResponse {
    private String status;
    private String message;
    private Object data;

    public ApiResponse(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public ApiResponse(String status, String message, Object data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    // Getters and setters
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public Object getData() { return data; }
    public void setData(Object data) { this.data = data; }
}