package com.knowledgeplatform.knowledgeplatform.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.Enrollment;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {

    // Find enrollment by user and course
    Optional<Enrollment> findByUserIdAndCourseId(Long userId, Long courseId);
    
    // Find all enrollments for a user
    List<Enrollment> findByUserId(Long userId);
    
    // Find all enrollments for a course
    List<Enrollment> findByCourseId(Long courseId);
    
    // Find all enrollments for a mentor's courses
    @Query("SELECT e FROM Enrollment e WHERE e.course.mentor.id = :mentorId")
    List<Enrollment> findByMentorId(@Param("mentorId") Long mentorId);
    
    // Find enrollments by status
    List<Enrollment> findByStatus(String status);
    
    // Find active enrollments for a user
    List<Enrollment> findByUserIdAndStatus(Long userId, String status);
    
    // Find completed enrollments for a user
    List<Enrollment> findByUserIdAndStatusOrderByCompletedAtDesc(Long userId, String status);
    
    // Count enrollments by course
    Long countByCourseId(Long courseId);
    
    // Count active enrollments by course
    Long countByCourseIdAndStatus(Long courseId, String status);
    
    // Count enrollments by user
    Long countByUserId(Long userId);
    
    // Count enrollments by mentor
    @Query("SELECT COUNT(e) FROM Enrollment e WHERE e.course.mentor.id = :mentorId")
    Long countByMentorId(@Param("mentorId") Long mentorId);
    
    // Check if user is enrolled in a course
    Boolean existsByUserIdAndCourseId(Long userId, Long courseId);
    
    // Check if user is actively enrolled in a course
    Boolean existsByUserIdAndCourseIdAndStatus(Long userId, Long courseId, String status);
    
    // Find enrollments created after a certain date
    List<Enrollment> findByCreatedAtAfter(LocalDateTime date);
    
    // Find enrollments by payment status
    List<Enrollment> findByPaymentStatus(String paymentStatus);
    
    // Calculate course completion rate for a user
    @Query("SELECT COUNT(e) FROM Enrollment e WHERE e.user.id = :userId AND e.status = 'COMPLETED'")
    Long countCompletedEnrollmentsByUserId(@Param("userId") Long userId);
    
    // Calculate overall completion rate for a course
    @Query("SELECT COUNT(e) FROM Enrollment e WHERE e.course.id = :courseId AND e.status = 'COMPLETED'")
    Long countCompletedEnrollmentsByCourseId(@Param("courseId") Long courseId);
    
    // Get recent enrollments for a course
    List<Enrollment> findByCourseIdOrderByCreatedAtDesc(Long courseId);
    
    // Get enrollments that are about to expire
    @Query("SELECT e FROM Enrollment e WHERE e.accessExpiryDate <= :date AND e.status = 'ACTIVE'")
    List<Enrollment> findExpiringEnrollments(@Param("date") LocalDateTime date);
    
    // Find enrollments with progress greater than
    List<Enrollment> findByProgressGreaterThanEqual(Double progress);
    
    // Find enrollments by course and progress
    List<Enrollment> findByCourseIdAndProgressGreaterThanEqual(Long courseId, Double progress);
    
    // Calculate average progress for a course
    @Query("SELECT COALESCE(AVG(e.progress), 0) FROM Enrollment e WHERE e.course.id = :courseId")
    Double calculateAverageProgressByCourseId(@Param("courseId") Long courseId);
    
    // Get top students by progress for a course
    List<Enrollment> findByCourseIdOrderByProgressDesc(Long courseId);
        
        
        @Query("SELECT e FROM Enrollment e WHERE e.course.id = :courseId AND e.status = 'ACTIVE'")
        List<Enrollment> findActiveEnrollmentsByCourseId(@Param("courseId") Long courseId);

		int countAllEnrollments1();

		    
		    boolean existsByUserIdAndCourseId1(Long userId, Long courseId);
		    
		    Optional<Enrollment> findByUserIdAndCourseId1(Long userId, Long courseId);
		    
		    List<Enrollment> findByUserId1(Long userId);
		    
		    List<Enrollment> findByCourseId1(Long courseId);
		    
		    List<Enrollment> findByUserIdAndStatus1(Long userId, String status);
		    
		    int countByUserId1(Long userId);
		    
		    int countByCourseId1(Long courseId);
		    
		    int countByStatus(String status);
		    
		    @Query("SELECT COUNT(e) FROM Enrollment e")
		    int countAllEnrollments();
		    
		    @Query("SELECT e FROM Enrollment e ORDER BY e.enrolledAt DESC LIMIT :limit")
		    List<Enrollment> findTopByOrderByEnrolledAtDesc(@Param("limit") int limit);
		    
		    @Query("SELECT e FROM Enrollment e WHERE e.user.id = :userId AND e.course.id = :courseId AND e.status = 'COMPLETED'")
		    Optional<Enrollment> findCompletedEnrollment(@Param("userId") Long userId, @Param("courseId") Long courseId);
		

		
}