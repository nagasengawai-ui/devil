package com.knowledgeplatform.knowledgeplatform.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.PlatformNotification;

@Repository
public interface NotificationRepository extends JpaRepository<PlatformNotification, Long> {
    
    List<PlatformNotification> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<PlatformNotification> findByUserIdAndIsReadFalse(Long userId);
    List<PlatformNotification> findByUserIdAndCreatedAtAfterOrderByCreatedAtDesc(Long userId, LocalDateTime date);
    Long countByUserIdAndIsReadFalse(Long userId);
    void deleteByUserId(Long userId);
    
    @Query("SELECT n FROM PlatformNotification n WHERE n.user.id = :userId AND n.createdAt >= :date ORDER BY n.createdAt DESC")
    List<PlatformNotification> findRecentByUserId(@Param("userId") Long userId, @Param("date") LocalDateTime date);
}