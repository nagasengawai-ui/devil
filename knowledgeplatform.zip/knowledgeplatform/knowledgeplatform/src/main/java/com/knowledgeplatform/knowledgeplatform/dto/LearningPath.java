
package com.knowledgeplatform.knowledgeplatform.dto;

import java.util.List;

import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.MentorProfile;

public class LearningPath {
    private String goal;
    private Integer estimatedDuration;
    private String difficultyLevel;
    private List<Course> recommendedCourses;
    private List<MentorProfile> recommendedMentors;
    private List<Milestone> milestones;

    // Getters and setters
    public String getGoal() { return goal; }
    public void setGoal(String goal) { this.goal = goal; }
    public Integer getEstimatedDuration() { return estimatedDuration; }
    public void setEstimatedDuration(Integer estimatedDuration) { this.estimatedDuration = estimatedDuration; }
    public String getDifficultyLevel() { return difficultyLevel; }
    public void setDifficultyLevel(String difficultyLevel) { this.difficultyLevel = difficultyLevel; }
    public List<Course> getRecommendedCourses() { return recommendedCourses; }
    public void setRecommendedCourses(List<Course> recommendedCourses) { this.recommendedCourses = recommendedCourses; }
    public List<MentorProfile> getRecommendedMentors() { return recommendedMentors; }
    public void setRecommendedMentors(List<MentorProfile> recommendedMentors) { this.recommendedMentors = recommendedMentors; }
    public List<Milestone> getMilestones() { return milestones; }
    public void setMilestones(List<Milestone> list) { this.milestones = list; }
}