package com.knowledgeplatform.knowledgeplatform.model;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "mentor_profiles")
public class MentorProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ElementCollection
    private List<String> expertiseAreas = new ArrayList<>();

    @ElementCollection
    private List<String> skills = new ArrayList<>();

    @Size(max = 100)
    private String professionalTitle;

    @Column(columnDefinition = "TEXT")
    private String bio;

    private String videoIntroductionUrl;

    private Boolean isVerified = false;
    private String verificationStatus = "PENDING";
    private Boolean kycCompleted = false;

    @ElementCollection
    private List<String> credentials = new ArrayList<>();

    private Boolean offersCourses = false;
    private Boolean offersMentoring = false;
    private Boolean offersWebinars = false;

    @DecimalMin("0.0")
    private Double courseBasePrice = 0.0;

    @DecimalMin("0.0")
    private Double mentoringRatePerMinute = 2.0;

    @DecimalMin("0.0")
    private Double webinarBasePrice = 0.0;

    private String timezone = "UTC";
    private Boolean isAvailable = true;

    @Embedded
    private AvailabilitySchedule availabilitySchedule;

    @DecimalMin("0.0")
    @DecimalMax("5.0")
    private Double averageRating = 0.0;

    private Integer totalRatings = 0;
    private Long totalStudents = 0L;
    private Integer totalSessions = 0;

    @DecimalMin("0.0")
    private Double totalEarnings = 0.0;

    @DecimalMin("0.0")
    private Double availableBalance = 0.0;

    @DecimalMin("0.0")
    private Double lifetimeEarnings = 0.0;

    private Long profileViews = 0L;
    private Long profileCompletions = 0L;
    private Double conversionRate = 0.0;

    private Integer yearsOfExperience = 0;
    private String company;
    private String website;

    @ElementCollection
    private List<String> socialLinks = new ArrayList<>();

    private String verificationNotes;
    private LocalDateTime verifiedAt;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "mentor")
    private List<Course> courses = new ArrayList<>();

    @OneToMany(mappedBy = "mentor")
    private List<LiveSession> liveSessions = new ArrayList<>();

    @OneToMany(mappedBy = "mentor")
    private List<Review> reviews = new ArrayList<>();

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public MentorProfile() {}

    public MentorProfile(User user) {
        this.user = user;
    }

    // Business Methods
    public boolean isEligibleForPayout() {
        return availableBalance >= 50.0;
    }

    public void addEarning(Double amount) {
        this.totalEarnings += amount;
        this.availableBalance += amount;
        this.lifetimeEarnings += amount;
    }

    public void requestPayout(Double amount) {
        if (amount <= availableBalance) {
            this.availableBalance -= amount;
        }
    }

    public void updateRating(Integer newRating) {
        double currentTotal = averageRating * totalRatings;
        totalRatings++;
        averageRating = (currentTotal + newRating) / totalRatings;
    }

    public String getVerificationBadge() {
        if (isVerified) return "✅ Verified Mentor";
        if ("PENDING".equals(verificationStatus)) return "⏳ Verification Pending";
        return "❌ Not Verified";
    }

    public Double calculateEstimatedEarnings() {
        return (mentoringRatePerMinute * 20 * 4) +
               (courseBasePrice * 5) +
               (webinarBasePrice * 2);
    }

    // Getters and Setters
    public Long getId() { return id; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public List<String> getExpertiseAreas() { return expertiseAreas; }
    public void setExpertiseAreas(List<String> expertiseAreas) { this.expertiseAreas = expertiseAreas; }
    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }
    public String getProfessionalTitle() { return professionalTitle; }
    public void setProfessionalTitle(String professionalTitle) { this.professionalTitle = professionalTitle; }
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    public String getVideoIntroductionUrl() { return videoIntroductionUrl; }
    public void setVideoIntroductionUrl(String videoIntroductionUrl) { this.videoIntroductionUrl = videoIntroductionUrl; }
    public Boolean getIsVerified() { return isVerified; }
    public void setIsVerified(Boolean isVerified) { this.isVerified = isVerified; }
    public String getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(String verificationStatus) { this.verificationStatus = verificationStatus; }
    public Boolean getKycCompleted() { return kycCompleted; }
    public void setKycCompleted(Boolean kycCompleted) { this.kycCompleted = kycCompleted; }
    public List<String> getCredentials() { return credentials; }
    public void setCredentials(List<String> credentials) { this.credentials = credentials; }
    public Boolean getOffersCourses() { return offersCourses; }
    public void setOffersCourses(Boolean offersCourses) { this.offersCourses = offersCourses; }
    public Boolean getOffersMentoring() { return offersMentoring; }
    public void setOffersMentoring(Boolean offersMentoring) { this.offersMentoring = offersMentoring; }
    public Boolean getOffersWebinars() { return offersWebinars; }
    public void setOffersWebinars(Boolean offersWebinars) { this.offersWebinars = offersWebinars; }
    public Double getCourseBasePrice() { return courseBasePrice; }
    public void setCourseBasePrice(Double courseBasePrice) { this.courseBasePrice = courseBasePrice; }
    public Double getMentoringRatePerMinute() { return mentoringRatePerMinute; }
    public void setMentoringRatePerMinute(Double mentoringRatePerMinute) { this.mentoringRatePerMinute = mentoringRatePerMinute; }
    public Double getWebinarBasePrice() { return webinarBasePrice; }
    public void setWebinarBasePrice(Double webinarBasePrice) { this.webinarBasePrice = webinarBasePrice; }
    public String getTimezone() { return timezone; }
    public void setTimezone(String timezone) { this.timezone = timezone; }
    public Boolean getIsAvailable() { return isAvailable; }
    public void setIsAvailable(Boolean isAvailable) { this.isAvailable = isAvailable; }
    public AvailabilitySchedule getAvailabilitySchedule() { return availabilitySchedule; }
    public void setAvailabilitySchedule(AvailabilitySchedule availabilitySchedule) { this.availabilitySchedule = availabilitySchedule; }
    public Double getAverageRating() { return averageRating; }
    public void setAverageRating(Double averageRating) { this.averageRating = averageRating; }
    public Integer getTotalRatings() { return totalRatings; }
    public void setTotalRatings(Integer totalRatings) { this.totalRatings = totalRatings; }
    public Long getTotalStudents() { return totalStudents; }
    public void setTotalStudents(Long totalStudents) { this.totalStudents = totalStudents; }
    public Integer getTotalSessions() { return totalSessions; }
    public void setTotalSessions(Integer totalSessions) { this.totalSessions = totalSessions; }
    public Double getTotalEarnings() { return totalEarnings; }
    public void setTotalEarnings(Double totalEarnings) { this.totalEarnings = totalEarnings; }
    public Double getAvailableBalance() { return availableBalance; }
    public void setAvailableBalance(Double availableBalance) { this.availableBalance = availableBalance; }
    public Double getLifetimeEarnings() { return lifetimeEarnings; }
    public void setLifetimeEarnings(Double lifetimeEarnings) { this.lifetimeEarnings = lifetimeEarnings; }
    public Long getProfileViews() { return profileViews; }
    public void setProfileViews(Long profileViews) { this.profileViews = profileViews; }
    public Long getProfileCompletions() { return profileCompletions; }
    public void setProfileCompletions(Long profileCompletions) { this.profileCompletions = profileCompletions; }
    public Double getConversionRate() { return conversionRate; }
    public void setConversionRate(Double conversionRate) { this.conversionRate = conversionRate; }
    public Integer getYearsOfExperience() { return yearsOfExperience; }
    public void setYearsOfExperience(Integer yearsOfExperience) { this.yearsOfExperience = yearsOfExperience; }
    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }
    public String getWebsite() { return website; }
    public void setWebsite(String website) { this.website = website; }
    public List<String> getSocialLinks() { return socialLinks; }
    public void setSocialLinks(List<String> socialLinks) { this.socialLinks = socialLinks; }
    public String getVerificationNotes() { return verificationNotes; }
    public void setVerificationNotes(String verificationNotes) { this.verificationNotes = verificationNotes; }
    public LocalDateTime getVerifiedAt() { return verifiedAt; }
    public void setVerifiedAt(LocalDateTime verifiedAt) { this.verifiedAt = verifiedAt; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    public List<Course> getCourses() { return courses; }
    public void setCourses(List<Course> courses) { this.courses = courses; }
    public List<LiveSession> getLiveSessions() { return liveSessions; }
    public void setLiveSessions(List<LiveSession> liveSessions) { this.liveSessions = liveSessions; }
    public List<Review> getReviews() { return reviews; }
    public void setReviews(List<Review> reviews) { this.reviews = reviews; }
}