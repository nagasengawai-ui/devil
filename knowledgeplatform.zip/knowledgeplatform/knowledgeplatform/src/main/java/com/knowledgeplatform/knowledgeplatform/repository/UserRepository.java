package com.knowledgeplatform.knowledgeplatform.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.knowledgeplatform.knowledgeplatform.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    // Find user by email
    Optional<User> findByEmail(String email);
    
    // Find user by username
    Optional<User> findByUsername(String username);
    
    // Check if email exists
    boolean existsByEmail(String email);
    
    // Check if username exists
    boolean existsByUsername(String username);
    
    // Find users by role
    List<User> findByRole(String role);
    
    // Find users by status
    List<User> findByStatus(String status);
    
    // Find active users
    List<User> findByStatusAndEmailVerified(String status, Boolean emailVerified);
    
    // Find top 5 newest users
    List<User> findTop5ByOrderByCreatedAtDesc();
    
    // Count users by role
    Long countByRole(String role);
    
    // Count users by status
    Long countByStatus(String status);
    
    // Search users by name or email
    @Query("SELECT u FROM User u WHERE u.firstName LIKE %:query% OR u.lastName LIKE %:query% OR u.email LIKE %:query%")
    List<User> searchUsers(@Param("query") String query);
    
    // Find users with completed profiles
    @Query("SELECT u FROM User u WHERE u.profileCompleted = true")
    List<User> findUsersWithCompletedProfiles();
    
    // Find users by multiple criteria
    @Query("SELECT u FROM User u WHERE u.role = :role AND u.status = :status AND u.emailVerified = :verified")
    List<User> findByRoleAndStatusAndEmailVerified(@Param("role") String role, 
                                                  @Param("status") String status, 
                                                  @Param("verified") Boolean verified);

	List<User> findByFirstNameContainingOrLastNameContainingOrEmailContaining(String query, String query2,
			String query3);

	List<User> findByRoleContaining(String role);

	Long countByCreatedAtBefore(LocalDateTime oneMonthAgo);
}