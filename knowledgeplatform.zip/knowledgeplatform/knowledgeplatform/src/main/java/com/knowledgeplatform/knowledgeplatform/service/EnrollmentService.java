package com.knowledgeplatform.knowledgeplatform.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.knowledgeplatform.knowledgeplatform.model.Course;
import com.knowledgeplatform.knowledgeplatform.model.Enrollment;
import com.knowledgeplatform.knowledgeplatform.model.User;
import com.knowledgeplatform.knowledgeplatform.repository.CourseRepository;
import com.knowledgeplatform.knowledgeplatform.repository.EnrollmentRepository;
import com.knowledgeplatform.knowledgeplatform.repository.UserRepository;

@Service  
public class EnrollmentService {

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CourseRepository courseRepository;

    public boolean isUserEnrolled(Long userId, Long courseId) {
        return enrollmentRepository.existsByUserIdAndCourseId(userId, courseId);
    }

    public Enrollment enrollUserInCourse(Long userId, Long courseId) {
        Optional<User> user = userRepository.findById(userId);
        Optional<Course> course = courseRepository.findById(courseId);

        if (user.isPresent() && course.isPresent()) {
            // Check if already enrolled
            if (isUserEnrolled(userId, courseId)) {
                throw new RuntimeException("User is already enrolled in this course");
            }

            Enrollment enrollment = new Enrollment();
            enrollment.setUser(user.get());
            enrollment.setCourse(course.get());
            enrollment.setEnrolledAt(LocalDateTime.now());
            enrollment.setStatus("ACTIVE");
            enrollment.setProgress(0.0);
            enrollment.setLastActivityAt(LocalDateTime.now());

            return enrollmentRepository.save(enrollment);
        }
        throw new RuntimeException("User or Course not found");
    }

    public void unenrollUserFromCourse(Long userId, Long courseId) {
        Optional<Enrollment> enrollment = enrollmentRepository.findByUserIdAndCourseId(userId, courseId);
        if (enrollment.isPresent()) {
            enrollmentRepository.delete(enrollment.get());
        }
    }

    public List<Enrollment> getUserEnrollments(Long userId) {
        return enrollmentRepository.findByUserId(userId);
    }

    public List<Enrollment> getCourseEnrollments(Long courseId) {
        return enrollmentRepository.findByCourseId(courseId);
    }

    public Long getEnrollmentCountForCourse(Long courseId) {
        return enrollmentRepository.countByCourseId(courseId);
    }

    public Long getEnrollmentCountForUser(Long userId) {
        return enrollmentRepository.countByUserId(userId);
    }

    public void updateProgress(Long userId, Long courseId, double progress) {
        Optional<Enrollment> enrollment = enrollmentRepository.findByUserIdAndCourseId(userId, courseId);
        if (enrollment.isPresent()) {
            Enrollment enroll = enrollment.get();
            enroll.setProgress(progress);
            enroll.setLastActivityAt(LocalDateTime.now());
            
            if (progress >= 100.0) {
                enroll.setCompletedAt(LocalDateTime.now());
                enroll.setStatus("COMPLETED");
            }
            
            enrollmentRepository.save(enroll);
        }
    }

    public void completeEnrollment(Long userId, Long courseId) {
        Optional<Enrollment> enrollment = enrollmentRepository.findByUserIdAndCourseId(userId, courseId);
        if (enrollment.isPresent()) {
            Enrollment enroll = enrollment.get();
            enroll.setProgress(100.0);
            enroll.setStatus("COMPLETED");
            enroll.setCompletedAt(LocalDateTime.now());
            enroll.setLastActivityAt(LocalDateTime.now());
            enrollmentRepository.save(enroll);
        }
    }

    public double getUserProgress(Long userId, Long courseId) {
        Optional<Enrollment> enrollment = enrollmentRepository.findByUserIdAndCourseId(userId, courseId);
        return enrollment.map(Enrollment::getProgress).orElse(0.0);
    }

    public List<Enrollment> getActiveEnrollments(Long userId) {
        return enrollmentRepository.findByUserIdAndStatus(userId, "ACTIVE");
    }

    public List<Enrollment> getCompletedEnrollments(Long userId) {
        return enrollmentRepository.findByUserIdAndStatus(userId, "COMPLETED");
    }

    public int getTotalEnrollmentsCount() {
        return enrollmentRepository.countAllEnrollments();
    }

    public int getActiveEnrollmentsCount() {
        return enrollmentRepository.countByStatus("ACTIVE");
    }

    public int getCompletedEnrollmentsCount() {
        return enrollmentRepository.countByStatus("COMPLETED");
    }

    public List<Enrollment> getRecentEnrollments(int limit) {
        return enrollmentRepository.findTopByOrderByEnrolledAtDesc(limit);
    }

    public boolean hasUserCompletedCourse(Long userId, Long courseId) {
        Optional<Enrollment> enrollment = enrollmentRepository.findByUserIdAndCourseId(userId, courseId);
        return enrollment.isPresent() && "COMPLETED".equals(enrollment.get().getStatus());
    }

	public void markLectureComplete(Long id, Long courseId, Long lectureId) {
		// TODO Auto-generated method stub
		
	}
}