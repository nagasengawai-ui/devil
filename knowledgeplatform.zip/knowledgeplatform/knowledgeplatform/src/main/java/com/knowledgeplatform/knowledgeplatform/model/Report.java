package com.knowledgeplatform.knowledgeplatform.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class Report {
    private Long id;
    private String reportId;
    private String title;
    private String description;
    private String reportType;
    private String format; // PDF, EXCEL, CSV, HTML, JSON
    private String status; // GENERATING, COMPLETED, FAILED, SCHEDULED
    private LocalDateTime generatedAt;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private Long generatedByUserId;
    private String generatedByUserName;
    private String fileUrl;
    private Long fileSize;
    private Integer recordCount;
    private String filters; // JSON string of applied filters
    private String parameters; // JSON string of report parameters
    private String data; // JSON string of report data (for small reports)
    private String summary; // Brief summary of the report
    private String errorMessage;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private ReportMetadata metadata;

    // Default constructor
    public Report() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.status = Status.GENERATING;
        generateReportId();
    }

    // Constructor with required fields
    public Report(String title, String reportType, LocalDateTime startDate, LocalDateTime endDate) {
        this();
        this.title = title;
        this.reportType = reportType;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getReportId() { return reportId; }
    public void setReportId(String reportId) { this.reportId = reportId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getReportType() { return reportType; }
    public void setReportType(String reportType) { this.reportType = reportType; }

    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }

    public String getStatus() { return status; }
    public void setStatus(String status) { 
        this.status = status;
        this.updatedAt = LocalDateTime.now();
        
        if (Status.COMPLETED.equals(status) && this.generatedAt == null) {
            this.generatedAt = LocalDateTime.now();
        }
    }

    public LocalDateTime getGeneratedAt() { return generatedAt; }
    public void setGeneratedAt(LocalDateTime generatedAt) { this.generatedAt = generatedAt; }

    public LocalDateTime getStartDate() { return startDate; }
    public void setStartDate(LocalDateTime startDate) { this.startDate = startDate; }

    public LocalDateTime getEndDate() { return endDate; }
    public void setEndDate(LocalDateTime endDate) { this.endDate = endDate; }

    public Long getGeneratedByUserId() { return generatedByUserId; }
    public void setGeneratedByUserId(Long generatedByUserId) { this.generatedByUserId = generatedByUserId; }

    public String getGeneratedByUserName() { return generatedByUserName; }
    public void setGeneratedByUserName(String generatedByUserName) { this.generatedByUserName = generatedByUserName; }

    public String getFileUrl() { return fileUrl; }
    public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }

    public Long getFileSize() { return fileSize; }
    public void setFileSize(Long fileSize) { this.fileSize = fileSize; }

    public Integer getRecordCount() { return recordCount; }
    public void setRecordCount(Integer recordCount) { this.recordCount = recordCount; }

    public String getFilters() { return filters; }
    public void setFilters(String filters) { this.filters = filters; }

    public String getParameters() { return parameters; }
    public void setParameters(String parameters) { this.parameters = parameters; }

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }

    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }

    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public ReportMetadata getMetadata() { return metadata; }
    public void setMetadata(ReportMetadata metadata) { this.metadata = metadata; }

    // Business logic methods
    private void generateReportId() {
        if (this.reportId == null) {
            String timestamp = String.valueOf(System.currentTimeMillis());
            String random = String.valueOf((int) (Math.random() * 1000));
            this.reportId = "RPT_" + timestamp + "_" + random;
        }
    }

    // Utility methods
    public boolean isGenerating() {
        return Status.GENERATING.equals(this.status);
    }

    public boolean isCompleted() {
        return Status.COMPLETED.equals(this.status);
    }

    public boolean isFailed() {
        return Status.FAILED.equals(this.status);
    }

    public boolean isScheduled() {
        return Status.SCHEDULED.equals(this.status);
    }

    public boolean isDownloadable() {
        return isCompleted() && this.fileUrl != null;
    }

    public boolean isRevenueReport() {
        return ReportType.REVENUE.equals(this.reportType);
    }

    public boolean isUserReport() {
        return ReportType.USER_ANALYTICS.equals(this.reportType);
    }

    public boolean isCourseReport() {
        return ReportType.COURSE_ANALYTICS.equals(this.reportType);
    }

    public boolean isMentorReport() {
        return ReportType.MENTOR_ANALYTICS.equals(this.reportType);
    }

    public boolean isFinancialReport() {
        return ReportType.FINANCIAL.equals(this.reportType);
    }

    public void markAsCompleted(String fileUrl, Long fileSize, Integer recordCount) {
        this.fileUrl = fileUrl;
        this.fileSize = fileSize;
        this.recordCount = recordCount;
        setStatus(Status.COMPLETED);
    }

    public void markAsFailed(String errorMessage) {
        this.errorMessage = errorMessage;
        setStatus(Status.FAILED);
    }

    public String getFormattedFileSize() {
        if (fileSize == null) return "N/A";
        
        if (fileSize < 1024) {
            return fileSize + " B";
        } else if (fileSize < 1024 * 1024) {
            return String.format("%.2f KB", fileSize / 1024.0);
        } else {
            return String.format("%.2f MB", fileSize / (1024.0 * 1024.0));
        }
    }

    public String getStatusBadge() {
        switch (this.status) {
            case Status.GENERATING: return "warning";
            case Status.COMPLETED: return "success";
            case Status.FAILED: return "danger";
            case Status.SCHEDULED: return "info";
            default: return "secondary";
        }
    }

    public String getFormatIcon() {
        switch (this.format) {
            case Format.PDF: return "📄";
            case Format.EXCEL: return "📊";
            case Format.CSV: return "📋";
            case Format.HTML: return "🌐";
            case Format.JSON: return "🔧";
            default: return "📁";
        }
    }

    public String getDateRange() {
        if (startDate == null || endDate == null) return "N/A";
        return startDate.toLocalDate() + " to " + endDate.toLocalDate();
    }

    // Builder pattern
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Report report = new Report();

        public Builder title(String title) {
            report.title = title;
            return this;
        }

        public Builder description(String description) {
            report.description = description;
            return this;
        }

        public Builder reportType(String reportType) {
            report.reportType = reportType;
            return this;
        }

        public Builder format(String format) {
            report.format = format;
            return this;
        }

        public Builder startDate(LocalDateTime startDate) {
            report.startDate = startDate;
            return this;
        }

        public Builder endDate(LocalDateTime endDate) {
            report.endDate = endDate;
            return this;
        }

        public Builder generatedByUserId(Long generatedByUserId) {
            report.generatedByUserId = generatedByUserId;
            return this;
        }

        public Builder generatedByUserName(String generatedByUserName) {
            report.generatedByUserName = generatedByUserName;
            return this;
        }

        public Builder filters(String filters) {
            report.filters = filters;
            return this;
        }

        public Builder parameters(String parameters) {
            report.parameters = parameters;
            return this;
        }

        public Report build() {
            report.generateReportId();
            return report;
        }
    }

    // Report type constants
    public static class ReportType {
        public static final String REVENUE = "REVENUE";
        public static final String USER_ANALYTICS = "USER_ANALYTICS";
        public static final String COURSE_ANALYTICS = "COURSE_ANALYTICS";
        public static final String MENTOR_ANALYTICS = "MENTOR_ANALYTICS";
        public static final String FINANCIAL = "FINANCIAL";
        public static final String ENGAGEMENT = "ENGAGEMENT";
        public static final String SALES = "SALES";
        public static final String SUBSCRIPTION = "SUBSCRIPTION";
        public static final String PLATFORM_GROWTH = "PLATFORM_GROWTH";
        public static final String CONTENT_PERFORMANCE = "CONTENT_PERFORMANCE";
    }

    // Format constants
    public static class Format {
        public static final String PDF = "PDF";
        public static final String EXCEL = "EXCEL";
        public static final String CSV = "CSV";
        public static final String HTML = "HTML";
        public static final String JSON = "JSON";
    }

    // Status constants
    public static class Status {
        public static final String GENERATING = "GENERATING";
        public static final String COMPLETED = "COMPLETED";
        public static final String FAILED = "FAILED";
        public static final String SCHEDULED = "SCHEDULED";
    }

    @Override
    public String toString() {
        return "Report{" +
                "id=" + id +
                ", reportId='" + reportId + '\'' +
                ", title='" + title + '\'' +
                ", reportType='" + reportType + '\'' +
                ", status='" + status + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                '}';
    }
}

// Report Metadata inner class
class ReportMetadata {
    private Integer totalPages;
    private String generationTime;
    private String dataSource;
    private String version;
    private Map<String, Object> customFields;

    public ReportMetadata() {}

    // Getters and setters
    public Integer getTotalPages() { return totalPages; }
    public void setTotalPages(Integer totalPages) { this.totalPages = totalPages; }

    public String getGenerationTime() { return generationTime; }
    public void setGenerationTime(String generationTime) { this.generationTime = generationTime; }

    public String getDataSource() { return dataSource; }
    public void setDataSource(String dataSource) { this.dataSource = dataSource; }

    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }

    public Map<String, Object> getCustomFields() { return customFields; }
    public void setCustomFields(Map<String, Object> customFields) { this.customFields = customFields; }
}