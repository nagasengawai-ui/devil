package com.knowledgeplatform.knowledgeplatform.model;

import java.time.LocalDateTime;

public class FinancialTransaction {
    private Long id;
    private String transactionId;
    private Long userId;
    private String userFullName;
    private Long mentorId;
    private String mentorName;
    private Long courseId;
    private String courseTitle;
    private Double amount;
    private String currency;
    private Double platformCommission;
    private Double mentorEarnings;
    private String transactionType;
    private String paymentMethod;
    private String paymentGateway;
    private String gatewayTransactionId;
    private String status;
    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime completedAt;
    private LocalDateTime refundedAt;
    private String failureReason;
    private String invoiceUrl;
    private String receiptUrl;
    private String customerEmail;
    private String customerPhone;
    private String billingAddress;
    private String taxAmount;
    private String metadata;

    // Default constructor
    public FinancialTransaction() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.currency = "USD";
    }

    // Constructor with required fields
    public FinancialTransaction(String transactionId, Long userId, Double amount, String transactionType, String status) {
        this();
        this.transactionId = transactionId;
        this.userId = userId;
        this.amount = amount;
        this.transactionType = transactionType;
        this.status = status;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getUserFullName() { return userFullName; }
    public void setUserFullName(String userFullName) { this.userFullName = userFullName; }

    public Long getMentorId() { return mentorId; }
    public void setMentorId(Long mentorId) { this.mentorId = mentorId; }

    public String getMentorName() { return mentorName; }
    public void setMentorName(String mentorName) { this.mentorName = mentorName; }

    public Long getCourseId() { return courseId; }
    public void setCourseId(Long courseId) { this.courseId = courseId; }

    public String getCourseTitle() { return courseTitle; }
    public void setCourseTitle(String courseTitle) { this.courseTitle = courseTitle; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { 
        this.amount = amount;
        calculateEarnings();
    }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public Double getPlatformCommission() { return platformCommission; }
    public void setPlatformCommission(Double platformCommission) { 
        this.platformCommission = platformCommission;
        calculateEarnings();
    }

    public Double getMentorEarnings() { return mentorEarnings; }
    public void setMentorEarnings(Double mentorEarnings) { this.mentorEarnings = mentorEarnings; }

    public String getTransactionType() { return transactionType; }
    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getPaymentGateway() { return paymentGateway; }
    public void setPaymentGateway(String paymentGateway) { this.paymentGateway = paymentGateway; }

    public String getGatewayTransactionId() { return gatewayTransactionId; }
    public void setGatewayTransactionId(String gatewayTransactionId) { this.gatewayTransactionId = gatewayTransactionId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { 
        this.status = status;
        this.updatedAt = LocalDateTime.now();
        
        if ("COMPLETED".equals(status) && this.completedAt == null) {
            this.completedAt = LocalDateTime.now();
        } else if ("REFUNDED".equals(status) && this.refundedAt == null) {
            this.refundedAt = LocalDateTime.now();
        }
    }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }

    public LocalDateTime getRefundedAt() { return refundedAt; }
    public void setRefundedAt(LocalDateTime refundedAt) { this.refundedAt = refundedAt; }

    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }

    public String getInvoiceUrl() { return invoiceUrl; }
    public void setInvoiceUrl(String invoiceUrl) { this.invoiceUrl = invoiceUrl; }

    public String getReceiptUrl() { return receiptUrl; }
    public void setReceiptUrl(String receiptUrl) { this.receiptUrl = receiptUrl; }

    public String getCustomerEmail() { return customerEmail; }
    public void setCustomerEmail(String customerEmail) { this.customerEmail = customerEmail; }

    public String getCustomerPhone() { return customerPhone; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }

    public String getBillingAddress() { return billingAddress; }
    public void setBillingAddress(String billingAddress) { this.billingAddress = billingAddress; }

    public String getTaxAmount() { return taxAmount; }
    public void setTaxAmount(String taxAmount) { this.taxAmount = taxAmount; }

    public String getMetadata() { return metadata; }
    public void setMetadata(String metadata) { this.metadata = metadata; }

    // Business logic methods
    private void calculateEarnings() {
        if (this.amount != null && this.platformCommission != null) {
            this.mentorEarnings = this.amount - this.platformCommission;
        } else if (this.amount != null && this.platformCommission == null) {
            // Default commission rate of 20%
            this.platformCommission = this.amount * 0.20;
            this.mentorEarnings = this.amount - this.platformCommission;
        }
    }

    // Utility methods
    public boolean isCompleted() {
        return "COMPLETED".equals(this.status);
    }

    public boolean isFailed() {
        return "FAILED".equals(this.status);
    }

    public boolean isPending() {
        return "PENDING".equals(this.status);
    }

    public boolean isRefunded() {
        return "REFUNDED".equals(this.status);
    }

    public boolean isCoursePurchase() {
        return "COURSE_PURCHASE".equals(this.transactionType);
    }

    public boolean isMentoringSession() {
        return "MENTORING_SESSION".equals(this.transactionType);
    }

    public boolean isWalletTopup() {
        return "WALLET_TOPUP".equals(this.transactionType);
    }

    public boolean isPayout() {
        return "PAYOUT".equals(this.transactionType);
    }

    public boolean isRefund() {
        return "REFUND".equals(this.transactionType);
    }

    public boolean isWithdrawal() {
        return "WITHDRAWAL".equals(this.transactionType);
    }

    public boolean isSubscription() {
        return "SUBSCRIPTION".equals(this.transactionType);
    }

    public void markAsCompleted() {
        setStatus("COMPLETED");
    }

    public void markAsFailed(String reason) {
        setStatus("FAILED");
        this.failureReason = reason;
    }

    public void markAsRefunded() {
        setStatus("REFUNDED");
    }

    public String getFormattedAmount() {
        return String.format("%s %.2f", this.currency, this.amount);
    }

    public Double getNetAmount() {
        if (this.amount == null) return 0.0;
        if (this.platformCommission == null) return this.amount;
        return this.amount - this.platformCommission;
    }

    public String getStatusColor() {
        switch (this.status) {
            case "COMPLETED": return "success";
            case "PENDING": return "warning";
            case "FAILED": return "danger";
            case "REFUNDED": return "info";
            case "PROCESSING": return "primary";
            default: return "secondary";
        }
    }

    public String getTransactionTypeIcon() {
        switch (this.transactionType) {
            case "COURSE_PURCHASE": return "📚";
            case "MENTORING_SESSION": return "💬";
            case "WALLET_TOPUP": return "💰";
            case "PAYOUT": return "💳";
            case "REFUND": return "↩️";
            case "WITHDRAWAL": return "🏦";
            case "SUBSCRIPTION": return "🔄";
            default: return "💸";
        }
    }

    // Builder pattern
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private FinancialTransaction transaction = new FinancialTransaction();

        public Builder transactionId(String transactionId) {
            transaction.transactionId = transactionId;
            return this;
        }

        public Builder userId(Long userId) {
            transaction.userId = userId;
            return this;
        }

        public Builder userFullName(String userFullName) {
            transaction.userFullName = userFullName;
            return this;
        }

        public Builder mentorId(Long mentorId) {
            transaction.mentorId = mentorId;
            return this;
        }

        public Builder mentorName(String mentorName) {
            transaction.mentorName = mentorName;
            return this;
        }

        public Builder courseId(Long courseId) {
            transaction.courseId = courseId;
            return this;
        }

        public Builder courseTitle(String courseTitle) {
            transaction.courseTitle = courseTitle;
            return this;
        }

        public Builder amount(Double amount) {
            transaction.amount = amount;
            return this;
        }

        public Builder currency(String currency) {
            transaction.currency = currency;
            return this;
        }

        public Builder platformCommission(Double platformCommission) {
            transaction.platformCommission = platformCommission;
            return this;
        }

        public Builder transactionType(String transactionType) {
            transaction.transactionType = transactionType;
            return this;
        }

        public Builder paymentMethod(String paymentMethod) {
            transaction.paymentMethod = paymentMethod;
            return this;
        }

        public Builder paymentGateway(String paymentGateway) {
            transaction.paymentGateway = paymentGateway;
            return this;
        }

        public Builder status(String status) {
            transaction.status = status;
            return this;
        }

        public Builder description(String description) {
            transaction.description = description;
            return this;
        }

        public Builder customerEmail(String customerEmail) {
            transaction.customerEmail = customerEmail;
            return this;
        }

        public FinancialTransaction build() {
            if (transaction.transactionId == null) {
                transaction.transactionId = generateTransactionId();
            }
            transaction.calculateEarnings();
            return transaction;
        }

        private String generateTransactionId() {
            String timestamp = String.valueOf(System.currentTimeMillis());
            String random = String.valueOf((int) (Math.random() * 1000));
            return "TXN_" + timestamp + "_" + random;
        }
    }

    // Transaction type constants
    public static class Type {
        public static final String COURSE_PURCHASE = "COURSE_PURCHASE";
        public static final String MENTORING_SESSION = "MENTORING_SESSION";
        public static final String WALLET_TOPUP = "WALLET_TOPUP";
        public static final String PAYOUT = "PAYOUT";
        public static final String REFUND = "REFUND";
        public static final String WITHDRAWAL = "WITHDRAWAL";
        public static final String SUBSCRIPTION = "SUBSCRIPTION";
        public static final String COMMISSION = "COMMISSION";
        public static final String TAX = "TAX";
    }

    // Status constants
    public static class Status {
        public static final String PENDING = "PENDING";
        public static final String COMPLETED = "COMPLETED";
        public static final String FAILED = "FAILED";
        public static final String REFUNDED = "REFUNDED";
        public static final String CANCELLED = "CANCELLED";
        public static final String PROCESSING = "PROCESSING";
        public static final String REVERSED = "REVERSED";
    }

    // Payment method constants
    public static class PaymentMethod {
        public static final String CREDIT_CARD = "CREDIT_CARD";
        public static final String DEBIT_CARD = "DEBIT_CARD";
        public static final String WALLET = "WALLET";
        public static final String BANK_TRANSFER = "BANK_TRANSFER";
        public static final String STRIPE = "STRIPE";
        public static final String PAYPAL = "PAYPAL";
        public static final String RAZORPAY = "RAZORPAY";
    }

    // Currency constants
    public static class Currency {
        public static final String USD = "USD";
        public static final String EUR = "EUR";
        public static final String GBP = "GBP";
        public static final String INR = "INR";
        public static final String CAD = "CAD";
        public static final String AUD = "AUD";
    }

    @Override
    public String toString() {
        return "FinancialTransaction{" +
                "id=" + id +
                ", transactionId='" + transactionId + '\'' +
                ", userId=" + userId +
                ", amount=" + amount +
                ", currency='" + currency + '\'' +
                ", transactionType='" + transactionType + '\'' +
                ", status='" + status + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FinancialTransaction that = (FinancialTransaction) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        return transactionId != null ? transactionId.equals(that.transactionId) : that.transactionId == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (transactionId != null ? transactionId.hashCode() : 0);
        return result;
    }

	public void setUser(User user) {
		// TODO Auto-generated method stub
		this.setUser(user);
	}
}